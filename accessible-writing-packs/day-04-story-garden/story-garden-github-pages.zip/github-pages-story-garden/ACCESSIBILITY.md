# Accessibility notes

The three profiles are Writer, Source Notes, and Large Type. Writer starts selected.

- Main text begins at 18px; Large Type begins at 22px.
- Keyboard and touch controls have visible focus.
- The settings panel controls text size, line spacing, contrast, and motion.
- Tools start disabled in config.js.
- Activities provide pace, hints, optional sound, contrast, motion, and text controls.
- Activities have no timer, score pressure, flashing, account, or data collection.
- The activities are optional practice. They do not diagnose, treat, or prevent any condition.

Test with real readers, a keyboard, mobile text enlargement, and a screen reader before a public launch.
