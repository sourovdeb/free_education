# v3 change log — 30 September 2026

Baseline: Open_Teacher_Training_Master_v2_2026-09-19.zip, 88 entries.

Preserved: twelve module identities, website section, original instruction-giving sample, skill foundations, timing helper, source archive and governance standards.

Revised: twenty blueprint pages; twelve curriculum pages; eight-page Mistral guide; skill references; website drafts; model selection; source and claim boundaries; review records.

Added: four literacy packs, independent transfer tasks, eighteen glossary bridges, forty-one-page offline HTML hub, nine diagrams, one retained illustration crop, ten target-model test cases, twelve new structural regression cases, evidence register and per-page/per-file ledgers.

Explicit migrations: old M01-U01 objective-setting outline → M01-U04; old M09-U01 feedback outline → M09-U02. URLs remain represented in the draft export. See UNIT_MIGRATION.md.

Removed from active use: duplicate instruction bodies and two bytecode caches. Original outputs remain archived. No original user source was changed.

An initial test run exposed a missing literacy-check call. It was repaired and the complete helper suite rerun. This is documented as a repair, not hidden as a first-pass success.
