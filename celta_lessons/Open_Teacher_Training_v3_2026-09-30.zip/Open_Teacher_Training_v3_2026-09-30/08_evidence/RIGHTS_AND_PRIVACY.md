# Rights and privacy

The public-facing curriculum contains original teaching examples and source-informed paraphrases. It does not reproduce the supplied glossary, candidate record or centre PDFs. Their rights and private status are not overridden by this task.

Historical deliverables are retained for the owner in the master archive. They are not automatically licensed for unrestricted redistribution. The public GitHub source edition excludes those archives and private source links.

No new blanket licence is applied to third-party material. The owner should confirm the licence for original v3 text, code and artwork before general redistribution. Existing governance references are retained with their own context.

No learner names, grades, medical information, service credentials or candidate judgments are intentionally included. Pattern scans are supplementary to source selection, not proof that any arbitrary future input is safe to publish.
