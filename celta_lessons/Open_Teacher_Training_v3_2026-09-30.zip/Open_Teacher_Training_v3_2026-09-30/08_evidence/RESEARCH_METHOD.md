# Research method

Scope: curriculum revision, not accreditation.

The 88-file ZIP is the baseline. The new evidence comprises the supplied glossary, candidate record, ten framework documents, current Cambridge material and external research. Centre instructions are not treated as Cambridge regulations. Public specifications do not establish actual training quality.

Research questions: What foundations are already present? Which literacy practices deserve emphasis? What do segmentation and digital-reading studies support? When might AI assistance improve work without improving learning? What needs testing before publication?

Selection favoured official specifications, original experiments, systematic reviews and standards bodies. Sources were found through targeted web searches and followed to primary pages. This is a focused evidence review, not a preregistered systematic review. No claim of exhaustive coverage is made.

The register records publication, population/design, limits and implications. Research from adolescents, first-language classrooms or college physics is not silently generalised to adult ELT. Effect sizes and headlines do not determine a universal lesson duration. Latest product descriptions establish documented availability only, not account access or quality.

Contrary evidence is retained: some designed AI tutors improved learning; another deployment harmed later unassisted performance. Paper-reading advantages do not imply a ban on screens. Modern CELTA includes digital materials and literacy; it is not represented as unchanged since the 1990s.

Source gaps: the internal page:// link was not accessible through available discovery. The novel-progress note has no usable lesson assets. Original course timetables outside this request were not re-audited. The July 2024 public syllabus was read, including writing and resources tables. The supplied Writing guidance table was visually inspected. All ten framework documents were text-inspected. No private candidate judgments are republished.

Future claims are scenarios, not forecasts. Practical adaptation remains subject to educator and learner trials.
