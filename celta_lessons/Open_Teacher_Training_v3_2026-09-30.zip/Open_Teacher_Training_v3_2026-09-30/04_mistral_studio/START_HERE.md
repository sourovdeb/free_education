# Mistral setup v3

Use the new eight-page setup guide. The old screenshots show an earlier account view. They are not evidence of today’s menu layout.

Current documentation says: Studio → Build → Skills → New Skill. Some accounts may show Skills under Context. Use the visible Skills control, then verify the fields. Add the canonical skill and relevant references. Create Skill. Inspect the saved version. Keep visibility private for testing.

Next create or configure an agent in the available Playground. Paste AGENT_ADAPTER.txt. Select an available candidate model. Use 04_FIRST_TEST.txt. Check the output before considering automation.

A Prompt stores a repeatable request. A Skill stores a method. An Agent combines a model and tools. A function schema does not execute itself. A workflow needs an implemented worker. None was deployed here. [T3–T6]
