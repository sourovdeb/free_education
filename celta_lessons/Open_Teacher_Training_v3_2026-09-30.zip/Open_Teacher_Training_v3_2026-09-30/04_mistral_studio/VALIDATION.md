# Validation pointer

Use ../06_validation/VALIDATION_REPORT.md.
The target Mistral account was not tested.
