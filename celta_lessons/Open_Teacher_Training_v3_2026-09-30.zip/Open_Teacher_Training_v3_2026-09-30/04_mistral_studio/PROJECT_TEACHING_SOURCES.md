# Source pointer

Use ../08_evidence/SOURCE_REGISTER.md.
Private originals are intentionally excluded.
