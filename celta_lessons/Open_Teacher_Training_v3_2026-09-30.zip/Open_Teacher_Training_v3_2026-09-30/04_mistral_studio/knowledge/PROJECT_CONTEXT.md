# Project v3

Use the package course-map.json and START_HERE.md.
Prioritise reading and writing while retaining all four language skills.
No curriculum equivalence or outcome superiority is established.
