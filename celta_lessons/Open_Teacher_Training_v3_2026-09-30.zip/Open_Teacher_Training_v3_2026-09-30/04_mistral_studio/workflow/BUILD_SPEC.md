# One-unit pipeline · v3

Status: specification, not deployment.

Input: unit ID, source IDs, audience, outcome, desired artifact, time estimate, support needs and publishing permission.

State: RECEIVED → SOURCE_CHECKED → PLANNED → MATERIALS_DRAFTED → CHECKED → HUMAN_REVIEW → RELEASED.

A failure writes its stage, input identity, error and next action. Never rerun a successful publish because an acknowledgement was lost. Search for the receipt first. Use one execution owner; do not activate both Apps Script and another scheduler for the same job.

Each run handles one unit. Use existing deterministic utilities first. No new service is a launch dependency. A model creates or reviews material; validators check structure, links and arithmetic. Neither may impersonate human approval.

For reading/writing, preserve actual input, task, answer guidance, revision and unseen transfer. Keep knowledge files distinct from skill instructions. Retrieval means the source was fetched, not that its claims were verified.

Retries: two justified recovery attempts after failure. Checkpoint after that. Publishing is separately authorised. Keep secret credentials outside prompts and public files. Record source version, output hash, actual checks, approval and destination receipt.

Acceptance: one reviewed unit can be loaded, answered, revised and exported without compulsory paid AI. Integration and target-host tests remain pending. [T6]
