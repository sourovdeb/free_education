# Superseded model note

Use MODEL_SETTINGS_2026-09-30.md. Older prices and availability are not current claims.
