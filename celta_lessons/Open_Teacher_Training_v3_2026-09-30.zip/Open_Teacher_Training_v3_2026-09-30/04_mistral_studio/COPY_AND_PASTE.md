# Setup v3

## Agent instructions

```text
Use the teaching-materials-methods v3 skill.
Load only the references needed.
Create one unit per request.
Distinguish trainees from language learners.
Use actual source text and tasks.
Preserve source framing and uncertainty.
Return drafts, answers and revision criteria.
Give hints after learner attempts.
Keep transfer assessment without AI.
Do not infer access or permissions.
Stop after the requested output.
Report executed checks and remaining gaps.
Never publish without an explicit request.
```

## First unit request

```text
Create one teacher-training unit.
Topic: checking a reading summary.
Primary audience: novice adult teachers.
Classroom example: adult B1 learners.
Training duration: 35 minutes, estimated.
Classroom task: 25 minutes, estimated.
Use the supplied source texts.
Include learner and teacher sheets.
Provide keys and revision guidance.
Add an unseen transfer passage.
Use hints only after attempts.
No AI during independent assessment.
Return a reviewable draft.
Do not publish or send.
```

## Model route

# Model route · checked 30 September 2026

## Selection is provisional

Candidate hosted drafter: Mistral Small 4, `mistral-small-2603` [T4]. Candidate local staged assistant: Ministral 3 3B [T5]. Verify the exact available API identifier in the account before use. No paid call or target-host test was performed here.

A review pass is a separate task, not necessarily a separate model. It must inspect sources and answer logic. Reusing a model creates correlated errors. Neither a model name nor a second pass replaces educator judgement.

Mistral Small 4 has 119B total parameters. Its 6.5B active count does not mean it fits a 4GB GPU. No local hardware recommendation is made without measured loading and memory use. Use an already available hosted route or benchmark a small quantised model before installation.

## Test before choosing

Use the same source and request. Log factual errors, invented citations, missing inputs, answer-key disagreements, instruction-following, retries, elapsed time and actual cost. Use the included model-cases.json. Compare like-for-like conditions. Do not invent a score table before tests.

Keep the provider’s supported defaults first. Change one setting at a time. For a stochastic drafting trial, 0.2 and 0.8 can be compared only when supported. Neither is a speed target or a guarantee of truth. Keep token budgets and evidence constant.

Measure first-token latency separately from complete output and review time. A sub-second acknowledgement is not a complete checked teaching pack. No latency promise is made.

Sources: T3–T6 in the evidence register. Prices are deliberately not hard-coded. Recheck costs and access before a batch.
