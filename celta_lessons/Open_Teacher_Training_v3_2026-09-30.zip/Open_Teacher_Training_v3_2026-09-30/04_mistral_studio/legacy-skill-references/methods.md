Historical alias. Do not activate.
Use ../03_skills/teaching-materials-methods from the package root.
The canonical v3 procedure and references take precedence.
