# Open Teacher Training v3

Read. Write. Understand.

## Open first

Open `02_website/site/index.html` after extracting the ZIP. It works without an account or server. Copy your answers before leaving; work is not saved automatically.

Read the twenty-page blueprint in `01_blueprints`. Then use `07_literacy_pilot/M06-U01`. Its learner PDF excludes the answer page. The full workbook includes teacher guidance.

## What is included

Twelve modules and forty-eight unit specifications. Four newly authored literacy packs. One retained instruction-giving pack. Forty-one HTML pages. Nine editable diagrams and one illustration crop. The updated teaching skill and Mistral setup guide. Twenty-eight WordPress draft pages. Evidence, page revisions, file dispositions and test reports.

The five packs are complete samples. The other forty-three units are specifications, not finished lessons. Educator review, learner trials and target-platform tests remain pending. The 200-hour pathway is a proposal.

## What changed

The project keeps useful CELTA foundations. It adds literacy practice, source verification, reader-focused revision and independent transfer. Chunks lead toward depth; they do not replace reading with short videos.

## Where to work

Edit blueprint Markdown in `01_blueprints/pages`. Edit curriculum data in `02_website/course-map.json`. Edit one pilot pack at a time. Use the single canonical `03_skills/teaching-materials-methods/SKILL.md`.

`05_original_deliverables` is history, not active instructions. Private source records are excluded. No live WordPress or Mistral settings changed.

## Review status

Technical checks are not learning outcomes. Read `06_validation/VALIDATION_REPORT.md`. Deployment and storage receipts are recorded separately. Do not infer approval from an upload.
