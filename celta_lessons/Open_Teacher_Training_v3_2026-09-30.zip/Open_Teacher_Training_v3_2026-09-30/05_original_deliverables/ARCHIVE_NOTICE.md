# Historical outputs

These are unchanged v2-era snapshots. They are not the current curriculum. Their dates, source gaps, model choices and test claims may be superseded.

Use START_HERE.md at the package root. No historical success claim establishes v3 validation. The original ZIP remains available to the owner separately.
