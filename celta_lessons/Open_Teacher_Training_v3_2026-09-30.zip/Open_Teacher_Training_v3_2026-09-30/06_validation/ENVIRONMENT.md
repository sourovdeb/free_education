# Local validation environment

Python 3.13.5 on Linux.

Existing ReportLab, PyMuPDF, Pillow, svglib, mistune, BeautifulSoup and Playwright libraries were reused. No dependency was installed. System Chromium existed but navigation was blocked. Rendering and helper execution took place locally, not in the user’s Mistral, Hermes or WordPress installation.
