# Baseline accounting

88 files are accounted for. New files are listed in MANIFEST.json.

| Baseline path | Decision | Reason |
|---|---|---|
| 00_governance/Master Skill Standard.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 00_governance/SKILL_UPGRADE_AUDIT.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 00_governance/Skill Upgrade Instructions.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 00_governance/UPGRADE_STATE.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 01_blueprints/ELT365_Open_Teacher_Training_System.pdf | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 01_blueprints/Open_Source_CELTA_2_0_Blueprint_Booklet.pdf | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 01_blueprints/Open_Source_CELTA_2_0_Blueprint_Editable.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/BUILDER_PROMPT.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/HUB_PAGE_COPY.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/Open_Teacher_Training_Website_Section.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/README.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/REUSE_AUDIT.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/UNIT_PAGE_TEMPLATE.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/WEBSITE_SECTION_PLAN.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/WORDPRESS_DRAFT_IMPORT_GUIDE.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/course-map.json | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/open-teacher-training-drafts.xml | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 02_website/pages-manifest.json | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/rigorous-analysis/COMPACT_PROMPT.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/rigorous-analysis/SKILL.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/rigorous-analysis/TEMPLATES.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/rigorous-analysis/agents/openai.yaml | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/rigorous-analysis/assets/icon.svg | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/INSTALL.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/INSTALL_OLD.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/SKILL.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/examples/M02-U01/channel-drafts.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/examples/M02-U01/learner-sheet.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/examples/M02-U01/master-unit.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/examples/M02-U01/teacher-guide.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/examples/M02-U01/unit.json | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/references/course-context.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/references/evidence-and-quality.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/references/method-selection.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/references/publishing-handoff.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/references/sources.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/scripts/__pycache__/validate_unit.cpython-313.pyc | OMIT_CACHE | Generated bytecode; source retained in the original ZIP. |
| 03_skills/teaching-materials-methods/scripts/test_validate_unit.py | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/scripts/validate_unit.py | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/templates/CLASSROOM_PACK.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/templates/MASTER_UNIT.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 03_skills/teaching-materials-methods/templates/REVIEW_AND_CLAIMS.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 03_skills/teaching-materials-methods/templates/unit-manifest.json | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/01_AGENT_INSTRUCTIONS.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/02_UNIT_REQUEST_TEMPLATE.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/03_REVIEW_REQUEST.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/04_FIRST_TEST.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/05_SKILL_INSTRUCTIONS_ARCHIVE.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/AGENT_ADAPTER.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/COPY_AND_PASTE.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/MODEL_SETTINGS_2026-09-13_ARCHIVE.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/MODEL_SETTINGS_2026-09-19.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/Mistral_Open_Teacher_Training_Click_Guide.pdf | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/Mistral_Teaching_Studio_Copy_and_Paste.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/PROJECT_TEACHING_SOURCES.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/SOURCES.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/START_HERE.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/TEACHING_SKILL_POINTER.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/VALIDATION.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/knowledge/PROJECT_CONTEXT.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/legacy-skill-examples/M02-U01.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/legacy-skill-references/methods.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/legacy-skill-references/quality.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/legacy-skill-references/templates.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 04_mistral_studio/optional-tools/README.md | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/optional-tools/__pycache__/timing_tool.cpython-313.pyc | OMIT_CACHE | Generated bytecode; source retained in the original ZIP. |
| 04_mistral_studio/optional-tools/parameters.json | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/optional-tools/sample-input.json | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/optional-tools/test_timing_tool.py | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/optional-tools/timing_tool.py | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/optional-tools/tool-definition.json | RETAIN | Preserved compatible domain material, example or standard; no new effectiveness claim. |
| 04_mistral_studio/workflow/BUILD_SPEC.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 05_original_deliverables/ELT365_Open_Teacher_Training_System.pdf | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Mistral_Open_Teacher_Training_Click_Guide.pdf | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Mistral_Teaching_Studio_Copy_and_Paste.md | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Mistral_Teaching_Studio_Setup_Kit.zip | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Open_Source_CELTA_2_0_Blueprint_Booklet.pdf | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Open_Source_CELTA_2_0_Blueprint_Editable.md | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Open_Teacher_Training_Website_Kit.zip | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/Open_Teacher_Training_Website_Section.md | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 05_original_deliverables/teaching-materials-methods.zip | ARCHIVE | Historical deliverable, not active v3 guidance. |
| 06_validation/SHA256SUMS.txt | REGENERATE_METADATA | Regenerated after accounting; final identity is in the external ZIP checksum. |
| 06_validation/VALIDATION_REPORT.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 06_validation/timing_tool_test.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| 06_validation/unit_validator_test.txt | REVISE | Updated v3 content, alias, data, guide or verification record. |
| CHANGELOG.md | REVISE | Updated v3 content, alias, data, guide or verification record. |
| MANIFEST.json | REGENERATE_METADATA | Regenerated after accounting; final identity is in the external ZIP checksum. |
| START_HERE.md | REVISE | Updated v3 content, alias, data, guide or verification record. |

Checksums in MANIFEST.json identify current candidate bytes. The original source ZIP is unchanged.
