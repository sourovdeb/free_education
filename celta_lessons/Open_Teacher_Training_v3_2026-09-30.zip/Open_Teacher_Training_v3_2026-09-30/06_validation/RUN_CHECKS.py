"""Run local helper tests without installing dependencies."""
from pathlib import Path
import os
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
def main():
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    suites = [
        ('03_skills/teaching-materials-methods/scripts', ['test_validate_unit', 'test_literacy']),
        ('04_mistral_studio/optional-tools', ['test_timing_tool']),
    ]
    failures = 0
    for folder, tests in suites:
        completed = subprocess.run([sys.executable, '-m', 'unittest', '-v', *tests], cwd=ROOT/folder, env=env, check=False)
        failures += completed.returncode != 0
    return 1 if failures else 0
if __name__ == '__main__':
    raise SystemExit(main())
