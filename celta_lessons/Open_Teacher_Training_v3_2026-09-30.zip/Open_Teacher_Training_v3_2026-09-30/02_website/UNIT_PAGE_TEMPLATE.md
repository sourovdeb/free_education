# Unit page template

Unit ID / version / content status / review status.
Audience / outcome / source / estimated time.

1. See the actual input.
2. Inspect a worked decision.
3. Attempt a meaningful task.
4. Compare with evidence and guidance.
5. Revise and explain a change.
6. Return to an unseen task.

Include a no-AI route, access alternatives, source anchors and next step. Separate trainee guidance from learner tasks. Templates are authoring tools, not finished lessons.
