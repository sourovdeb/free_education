# Plan pointer

Use WEBSITE_SECTION_PLAN.md. It is the canonical v3 implementation plan.
