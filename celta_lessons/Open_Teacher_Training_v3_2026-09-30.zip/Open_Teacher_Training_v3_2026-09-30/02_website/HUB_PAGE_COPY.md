# Open Teacher Training

Read with evidence. Write for people. Teach through practice.

Begin with the literacy pilot. Four complete sample packs offer texts, tasks, answers and revision. An earlier instruction-giving pack remains available. All await educator review.

The curriculum contains twelve modules and forty-eight unit specifications. Specifications describe work still to be authored. The proposed 200-hour supported route requires mentor capacity. Self-study is not observed teaching competence.

Independent project. No Cambridge affiliation. No CELTA award. No compulsory paid AI. Original source documents and private candidate records are not redistributed.
