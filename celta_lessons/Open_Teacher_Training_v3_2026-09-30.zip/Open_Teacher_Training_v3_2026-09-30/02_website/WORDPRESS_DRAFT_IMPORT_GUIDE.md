# Draft import

Use staging and a backup. This XML creates drafts. It is not a live-site updater.

On an empty staging section: WordPress → Tools → Import → WordPress. Select the XML. Assign an existing author. Do not import attachments. Check the parent tree and slugs. Review one page before publication.

On a section that already exists: do not re-import blindly. Match paths and parents first. Update by verified WordPress ID through the existing authorised editing route. Keep old slugs or record redirects. Never assume synthetic export IDs equal live IDs.

The generated content uses portable HTML inside a WordPress HTML block. The target theme may style it differently. Test mobile, keyboard, print and links. Static HTML is the fallback. No plugin or live integration was tested here.
