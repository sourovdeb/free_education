# Website files

Open site/index.html for the offline preview. Read WEBSITE_SECTION_PLAN.md before WordPress changes.
