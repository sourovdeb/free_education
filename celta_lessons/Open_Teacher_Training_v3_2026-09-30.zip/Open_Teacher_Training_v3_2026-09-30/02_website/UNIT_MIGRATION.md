# Unit identity migration

Module IDs and slugs remain unchanged. Legacy unit outlines require explicit mapping.

| Legacy ID and URL | v3 mapping | Reason |
|---|---|---|
| M02-U01 / giving-clear-instructions | M02-U01 | Existing complete example preserved. |
| M01-U01 / learner-need-to-objective | M01-U04 | Diagnosis now precedes goal setting. URL retained; page relabelled. |
| M03-U01 / checking-meaning | M03-U01 | Same teaching topic; specification refined. |
| M09-U01 / feedback-and-revision | M09-U02 | Alignment now precedes feedback. URL retained; page relabelled. |

The four literacy unit IDs are new relative to the v2 draft export. Do not use export IDs as live WordPress IDs. Inspect actual existing pages before updates.
