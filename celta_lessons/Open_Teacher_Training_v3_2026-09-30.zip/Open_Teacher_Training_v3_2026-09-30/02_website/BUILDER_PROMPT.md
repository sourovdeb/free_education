# Website agent request

# Website section v3

Keep sourovdeb.com/open-teacher-training/. Keep existing module IDs and slugs. Use ordinary WordPress Pages. Do not add an LMS, another domain, a forced account or a new scheduler for this release.

Navigation: Start, Course, Methods, Materials, Practice. Add a literacy-pilot entry within Start. Keep Portfolio and About linked through the footer. Preserve previous ELT365 posts as readings, not as duplicated course lessons.

The package provides an offline HTML hub and WordPress draft XML. The XML is a starting export, not an idempotent updater. On an existing installation, inventory current slugs and parents. Update matching pages by verified ID, retaining URLs; create only absent pages. Import the XML only on a backed-up empty staging section. Do not run it repeatedly.

Every unit contains purpose, source, task, answer guidance, revision and a next step. Use visible labels for specifications versus complete samples. Do not publish empty specification pages as finished lessons. Four literacy packs and M02-U01 are sample-complete but await educator approval.

The static hub uses no trackers, remote scripts, accounts or learner-data uploads. Textareas are not saved automatically. Learners must copy their work before leaving. This avoids silent storage claims. Expandable answers are practice aids, not secure examination controls.

Use HTML for reading and writing. Add captions and a transcript if a demonstration video is later produced. Do not use autoplay or scrolling rewards. The no-video route must contain all essential tasks. Print copies should retain the same input and instructions.

The release does not change the live site, menus, plugins, credentials or student records. Test appearance, keyboard navigation and reflow in the actual theme. Structural checks are not a WCAG conformance audit. [T1–T2]

Use the provided output before building replacements. Make one draft page work first. Keep any existing teaching records private. Verify each requested write; stop after the authorised scope.
