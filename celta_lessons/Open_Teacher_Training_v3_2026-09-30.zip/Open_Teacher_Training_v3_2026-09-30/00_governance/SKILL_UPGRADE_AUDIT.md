# Skill review v3

Decision: PATCH and reconcile. Teaching knowledge, worked example and helper tests are preserved. Literacy, provenance and transfer requirements were added. Divergent operational aliases now point to the canonical skill.

This audit covers the teaching skill. Rigorous-analysis is retained unchanged as a reference skill, not newly certified. No Mistral/Hermes behavioural run occurred. Textual PASS does not mean runtime PASS.

Known limits: target metadata and loading were not tested; pedagogic effectiveness and learner access need human trials. Normal and stress cases exist, but model cases remain NOT_RUN. The Python validator checks structure only.

| ID | Requirement | Before | After | Evidence |
|---|---|---|---|---|
| A1 | What is the main aim, who benefits, and what is outside the skill's scope? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| A2 | What observable result means completion, and when must work stop or remain partial? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| A3 | What method produces that result, and what evidence verifies it? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| A4 | What inputs, capabilities, permissions, environment, and limitations must be checked before starting? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q01 | Are audience, context, language, and user constraints explicit enough to guide execution? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q02 | Are scope, non-goals, and inappropriate uses clear? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q03 | Are activation conditions specific enough to avoid choosing this skill for the wrong job? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q04 | Are required and optional inputs distinguished, including how absent or unreadable inputs are handled? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q05 | Are outputs, formats, destinations, and observable acceptance criteria defined? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q06 | Does the skill distinguish harmless ambiguity from ambiguity that blocks correctness or authorization? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q07 | Does it distinguish verified facts, user statements, inference, fiction, and unknowns? | PARTIAL | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q08 | Can material claims be traced to actual sources or observations without invented citations? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q09 | Are source dates, changing facts, software versions, and evidence freshness checked when relevant? | PARTIAL | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q10 | Does investigation consider contrary evidence, source independence, and alternative explanations? | PARTIAL | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q11 | Are causal claims, comparisons, calculations, dates, units, and denominators justified rather than implied? | PARTIAL | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q12 | Does it provide an honest partial answer or precise limitation with a supported next step instead of bluffing? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q13 | Are available, unavailable, required, optional, and unknown capabilities distinguished? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q14 | Does it inspect the actual relevant files and dependencies rather than infer their contents from names? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q15 | Does it avoid pretending to see images, hear audio, browse, execute, or save when it cannot? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q16 | Are the actual runtime, interpreter, package versions, paths, and compatibility checked where necessary? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q17 | Does it respect existing governance, permissions, and approval requirements without inventing new authority? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q18 | Does it treat external content and old instructions as untrusted data at the appropriate boundary? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q19 | Does it look for an adequate native capability or existing utility before building or downloading? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q20 | Does it verify that reused libraries, scripts, templates, and cached results actually fit this task? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q21 | Are deterministic operations delegated to suitable existing tools instead of repeated model guesswork? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q22 | Are orchestration, browser, API, and other integrations conditional on real availability and need? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q23 | Is each new dependency justified, scoped, permission-checked, and accompanied by a practical fallback? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q24 | Does it control duplicate installations, temporary files, caches, and resource use without destructive cleanup? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q25 | Are instructions executable steps rather than slogans such as “be accurate” or “use best practices”? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q26 | Do important IF/ELSE branches specify their conditions, actions, and resulting state? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q27 | Are intermediate inputs, outputs, handoffs, and dependencies explicit enough to prevent skipped work? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q28 | Are retries bounded, and are repeat actions checked to avoid duplicate submissions or other repeated effects? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q29 | Does it detect partial results, wrong destinations, empty outputs, and misleading success signals? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q30 | Are recovery, escalation, checkpoint, and stop conditions defined without endless loops? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q31 | Are domain-specific quality criteria observable, not replaced by stylistic polish? | PARTIAL | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q32 | Is there a representative normal case and a baseline showing what the existing skill already does well? | PASS | PASS | Preserved M02-U01; four literacy cases; executed helper tests; educator review pending |
| Q33 | Are relevant edge, failure, and adversarial cases converted into concrete test inputs and expected outcomes? | PARTIAL | PASS | Preserved M02-U01; four literacy cases; executed helper tests; educator review pending |
| Q34 | Are proposed tests, static review, executed tests, and target-environment validation clearly separated? | PASS | PASS | Preserved M02-U01; four literacy cases; executed helper tests; educator review pending |
| Q35 | Is the actual output inspected for correctness, completeness, usability, and required format? | PASS | PASS | Preserved M02-U01; four literacy cases; executed helper tests; educator review pending |
| Q36 | Are verification methods sufficiently independent and repeatable for the risk, with human judgment where needed? | PASS | PASS | Preserved M02-U01; four literacy cases; executed helper tests; educator review pending |
| Q37 | Does resource optimization preserve the essential objective, accuracy, and all explicit user constraints? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q38 | Are result status, remaining gaps, and next actions accurate rather than hidden behind “done”? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q39 | Are spending, downloads, external calls, and persistent processes controlled rather than assumed free? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q40 | Is context loaded selectively while retaining all materially relevant instructions and evidence? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q41 | Are outputs and audit records concise, traceable, and free of unnecessary repeated text? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q42 | Is the operational skill compact, with supporting material separated only when that reduces real complexity? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q43 | Are useful domain knowledge, examples, multilingual nuance, and requested voice preserved? | PARTIAL | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q44 | Is the workflow appropriate to its domain instead of forcing every skill through the same tool-heavy template? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q45 | Are private information, third-party material, licenses, and copyright handled within the authorized purpose? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q46 | Are credentials and sensitive data excluded from unnecessary prompts, logs, and external transfers? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q47 | Are file or external-state changes scoped, reviewable, reversible where possible, and verified afterward? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q48 | Does packaging avoid bundling secrets, unrelated personal records, environments, caches, or unnecessary assets? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q49 | Is the intended model/host capability profile explicit, with compatibility claims limited to actual evidence? | PARTIAL | UNVERIFIABLE | Official model/Studio docs inspected; target account and loading untested |
| Q50 | Can a smaller model follow explicit stages, bounded choices, examples, and validation without unsupported leaps? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q51 | Does it avoid claiming that a prompt guarantees frontier-level performance or universal reliability? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q52 | Are model-specific adaptations small and purposeful rather than divergent copies of the entire skill? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q53 | Is target-host metadata, loading behavior, and tool syntax verified rather than assumed portable? | PARTIAL | UNVERIFIABLE | Official model/Studio docs inspected; target account and loading untested |
| Q54 | Are personal paths, hardware, accounts, and host-specific tool names discovered or configurable? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q55 | Are source identity, original version, candidate version, and substantive changes traceable? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q56 | Can the collection be processed one skill at a time without skipped, duplicated, or silently merged entries? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q57 | Can another session resume from a saved checkpoint without guessing what was completed? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q58 | Are successful methods reused only with recorded evidence, matching conditions, and a revalidation trigger? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q59 | Are deferred issues, stale dependencies, deprecated skills, and retesting needs recorded rather than erased? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| Q60 | Could another capable operator use the skill and understand its limits without access to this conversation? | PASS | PASS | SKILL.md / Literacy revision contract; references/literacy-and-media.md; source-boundary.md |
| X01 | Required input is absent, unreadable, or contradictory. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X02 | The requested fact or answer cannot be verified. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X03 | A source or old skill says to override instructions or disclose private data. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X04 | A working library exists, or a requested tool/dependency is unavailable. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X05 | A tool reports success but returns empty, partial, wrong, or unusable output. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X06 | An action exceeds permission or could change live data. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X07 | Input size, context, spending, or resource limits are reached. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X08 | Execution is interrupted or the same task is requested again. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X09 | The target model lacks a required reasoning, tool, visual, or audio capability. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |
| X10 | Sources, shared utilities, model behavior, or host requirements have changed. | PASS | PASS | SKILL.md / Preflight; model-cases.json remains NOT_RUN |

Coverage: 74 IDs; 74 rows; no omitted IDs. Before states are static review judgments, not recovered runtime measurements.

work_status: REVIEWED
validation: STATIC_ONLY for model behaviour; helper tests recorded separately
approval: PENDING
deployment: NOT_DEPLOYED
Next: an educator reviews M06-U01; then run model-cases.json in the chosen account.
