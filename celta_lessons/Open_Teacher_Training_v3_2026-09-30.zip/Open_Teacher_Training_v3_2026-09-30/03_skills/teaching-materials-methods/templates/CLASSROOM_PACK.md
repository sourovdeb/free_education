# Classroom pack — [Unit ID / version]

## Learner sheet — separate file
Title and real-world purpose:
Level/context (provisional when not assessed):
What to do, with whom, and how long:
Supplied text/dialogue/cards/data:
One example:
Tasks with stable IDs (T01, T02...):
Space or format for the response:
Self-check:
Support and extension:

Do not include the teacher's answer key on the student-facing page. Do not write placeholders such as “insert a suitable text” in a completed pack.

## Teacher guide — separate file
Outcome, prerequisites and materials:
Language analysis where relevant: meaning, form, pronunciation, use:
Stage timings and grouping:
Exact demonstration/instructions where useful:
Likely difficulty and response:
Task keys with matching IDs:
Acceptable variants and reasons:
Open-response criteria and illustrative answer:
Feedback and second attempt:
Offline and access adaptations:
Source/rights notes:

## Assessment and reflection
Observable criterion:
Evidence to collect (anonymised as appropriate):
What would not justify a claim of progress:
One useful feedback statement:
Revision to try:
Private record / public illustrative example distinction:


## v3 literacy extension
Include the source text, writing purpose, model, draft, feedback decisions and revision. Add an unseen transfer input and an independent check. Preserve access accommodations. Record teacher and learner evidence separately. This file is an authoring template, not a completed lesson.
