# Course context v3

Public name: Open Teacher Training.
Working title: Open Source CELTA 2.0.

Twelve modules remain. Forty-eight unit specifications exist. Four new literacy packs and the earlier M02-U01 pack are complete samples. Educator review is pending. The 200-hour route is planned, not delivered or accredited.

Use the package course-map.json for module IDs. Do not confuse existing ELT365 daily numbering with these unit IDs. No learner record belongs in public outputs.
