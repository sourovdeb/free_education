# Current evidence register

Use `../../../08_evidence/SOURCE_REGISTER.md`.
For a standalone installation, copy SOURCE_REGISTER.md beside this file. Keep its name.

Historical site inspections are not repeated here. No live website audit was performed for v3.
