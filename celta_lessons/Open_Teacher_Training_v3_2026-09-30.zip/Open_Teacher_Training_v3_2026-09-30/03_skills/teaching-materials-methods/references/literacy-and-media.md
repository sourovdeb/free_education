# Literacy and media

## Reading
Supply the text. Identify purpose, barriers and evidence. Model one inference or reference chain. Let the learner try another. Do not turn every lesson into repeated gist testing. Preserve unknowns and competing interpretations.

## Writing
Supply audience, purpose and input. Analyse a model’s function. Plan before drafting. Give feedback on meaning and organisation before selected language issues. Require a revision and a reason. Keep the writer’s intention.

## Chunks
Use one meaningful decision per chunk. Entry, practice and transfer have different demands. The proposed 3–6, 15–25 and 30–45 minute bands are pilot choices, not scientific constants. Increase task depth using learner evidence. Provide pause and return controls.

## Medium
Use HTML and print for reading/writing. Use a captioned demonstration when a process benefits from seeing it. Use audio for listening and rehearsal. A text transcript is not equivalent evidence of listening; audio substitution changes a reading construct. State accommodations.

## AI
Attempt, hint, retry, verify. Do not generate an assessed final answer for the learner. Record adopted and rejected suggestions. A separate unseen task assesses independence. All essential learning remains possible without paid AI.

## Sources
See package `08_evidence/SOURCE_REGISTER.md`: D2–D6, R2–R10, T1–T2. These are foundations for a candidate design, not an effectiveness certificate.
