# Source boundary

The original ZIP supplies the architecture. The glossary and centre frameworks supply terminology and examples of staged teaching. Current Cambridge documents supply official requirements. External studies inform extensions with population limits.

Keep these categories separate. Never publish private candidate records or full centre handouts without authority. Summarise only necessary instructional principles. Trace consequential claims to a source location.

Retain MFPA and explain MFPR where encountered. Distinguish meaning checks from instruction checks. In the supplied glossary, micro-teaching means monitoring support; in rehearsal contexts the word can mean something else. Label which sense applies.

Fixed minutes, word encounters and talk ratios are local heuristics unless separately justified. The centre summary explicitly allows adaptation. The source does not justify describing all CELTA as pre-internet.

Missing sources remain missing. The internal page link was unavailable; the novel note is progress metadata. Neither is treated as instructional evidence.
