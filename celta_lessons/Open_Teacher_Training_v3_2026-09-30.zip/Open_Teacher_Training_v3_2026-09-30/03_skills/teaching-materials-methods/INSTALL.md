# Installation

This package is a candidate. No installation occurred here.

Copy this skill folder into the intended host’s supported skills location. Check that the host can read its references and templates. Test one request. Do not copy the archive as an active skill.

For Mistral Studio, consult the v3 setup guide. For a host without file access, supply SKILL.md plus only the relevant reference. Do not claim that a skill attachment grants execution or publishing access.
