"""Executed structural regression tests; no model calls."""
import copy
import json
from pathlib import Path
import unittest
from validate_unit import validate
ROOT = Path(__file__).resolve().parents[3]
PACK = ROOT / '07_literacy_pilot' / 'M06-U01'
class LiteracyTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((PACK / 'unit.json').read_text())
    def test_complete_v2_pack(self):
        self.assertEqual(validate(self.data, PACK), [])
    def test_all_pilot_packs(self):
        for path in (ROOT / '07_literacy_pilot').glob('*/unit.json'):
            self.assertEqual(validate(json.loads(path.read_text()), path.parent), [])
    def test_missing_literacy(self):
        del self.data['literacy']
        self.assertTrue(any('literacy' in x for x in validate(self.data)))
    def test_blank_reading_input(self):
        self.data['literacy']['reading_input'] = ''
        self.assertTrue(any('reading_input' in x for x in validate(self.data)))
    def test_missing_transfer(self):
        self.data['literacy']['transfer_input'] = ''
        self.assertTrue(any('transfer_input' in x for x in validate(self.data)))
    def test_repeated_transfer_input(self):
        self.data['literacy']['transfer_input'] = self.data['literacy']['reading_input']
        self.assertTrue(any('differ' in x for x in validate(self.data)))
    def test_independent_ai(self):
        self.data['literacy']['independent_ai_allowed'] = True
        self.assertTrue(any('independent_ai_allowed' in x for x in validate(self.data)))
    def test_ai_policy(self):
        self.data['literacy']['ai_policy'] = 'give_answers'
        self.assertTrue(any('ai_policy' in x for x in validate(self.data)))
    def test_bool_not_false(self):
        self.data['literacy']['independent_ai_allowed'] = 0
        self.assertTrue(any('independent_ai_allowed' in x for x in validate(self.data)))
    def test_blank_teacher_evidence(self):
        self.data['literacy']['teacher_evidence'] = ''
        self.assertTrue(any('teacher_evidence' in x for x in validate(self.data)))
    def test_blank_writing_task(self):
        self.data['literacy']['writing_output'] = ''
        self.assertTrue(any('writing_output' in x for x in validate(self.data)))
    def test_unrecognised_status(self):
        self.data['literacy']['content_status'] = 'deployed'
        self.assertTrue(any('content_status' in x for x in validate(self.data)))
if __name__ == '__main__': unittest.main()
