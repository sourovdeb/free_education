# Historical alias

Use INSTALL.md in this folder. The previous installation text is preserved in the original deliverables archive.
