# Asset register

Diagrams are editable SVGs. They represent project design, not measured results. Their text is also available in HTML and the blueprint.

reading-listening-illustration.png is a cropped book-and-headphones illustration from an AI-generated image. The complete generated poster was rejected because it contained unsupported comparison claims. Only the text-free icon is retained. It is decorative; substantive meaning remains in text.

No private portraits, source-document logos or learner records are included. No commissioned video or audio was produced. Video scripts are production plans, not finished recordings.
