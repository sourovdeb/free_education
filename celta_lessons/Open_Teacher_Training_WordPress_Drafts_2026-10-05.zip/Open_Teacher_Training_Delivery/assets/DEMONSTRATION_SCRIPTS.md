# Demonstration scripts

No video or audio was rendered. Captions must be checked after production. All notices are fictional teaching inputs.

## M06-U01 — Read for evidence

Proposed 75-second demonstration. Learners can pause.

| Time | Show | On-screen prompt |
|---|---|---|
| 0–10s | Title and one source paragraph | What does the source actually say? |
| 10–25s | Highlight the model’s evidence | Claim: Entry costs nothing. Decision: supported. Evidence: paragraph 1 says there is no entry charge. This does not mean visitors can take books home. |
| 25–40s | Show a task without its key | A: Announce a permanent library. B: Explain a trial reading room. C: Sell donated books. |
| 40–55s | Reveal the supporting evidence | B. Paragraphs 1 and 4 describe a trial without a continuation decision. |
| 55–65s | Show one revision decision | Preserve meaning. Explain a change. |
| 65–75s | Link to the full text task | Read, write and retry. |

Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.

LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.

## M06-U02 — Check a summary

Proposed 75-second demonstration. Learners can pause.

| Time | Show | On-screen prompt |
|---|---|---|
| 0–10s | Title and one source paragraph | What does the source actually say? |
| 10–25s | Highlight the model’s evidence | A claim about score changes is supported by A[1]. A claim about writing causing improvement is not supported. A[2] and B[3] provide alternative explanations. |
| 25–40s | Show a task without its key | How many attended? How many completed both quizzes? Why does the difference matter? |
| 40–55s | Reveal the supporting evidence | Eighteen attended; fourteen completed both. The score change describes completers, not necessarily every attendee. |
| 55–65s | Show one revision decision | Preserve meaning. Explain a change. |
| 65–75s | Link to the full text task | Read, write and retry. |

Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.

LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.

## M07-U01 — Write for a reader

Proposed 75-second demonstration. Learners can pause.

| Time | Show | On-screen prompt |
|---|---|---|
| 0–10s | Title and one source paragraph | What does the source actually say? |
| 10–25s | Highlight the model’s evidence | The opening identifies the session. The next sentence states the goal. The questions request missing information. The final sentence explains why confirmation matters. |
| 25–40s | Show a task without its key | Mark the session, learning goal, missing information and confirmation request. Which details come from the notice? |
| 40–55s | Reveal the supporting evidence | The Saturday time and booking rule come from the notice. The goal, access question and travel reason belong to the writer’s situation. The notice does not guarantee access. |
| 55–65s | Show one revision decision | Preserve meaning. Explain a change. |
| 65–75s | Link to the full text task | Read, write and retry. |

Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.

LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.

## M07-U02 — Revise without losing meaning

Proposed 75-second demonstration. Learners can pause.

| Time | Show | On-screen prompt |
|---|---|---|
| 0–10s | Title and one source paragraph | What does the source actually say? |
| 10–25s | Highlight the model’s evidence | Accept A because the reader needs times. Reject B because access is unconfirmed. Adapt E into a choice: paper or laptop. Feedback is a proposal, not an authority. |
| 25–40s | Show a task without its key | Identify three conflicts between the intention and draft. Distinguish missing facts from invented promises. |
| 40–55s | Reveal the supporting evidence | Missing: times, capacity, booking, equipment options. Invented: guaranteed writing success and certificates. “Everyone can come” ignores capacity and unconfirmed access. |
| 55–65s | Show one revision decision | Preserve meaning. Explain a change. |
| 65–75s | Link to the full text task | Read, write and retry. |

Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.

LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.

