# Teacher guide: M07-U02

Teach accept, adapt and reject decisions using reader evidence.

Training time: 35 minutes. Example classroom time: 30 minutes.

## Worked decision
Accept A because the reader needs times. Reject B because access is unconfirmed. Adapt E into a choice: paper or laptop. Feedback is a proposal, not an authority.

## Answers
### T1
Missing: times, capacity, booking, equipment options. Invented: guaranteed writing success and certificates. “Everyone can come” ignores capacity and unconfirmed access.

### T2
A accept; B reject; C accept; D reject; E accept/adapt; F accept. Alternatives need a defensible explanation. Do not replace author judgement with a rigid label test.

### T3
A suitable invitation states known details, describes practice and peer response, and asks people needing access information to contact the organiser before booking. It does not promise accessibility or certificates.

### T4
Evidence should show what changed and why. Reader success matters more than whether the AI’s preferred phrasing was used.

## Sample response
Join our writing workshop this Saturday from 10:00 to 11:30. Beginners are welcome, and the session is free. We have ten places, so please book before coming. Bring paper or a laptop, whichever suits you. During the workshop, you will practise writing and exchange responses with another participant. This is a practice session, not a certificate course. Step-free access has not yet been confirmed. Please contact the organiser before booking if you need access information. We will check the room details rather than promise something we cannot verify. We look forward to hearing your ideas.

## Feedback
Review intention and content first. Check factual accuracy next. Then improve organisation and language. Keep the original and revised versions together.

## Adaptation
Offer a decision table. Read suggestions aloud if needed. Allow additional planning time. Do not mark assistive access as AI dependence.

## Independent return
Without AI, write a 70–100 word correction. Preserve choice, timing, capacity and the recording rule. Explain two rejected changes.

State Thursday 17:00–18:00, six booked places, choice to speak or listen, no recording. Reject Friday and certificate claims. Do not infer any other participation requirement.

## Criteria
- Intention: preserves purpose and audience.
- Truth: corrects invention and uncertainty.
- Revision: responds to reader needs.
- Agency: explains accepted and rejected suggestions.