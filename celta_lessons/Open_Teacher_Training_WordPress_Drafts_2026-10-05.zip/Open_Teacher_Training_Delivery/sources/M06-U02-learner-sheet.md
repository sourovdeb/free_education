# M06-U02 — Check a summary

Read → attempt → explain → revise.

## Two accounts, one claim

SOURCE A — Learning-centre trial note, 6 May

[1] Eighteen volunteers attended four lunchtime reading sessions. The sessions combined short articles, discussion and a ten-minute writing task. Fourteen volunteers completed both the opening and closing quizzes. Their average scores rose from six to eight correct answers out of ten.

[2] The quizzes used different articles. Staff did not check whether those articles had the same difficulty. There was no comparison group. Six volunteers said discussion helped them. Others did not answer that question. The centre will repeat the trial before making a decision about expansion.

SOURCE B — Coordinator’s email, 8 May

[3] We are pleased that participants returned. The quiz results are encouraging, but they cannot show which activity caused the change. Some volunteers had attended English classes elsewhere during the same month. We have not tested whether improvements last.

[4] Next time, we will record attendance and ask about other learning. We also need a task using an unfamiliar article. The current results should not be advertised as proof that ten minutes of writing improves everyone’s reading.

## T1 — Identify the sample.

How many attended? How many completed both quizzes? Why does the difference matter?

## T2 — Audit the summary.

Flawed summary: “Eighteen learners proved that ten minutes of writing causes a lasting reading improvement. Everyone preferred discussion, so the centre will expand immediately.” Underline unsupported claims.

## T3 — Rewrite with attribution.

Write 70–100 words. State the result, sample and two limits. Name the source of one caution.

## T4 — Explain an uncertainty.

Tell a partner which finding would change your confidence. Then write one follow-up question.

Original fictional input. Review pending.
