# M07-U02 — Return task

Use a new context. No AI assistance. Record other support.

A community group plans a free listening circle on Thursday from 17:00 to 18:00. Six places require booking. Attendees can speak or listen. Recording is not allowed. The draft says: “Everyone must speak. Bring your phone and record the discussion. Arrive sometime after five.” A suggested rewrite adds a certificate and changes the meeting to Friday.

Without AI, write a 70–100 word correction. Preserve choice, timing, capacity and the recording rule. Explain two rejected changes.

## Teacher key
State Thursday 17:00–18:00, six booked places, choice to speak or listen, no recording. Reject Friday and certificate claims. Do not infer any other participation requirement.
