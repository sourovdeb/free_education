# M06-U02 — Return task

Use a new context. No AI assistance. Record other support.

A library tried a reminder message for a writing group. Twenty members received it. Twelve came that week, compared with eight the previous week. It rained heavily during the earlier meeting. The library did not ask whether members read the message. The organiser wrote: “Attendance rose, but we cannot identify the cause from these two meetings.”

Without AI, correct this claim: “The reminder made four extra people attend.” Write 50–70 words preserving the observed change and two limitations.

## Teacher key
Attendance changed from eight to twelve. This does not establish four specific additional people or a reminder effect. Weather differed; receipt/reading was unverified; no comparison group or repeated matched observations.
