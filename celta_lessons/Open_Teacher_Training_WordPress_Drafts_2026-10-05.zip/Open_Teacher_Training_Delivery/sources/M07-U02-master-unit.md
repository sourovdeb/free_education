# M07-U02 — Revise without losing meaning

Version 3.0.0. Complete sample; educator review pending.

## Context

Training: 35 minutes. Classroom illustration: 30 minutes. Estimates only.

Level: B1–B2, provisional. Diagnose before use.

Teacher outcome: Teach accept, adapt and reject decisions using reader evidence.

Learner outcome: Evaluate feedback and revise a message while preserving its intention.

## Input — The workshop invitation

Original fictional teaching material. Not a real service notice.

WRITER’S INTENTION

Invite beginners to a free Saturday writing workshop. It starts at 10:00 and ends at 11:30. Ten places are available. Booking is required. Participants may bring paper or a laptop. The organiser has not confirmed step-free access. The workshop offers practice and peer response, not certificates.

FIRST DRAFT

Come to our writing thing on Saturday. Everyone can come and there is lots of time. Bring something. You will become a great writer. You can get a certificate. Tell people.

READER RESPONSE

“What time does it start? Do I need to book? I use a wheelchair. I cannot tell whether I can enter the room. Do I need a laptop?”

SUGGESTIONS FROM AN ILLUSTRATIVE AI REVIEW

A. Add the start and finish times.
B. Say that the room is fully accessible.
C. Remove the certificate promise.
D. Replace the invitation with an academic essay.
E. Explain what people can bring.
F. Say that places require booking.

## Worked decision

Accept A because the reader needs times. Reject B because access is unconfirmed. Adapt E into a choice: paper or laptop. Feedback is a proposal, not an authority.

## Sequence

- 5 minutes: Diagnose and state the purpose.
- 7 minutes: Model one decision.
- 10 minutes: Attempt the task.
- 8 minutes: Compare evidence and revise.
- 5 minutes: Check independently and plan a return.

## T1 — Find meaning problems.

Identify three conflicts between the intention and draft. Distinguish missing facts from invented promises.

Answer guidance: Missing: times, capacity, booking, equipment options. Invented: guaranteed writing success and certificates. “Everyone can come” ignores capacity and unconfirmed access.

## T2 — Judge each suggestion.

Mark Accept, Adapt or Reject. Give a reason grounded in intention or reader response.

Answer guidance: A accept; B reject; C accept; D reject; E accept/adapt; F accept. Alternatives need a defensible explanation. Do not replace author judgement with a rigid label test.

## T3 — Write the revision.

Write 90–120 words. Preserve the invitation. Include time, capacity, booking and equipment. Handle access uncertainty without inventing an answer.

Answer guidance: A suitable invitation states known details, describes practice and peer response, and asks people needing access information to contact the organiser before booking. It does not promise accessibility or certificates.

## T4 — Record the decisions.

Explain one acceptance, one adaptation and one rejection. Ask a reader to answer the original questions.

Answer guidance: Evidence should show what changed and why. Reader success matters more than whether the AI’s preferred phrasing was used.

## One possible response

Join our writing workshop this Saturday from 10:00 to 11:30. Beginners are welcome, and the session is free. We have ten places, so please book before coming. Bring paper or a laptop, whichever suits you. During the workshop, you will practise writing and exchange responses with another participant. This is a practice session, not a certificate course. Step-free access has not yet been confirmed. Please contact the organiser before booking if you need access information. We will check the room details rather than promise something we cannot verify. We look forward to hearing your ideas.

Exact wording is not prescribed.

## Feedback

Review intention and content first. Check factual accuracy next. Then improve organisation and language. Keep the original and revised versions together.

## Access

Offer a decision table. Read suggestions aloud if needed. Allow additional planning time. Do not mark assistive access as AI dependence.

## Return without AI

Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.

A community group plans a free listening circle on Thursday from 17:00 to 18:00. Six places require booking. Attendees can speak or listen. Recording is not allowed. The draft says: “Everyone must speak. Bring your phone and record the discussion. Arrive sometime after five.” A suggested rewrite adds a certificate and changes the meeting to Friday.

Without AI, write a 70–100 word correction. Preserve choice, timing, capacity and the recording rule. Explain two rejected changes.

Answer guidance: State Thursday 17:00–18:00, six booked places, choice to speak or listen, no recording. Reject Friday and certificate claims. Do not infer any other participation requirement.

## Criteria

- Intention: preserves purpose and audience.
- Truth: corrects invention and uncertainty.
- Revision: responds to reader needs.
- Agency: explains accepted and rejected suggestions.

## Source and review

Source anchors: D5, R4, R6, R8. Local input is original fiction. No learner trial or educator approval occurred.
