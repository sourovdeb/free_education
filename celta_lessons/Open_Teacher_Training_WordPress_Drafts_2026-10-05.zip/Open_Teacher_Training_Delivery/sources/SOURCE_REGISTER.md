# Sources and boundaries

Reviewed 2026-09-30. Source descriptions are not outcome claims.

## C1 — Cambridge: CELTA syllabus and assessment guidelines

Date: July 2024. Type: official specification.

Location: pp. 4–5, 8–11, 13–18.

Finding: Covers adult literacy, writing processes, online classrooms and digital materials. Includes five integrated topic areas.

Limit: A specification does not establish implementation quality. No course-equivalence assessment was performed.

Proposed response: Retain all five areas. Extend literacy practice and digital evaluation.

https://www.cambridgeenglish.org/Images/21816-celta-syllabus.pdf

## C2 — Cambridge: CELTA course requirements

Date: 2026-09-30. Type: official requirements.

Location: Course in detail; assessment.

Finding: At least 120 tutor-contact hours; allow 80 additional learning hours. Six assessed teaching hours and six directed-observation hours. Online and mixed formats are offered.

Limit: Our 200-hour estimate is not 120 hours of tutor contact. Hours alone cannot show equivalent provision.

Proposed response: Separate self-study, mentorship, rehearsal and real teaching.

https://www.cambridgeenglish.org/educators-organisations/professional-development/teaching-qualifications/celta/about/

## C3 — Cambridge: generative AI guidance

Date: Accessed 2026-09-30. Type: official guidance.

Location: pp. 1–2.

Finding: Addresses AI use in assessed work, attribution and centre guidance.

Limit: Does not endorse this project or validate AI outputs.

Proposed response: Teach attribution and verification. Never claim AI is absent from CELTA.

https://www.cambridgeenglish.org/Images/745146-guidance-for-use-of-generative-ai-tools-on-celta-and-delta.pdf

## D1 — Supplied candidate record booklet

Date: C1/2026. Type: user-supplied private record.

Location: Course requirements; candidate responsibilities; assessment overview.

Finding: Confirms teaching practice, assignments, feedback and portfolio responsibilities.

Limit: Contains personal records. Not reproduced or linked publicly. No appeal or grade review undertaken.

Proposed response: Use assessment structure only. Keep personal records outside the release.

Source supplied by the owner. Original not redistributed.

## D2 — Neil Anderson: glossary of CELTA terms

Date: February 2008. Type: user-supplied glossary.

Location: pp. 1–7; supplied A_GLOSSARY_OF_COMMON_CELTA_TERMS2.docx.

Finding: Prioritises teaching over terminology. Defines MFPA, feedback, meaning checks and instruction checks.

Limit: Local catchphrases and numerical rules are not universal empirical laws.

Proposed response: Preserve distinctions. Qualify fixed encounter counts, time caps and talk ratios.

Source supplied by the owner. Original not redistributed.

## D3 — Blue Lesson Frameworks: summary

Date: Supplied folder; date not established. Type: centre guidance.

Location: Framework summary; writing sequence.

Finding: States frameworks can be adapted. Writing includes editing, correction and publishing.

Limit: Centre guidance is not identical to Cambridge regulations.

Proposed response: Adapt, rather than reject, the sequence.

Source supplied by the owner. Original not redistributed.

## D4 — Simon Brooks: Reading guidance

Date: 2016. Type: centre guidance.

Location: 45-minute template; detailed-reading stage.

Finding: Includes purposeful reading, detailed comprehension and text-based justification.

Limit: Timings and vocabulary counts belong to an illustrative template.

Proposed response: Add cross-source checking and independent transfer.

Source supplied by the owner. Original not redistributed.

## D5 — Simon Brooks: Writing guidance

Date: 2016. Type: centre guidance.

Location: Single-page table; visually inspected.

Finding: Uses model texts, genre analysis, planning, supported writing and reader feedback.

Limit: The example is a 45-minute lesson, not the full writing curriculum.

Proposed response: Extend drafting into documented revision and delayed transfer.

Source supplied by the owner. Original not redistributed.

## D6 — Other supplied lesson frameworks

Date: 2016 where marked. Type: centre guidance.

Location: Seven remaining documents: Listening; Speaking; grammar text; lexis text; functional language text; situational lexis; Stage names & Aims.

Finding: Listening, speaking, grammar, lexis and functions connect context, comprehension, language analysis, practice and feedback. Stage-name guidance distinguishes clarification from whole-lesson frameworks.

Limit: Text inspected for all seven. Not every layout was visually inspected.

Proposed response: Retain these foundations across modules. Track source terminology rather than silently harmonising it.

Source supplied by the owner. Original not redistributed.

## R1 — OECD: PISA 2025 Results, Volume I

Date: 8 September 2026. Type: international assessment report.

Location: Overview and key findings.

Finding: Reports declining reading performance across OECD countries. Reading scores fell 28 points between 2015 and 2025.

Limit: Participants are 15-year-olds. Associations do not establish technological causation or adult language-learning effects.

Proposed response: Prioritise comprehension and evidence evaluation; do not stereotype a generation.

https://www.oecd.org/en/publications/pisa-2025-results-volume-i_73451bc5-en.html

## R2 — Clinton: Reading from paper compared to screens

Date: 2019. Type: systematic review and meta-analysis.

Location: Abstract; moderator results.

Finding: Across 33 studies, paper showed a comprehension advantage, especially for expository texts; narrative differences were not clear.

Limit: Results vary by task and design. Not proof that digital learning cannot work.

Proposed response: Offer print and screen routes. Preserve text and purposeful rereading.

https://onlinelibrary.wiley.com/doi/full/10.1111/1467-9817.12269

## R3 — Rey et al.: A meta-analysis of the segmenting effect

Date: 2019. Type: meta-analysis.

Location: Abstract; 56 investigations.

Finding: Meaningful, coherent segments supported retention and transfer in multimedia learning.

Limit: Does not establish a universal five-minute lesson or an eight-second attention span.

Proposed response: Segment by meaning. Let users control pacing. Build longer practice afterwards.

https://doi.org/10.1007/s10648-018-9456-4

## R4 — IES: Teaching Secondary Students to Write Effectively

Date: 2016; revised 2019. Type: evidence-based practice guide.

Location: Recommendations 1–3.

Finding: Recommends Model–Practice–Reflect, integrated reading/writing and using assessment to guide writing instruction.

Limit: Grades 6–12. Adaptation to adult ELT is a design inference, not a demonstrated effect here.

Proposed response: Include models, drafts, feedback decisions and revision.

https://ies.ed.gov/ncee/wwc/practiceguide/22

## R5 — Agarwal, Nunes & Blunt: Retrieval practice in classrooms

Date: 2021. Type: systematic review.

Location: Abstract; 50 experiments.

Finding: Classroom experiments generally support retrieval practice across varied settings.

Limit: Most included research came from WEIRD settings. Recall alone does not establish writing transfer.

Proposed response: Add return tasks and changed-context performance, not only recognition quizzes.

https://doi.org/10.1007/s10648-021-09595-9

## R6 — Bastani et al.: Generative AI without guardrails can harm learning

Date: 2025. Type: randomised field experiment.

Location: Abstract; discussion.

Finding: Nearly 1,000 Turkish high-school maths learners received different GPT-4 interfaces. Unrestricted assistance improved practice but reduced later unassisted performance; teacher-designed hints mitigated this harm.

Limit: One school, maths, short-term outcomes, 2023 deployment. Not direct evidence about adult ELT writing.

Proposed response: Attempt first. Use hints. Assess later without AI.

https://doi.org/10.1073/pnas.2422633122

## R7 — Kestin et al.: AI tutoring compared with active learning

Date: 2025. Type: randomised crossover trial.

Location: Methods; results; discussion.

Finding: A designed AI tutor improved short-term learning relative to an active-learning class in introductory college physics.

Limit: Two lesson topics, one university context. Not evidence that any chatbot replaces teachers.

Proposed response: Test purpose-built tutoring rather than rejecting or celebrating AI wholesale.

https://doi.org/10.1038/s41598-025-97652-6

## R8 — UNESCO: AI competency framework for teachers

Date: 2024. Type: competency framework.

Location: Framework overview.

Finding: Organises teacher AI competence around human agency, ethics, foundations, pedagogy and professional learning.

Limit: A normative framework, not a trial proving learning gains.

Proposed response: Teach judgement and privacy alongside prompts and tools.

https://www.iicba.unesco.org/fr/africa-education-knowledge-platform/ai-competency-framework-teachers

## R9 — Council of Europe: CEFR Companion Volume

Date: 2020. Type: language-education framework.

Location: Publication overview.

Finding: Extends descriptors to mediation, online interaction and plurilingual competence.

Limit: No formal CEFR alignment or level validation was performed for these materials.

Proposed response: Use observable tasks and provisional level labels.

https://www.coe.int/en/web/education/newsroom/-/asset_publisher/fkf5o6A9gZZK/content/id/63912058

## R10 — Council of Europe: Online interaction in the classroom

Date: Accessed 2026-09-30. Type: professional guidance.

Location: Overview.

Finding: Connects synchronous and asynchronous online interaction with action-oriented language tasks.

Limit: Guidance is not evidence for any one platform.

Proposed response: Use reader replies and collaboration, not engagement clicks.

https://www.coe.int/en/web/common-european-framework-reference-languages/online-interaction-in-the-classroom

## T1 — W3C: WCAG 2 overview

Date: Accessed 2026-09-30. Type: accessibility standard overview.

Location: What is in WCAG; conformance.

Finding: WCAG 2.2 provides testable accessibility criteria for web content.

Limit: This release has not undergone a full accessibility conformance audit.

Proposed response: Test keyboard access, contrast, reflow and text alternatives.

https://www.w3.org/WAI/standards-guidelines/wcag/

## T2 — W3C: Use Clear Words

Date: 2021; web presentation 2022. Type: supplemental accessibility guidance.

Location: What to do; getting started.

Finding: Recommends explaining unfamiliar terminology and using clear labels.

Limit: Supplemental guidance is not itself a WCAG conformance requirement.

Proposed response: Explain terms in context; retain disciplinary precision.

https://www.w3.org/WAI/WCAG2/supplemental/patterns/o3p01-clear-words/

## T3 — Mistral: Create a Skill in Studio

Date: Accessed 2026-09-30. Type: official product documentation.

Location: Steps 1–8.

Finding: Skills store activation conditions, procedures and supporting files. Visibility, versioning and tests are separate concerns.

Limit: Account UI and availability were not tested. September screenshots may differ.

Proposed response: Use one canonical skill and a thin adapter.

https://docs.mistral.ai/getting-started/quickstarts/studio/create-skill

## T4 — Mistral: Small 4 model card

Date: 16 March 2026; checked 2026-09-30. Type: official model specification.

Location: Model card.

Finding: Lists mistral-small-2603, structured outputs and tool support. It has 119B total parameters, not a laptop-sized 6.5B model.

Limit: Capabilities do not certify teaching quality. No target-model benchmark ran.

Proposed response: Hosted drafting candidate; test with the included cases.

https://docs.mistral.ai/models/mistral-small-4-0-26-03

## T5 — Mistral: Ministral 3 3B model card

Date: December 2025; checked 2026-09-30. Type: official model specification.

Location: Model card.

Finding: Documents a small text-and-vision model.

Limit: Local memory and runtime depend on quantisation and context. No installation or speed test occurred.

Proposed response: Optional staged local route; never assign sole factual approval.

https://docs.mistral.ai/models/model-cards/ministral-3-3b-25-12

## T6 — Mistral: Durable agents

Date: Accessed 2026-09-30. Type: official developer documentation.

Location: Overview.

Finding: Describes workflow-backed agent state, activities and tool integration.

Limit: Instructions and diagrams are not a deployed worker.

Proposed response: Keep automation optional and separate from first-unit use.

https://docs.mistral.ai/studio/workflows/building-workflows/durable_agents

