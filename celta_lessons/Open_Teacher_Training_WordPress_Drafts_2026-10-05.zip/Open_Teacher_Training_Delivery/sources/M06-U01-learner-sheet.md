# M06-U01 — Read for evidence

Read → attempt → explain → revise.

## The reading room notice

[1] The Harbour Learning Centre is trying a reading room for four Saturdays in November. The room will open from 10:00 until 12:00. There is no entry charge. Visitors can borrow books during the session, but they must return them before leaving.

[2] Adults can attend alone. Children under twelve need an adult with them. The notice does not give a rule for older children. Twelve seats can be reserved by email. The centre will keep four other seats for people who arrive without booking.

[3] Visitors may read their own books or choose from the centre’s collection. They may use a phone to look up a word, but calls must be taken outside. Headphones are needed for audio. There will be a quiet area and a table for discussion.

[4] After the trial, staff will ask visitors what worked. They have not decided whether the room will continue. A local company has offered to donate books, but no donation has arrived yet.

## T1 — Choose the main purpose.

A: Announce a permanent library. B: Explain a trial reading room. C: Sell donated books.

## T2 — Classify each statement.

Write Supported, Contradicted, or Not stated. Cite a paragraph. A: All seats need booking. B: Visitors can bring their own books. C: The room will continue in December. D: Books can be taken home. E: A book donation has arrived. F: Visitors aged thirteen need an adult.

## T3 — Explain one inference.

Why might the centre keep some seats unreserved? Give one possible explanation. Mark it as an inference.

## T4 — Write to a visitor.

Write 50–70 words for a friend. Include a booking fact, a borrowing rule and one uncertainty.

Original fictional input. Review pending.
