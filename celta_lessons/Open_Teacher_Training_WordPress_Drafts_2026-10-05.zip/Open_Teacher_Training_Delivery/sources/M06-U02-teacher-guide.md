# Teacher guide: M06-U02

Model source comparison without presenting fluent summaries as evidence.

Training time: 35 minutes. Example classroom time: 25 minutes.

## Worked decision
A claim about score changes is supported by A[1]. A claim about writing causing improvement is not supported. A[2] and B[3] provide alternative explanations.

## Answers
### T1
Eighteen attended; fourteen completed both. The score change describes completers, not necessarily every attendee.

### T2
Eighteen completers is wrong; only fourteen completed both. “Proved”, “causes”, “lasting”, “everyone” and “expand immediately” are unsupported or contradicted. A[2] and B[3–4] explain why.

### T3
Include fourteen completers, six-to-eight quiz result, unequal article difficulty/no comparison/other learning/no follow-up. Attribute the coordinator’s caution. Do not imply the intervention failed or succeeded causally.

### T4
Accept a matched comparison, comparable quiz difficulty or delayed unfamiliar-text task. An additional satisfaction survey alone cannot establish causation.

## Sample response
The centre reports that fourteen volunteers completed both quizzes, with average scores rising from six to eight out of ten. Eighteen people attended the sessions overall. The result does not establish what caused the change: article difficulty was not matched and there was no comparison group. The coordinator also notes that some people attended other English classes. No follow-up test established whether the change lasted. The centre plans another trial before deciding whether to expand.

## Feedback
Ask which source supports each clause. Keep a useful result without overclaiming. Do not replace unjustified optimism with unjustified pessimism.

## Adaptation
Read sources separately, then together. Explain average, comparison group and lasting. Allow first-language planning. Reduce output length before deleting source limitations.

## Independent return
Without AI, correct this claim: “The reminder made four extra people attend.” Write 50–70 words preserving the observed change and two limitations.

Attendance changed from eight to twelve. This does not establish four specific additional people or a reminder effect. Weather differed; receipt/reading was unverified; no comparison group or repeated matched observations.

## Criteria
- Accuracy: preserves the sample and result.
- Attribution: locates the source of a caution.
- Qualification: separates association and cause.
- Independence: explains the rewrite without AI.