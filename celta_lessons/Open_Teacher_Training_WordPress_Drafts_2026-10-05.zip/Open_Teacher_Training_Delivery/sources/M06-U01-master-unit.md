# M06-U01 — Read for evidence

Version 3.0.0. Complete sample; educator review pending.

## Context

Training: 30 minutes. Classroom illustration: 20 minutes. Estimates only.

Level: A2–B1, provisional. Diagnose before use.

Teacher outcome: Teach learners to justify a reading decision before receiving an answer.

Learner outcome: Distinguish stated facts, contradictions and information not supplied.

## Input — The reading room notice

Original fictional teaching material. Not a real service notice.

[1] The Harbour Learning Centre is trying a reading room for four Saturdays in November. The room will open from 10:00 until 12:00. There is no entry charge. Visitors can borrow books during the session, but they must return them before leaving.

[2] Adults can attend alone. Children under twelve need an adult with them. The notice does not give a rule for older children. Twelve seats can be reserved by email. The centre will keep four other seats for people who arrive without booking.

[3] Visitors may read their own books or choose from the centre’s collection. They may use a phone to look up a word, but calls must be taken outside. Headphones are needed for audio. There will be a quiet area and a table for discussion.

[4] After the trial, staff will ask visitors what worked. They have not decided whether the room will continue. A local company has offered to donate books, but no donation has arrived yet.

## Worked decision

Claim: Entry costs nothing. Decision: supported. Evidence: paragraph 1 says there is no entry charge. This does not mean visitors can take books home.

## Sequence

- 4 minutes: Diagnose and state the purpose.
- 6 minutes: Model one decision.
- 8 minutes: Attempt the task.
- 7 minutes: Compare evidence and revise.
- 5 minutes: Check independently and plan a return.

## T1 — Choose the main purpose.

A: Announce a permanent library. B: Explain a trial reading room. C: Sell donated books.

Answer guidance: B. Paragraphs 1 and 4 describe a trial without a continuation decision.

## T2 — Classify each statement.

Write Supported, Contradicted, or Not stated. Cite a paragraph. A: All seats need booking. B: Visitors can bring their own books. C: The room will continue in December. D: Books can be taken home. E: A book donation has arrived. F: Visitors aged thirteen need an adult.

Answer guidance: A Contradicted [2]; four seats do not need booking. B Supported [3]. C Not stated [4]; undecided. D Contradicted [1]; return books before leaving. E Contradicted [4]. F Not stated [2]; the notice leaves older children unspecified.

## T3 — Explain one inference.

Why might the centre keep some seats unreserved? Give one possible explanation. Mark it as an inference.

Answer guidance: Possible: to include visitors who could not book. This is plausible, not directly stated. Other explanations need a logical link to paragraph 2.

## T4 — Write to a visitor.

Write 50–70 words for a friend. Include a booking fact, a borrowing rule and one uncertainty.

Answer guidance: Check all three functions. Do not invent December dates or a rule for thirteen-year-olds. Exact wording varies.

## One possible response

The centre is trying a reading room on four Saturdays in November. You can reserve a seat by email, but four seats are kept for people without bookings. Books must stay at the centre. You can bring your own book. Staff have not decided whether the room will continue, so check before planning a December visit.

Exact wording is not prescribed.

## Feedback

Ask the learner to locate evidence. Then ask what it rules out. Give the key after that attempt. Correct the reasoning, not just the label.

## Access

Gloss trial, reserve and donate when needed. Offer numbered paragraphs and print. Let learners answer orally before writing. Record oral support when interpreting writing evidence.

## Return without AI

Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.

The Riverside Centre will run a repair workshop on three Thursdays in March. Sessions start at 18:00 and finish at 19:30. Entry is free, but replacement parts are charged separately. Eight places must be booked by telephone. There are no walk-in places. Participants should bring one small item. Electrical appliances are not accepted. Tools stay at the centre. Staff will review attendance before deciding whether to add April sessions.

Without AI, classify these claims: every repair costs nothing; all places require booking; April sessions are confirmed. Then write a 40–60 word message explaining one rule and one uncertainty.

Answer guidance: Every repair costs nothing: contradicted; parts cost money. All places require booking: supported. April sessions confirmed: not stated. Message must preserve those distinctions.

## Criteria

- Evidence: links claims to relevant wording.
- Distinctions: separates support, contradiction and absence.
- Writing: includes the requested facts without invention.
- Revision: explains one corrected interpretation.

## Source and review

Source anchors: D2, D4, R2, R9. Local input is original fiction. No learner trial or educator approval occurred.
