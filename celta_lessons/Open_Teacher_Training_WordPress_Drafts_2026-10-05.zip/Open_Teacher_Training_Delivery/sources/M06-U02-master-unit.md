# M06-U02 — Check a summary

Version 3.0.0. Complete sample; educator review pending.

## Context

Training: 35 minutes. Classroom illustration: 25 minutes. Estimates only.

Level: B1–B2, provisional. Diagnose before use.

Teacher outcome: Model source comparison without presenting fluent summaries as evidence.

Learner outcome: Reconcile two source accounts without removing their limitations.

## Input — Two accounts, one claim

Original fictional teaching material. Not a real service notice.

SOURCE A — Learning-centre trial note, 6 May

[1] Eighteen volunteers attended four lunchtime reading sessions. The sessions combined short articles, discussion and a ten-minute writing task. Fourteen volunteers completed both the opening and closing quizzes. Their average scores rose from six to eight correct answers out of ten.

[2] The quizzes used different articles. Staff did not check whether those articles had the same difficulty. There was no comparison group. Six volunteers said discussion helped them. Others did not answer that question. The centre will repeat the trial before making a decision about expansion.

SOURCE B — Coordinator’s email, 8 May

[3] We are pleased that participants returned. The quiz results are encouraging, but they cannot show which activity caused the change. Some volunteers had attended English classes elsewhere during the same month. We have not tested whether improvements last.

[4] Next time, we will record attendance and ask about other learning. We also need a task using an unfamiliar article. The current results should not be advertised as proof that ten minutes of writing improves everyone’s reading.

## Worked decision

A claim about score changes is supported by A[1]. A claim about writing causing improvement is not supported. A[2] and B[3] provide alternative explanations.

## Sequence

- 5 minutes: Diagnose and state the purpose.
- 7 minutes: Model one decision.
- 10 minutes: Attempt the task.
- 8 minutes: Compare evidence and revise.
- 5 minutes: Check independently and plan a return.

## T1 — Identify the sample.

How many attended? How many completed both quizzes? Why does the difference matter?

Answer guidance: Eighteen attended; fourteen completed both. The score change describes completers, not necessarily every attendee.

## T2 — Audit the summary.

Flawed summary: “Eighteen learners proved that ten minutes of writing causes a lasting reading improvement. Everyone preferred discussion, so the centre will expand immediately.” Underline unsupported claims.

Answer guidance: Eighteen completers is wrong; only fourteen completed both. “Proved”, “causes”, “lasting”, “everyone” and “expand immediately” are unsupported or contradicted. A[2] and B[3–4] explain why.

## T3 — Rewrite with attribution.

Write 70–100 words. State the result, sample and two limits. Name the source of one caution.

Answer guidance: Include fourteen completers, six-to-eight quiz result, unequal article difficulty/no comparison/other learning/no follow-up. Attribute the coordinator’s caution. Do not imply the intervention failed or succeeded causally.

## T4 — Explain an uncertainty.

Tell a partner which finding would change your confidence. Then write one follow-up question.

Answer guidance: Accept a matched comparison, comparable quiz difficulty or delayed unfamiliar-text task. An additional satisfaction survey alone cannot establish causation.

## One possible response

The centre reports that fourteen volunteers completed both quizzes, with average scores rising from six to eight out of ten. Eighteen people attended the sessions overall. The result does not establish what caused the change: article difficulty was not matched and there was no comparison group. The coordinator also notes that some people attended other English classes. No follow-up test established whether the change lasted. The centre plans another trial before deciding whether to expand.

Exact wording is not prescribed.

## Feedback

Ask which source supports each clause. Keep a useful result without overclaiming. Do not replace unjustified optimism with unjustified pessimism.

## Access

Read sources separately, then together. Explain average, comparison group and lasting. Allow first-language planning. Reduce output length before deleting source limitations.

## Return without AI

Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.

A library tried a reminder message for a writing group. Twenty members received it. Twelve came that week, compared with eight the previous week. It rained heavily during the earlier meeting. The library did not ask whether members read the message. The organiser wrote: “Attendance rose, but we cannot identify the cause from these two meetings.”

Without AI, correct this claim: “The reminder made four extra people attend.” Write 50–70 words preserving the observed change and two limitations.

Answer guidance: Attendance changed from eight to twelve. This does not establish four specific additional people or a reminder effect. Weather differed; receipt/reading was unverified; no comparison group or repeated matched observations.

## Criteria

- Accuracy: preserves the sample and result.
- Attribution: locates the source of a caution.
- Qualification: separates association and cause.
- Independence: explains the rewrite without AI.

## Source and review

Source anchors: D4, R1, R6, R7, R9. Local input is original fiction. No learner trial or educator approval occurred.
