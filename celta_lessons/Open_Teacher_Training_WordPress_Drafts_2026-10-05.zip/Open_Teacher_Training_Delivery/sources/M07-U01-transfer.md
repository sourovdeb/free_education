# M07-U01 — Return task

Use a new context. No AI assistance. Record other support.

A neighbourhood workshop offers a Wednesday photography walk at 16:00 or a Sunday indoor session at 11:00. Booking is required. The first visit costs nothing. Participants should ask whether equipment can be borrowed. You are available only on Sundays. You want to practise describing photographs in English. You do not own a camera.

Without AI, write 60–90 words asking for a Sunday place, explaining your goal and asking about equipment. Request confirmation.

## Teacher key
Message should contain Sunday, describing photographs, equipment question and confirmation. No invented promise of a camera or available place.
