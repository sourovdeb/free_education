# M06-U01 — Return task

Use a new context. No AI assistance. Record other support.

The Riverside Centre will run a repair workshop on three Thursdays in March. Sessions start at 18:00 and finish at 19:30. Entry is free, but replacement parts are charged separately. Eight places must be booked by telephone. There are no walk-in places. Participants should bring one small item. Electrical appliances are not accepted. Tools stay at the centre. Staff will review attendance before deciding whether to add April sessions.

Without AI, classify these claims: every repair costs nothing; all places require booking; April sessions are confirmed. Then write a 40–60 word message explaining one rule and one uncertainty.

## Teacher key
Every repair costs nothing: contradicted; parts cost money. All places require booking: supported. April sessions confirmed: not stated. Message must preserve those distinctions.
