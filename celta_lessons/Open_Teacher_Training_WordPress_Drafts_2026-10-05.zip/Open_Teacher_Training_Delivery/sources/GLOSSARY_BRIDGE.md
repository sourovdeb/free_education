# Glossary bridge

Source terminology is retained. Adaptations are labelled.

## MFPA

Source: Meaning, form, pronunciation, appropriacy.

Adaptation: Retain all four considerations.

Example: A request changes with audience.

Anchor: D2 pp. 2, 5

## MFPR

Source: Some centre sheets use register instead of appropriacy.

Adaptation: Explain the related but non-identical labels.

Example: Register is one part of context-sensitive use.

Anchor: D6 lexis/function sheets

## Concept check

Source: Checks understanding of language meaning.

Adaptation: Do not confuse with instructions.

Example: Does “borrow” mean keep forever?

Anchor: D2 pp. 2–3

## Instruction check

Source: Checks what learners should do.

Adaptation: A demonstration can be preferable.

Example: Should you write or discuss?

Anchor: D2 p. 3

## Gist

Source: General understanding of a text.

Adaptation: Use when the reading purpose needs it.

Example: Choose the notice’s main purpose.

Anchor: D2 p. 4; D4

## Detailed reading

Source: Closer inspection of text meaning.

Adaptation: Require evidence, references and inference checks.

Example: Which sentence supports the booking rule?

Anchor: D4

## Fluency

Source: Allows language use without tightly restricting choices.

Adaptation: Apply to writing as well as speaking.

Example: Draft a purposeful message.

Anchor: D2 p. 4

## Accuracy

Source: Attention to correct language production.

Adaptation: Use alongside meaning; not as the sole writing criterion.

Example: Check whether tense changes the event time.

Anchor: D2 p. 2

## Guided discovery

Source: A way to clarify language through examples.

Adaptation: Not automatically a whole lesson framework.

Example: Infer a pattern, then verify it.

Anchor: D2 p. 4; D6 stage names

## Micro-teaching

Source: In this glossary: support during monitoring.

Adaptation: Elsewhere it can mean a brief teaching rehearsal. Label the meaning.

Example: Guiding a learner during controlled practice is not a recorded rehearsal.

Anchor: D2 p. 5

## Teacher talk time

Source: The amount of teacher talk.

Adaptation: The glossary’s 70/30 ratio is a rough heuristic. Evaluate purpose and learner response.

Example: A model explanation can be useful.

Anchor: D2 p. 7

## Task before text

Source: Give a reason to read or listen.

Adaptation: Useful routine, not a ban on reader-selected purposes.

Example: Read to decide whether to book.

Anchor: D2 pp. 6–7

## Lead-in

Source: A stage establishing interest and context.

Adaptation: Five minutes is not mandatory.

Example: One picture may establish context.

Anchor: D2 p. 5

## Repeated encounters

Source: The introduction suggests at least seven.

Adaptation: Do not promise a universal threshold.

Example: Use retrieval and meaningful return tasks.

Anchor: D2 p. 1; R5

## Feedback

Source: May address content or language.

Adaptation: Connect comments to revision decisions.

Example: The reader could not find the time.

Anchor: D2 p. 4; D5

## Mediation

Source: Helping others access or construct meaning.

Adaptation: Our extension uses CEFR-informed tasks.

Example: Explain a notice for another reader.

Anchor: R9

## Transfer

Source: Performance in a changed context.

Adaptation: A project assessment design, not a glossary quotation.

Example: Write a fresh request without hints.

Anchor: R5; R6

## AI hint

Source: A bounded aid after an attempt.

Adaptation: Separate assistance from an independent check.

Example: Point to a paragraph without giving the answer.

Anchor: R6; R8