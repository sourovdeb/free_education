# M07-U02 — Revise without losing meaning

Read → attempt → explain → revise.

## The workshop invitation

WRITER’S INTENTION

Invite beginners to a free Saturday writing workshop. It starts at 10:00 and ends at 11:30. Ten places are available. Booking is required. Participants may bring paper or a laptop. The organiser has not confirmed step-free access. The workshop offers practice and peer response, not certificates.

FIRST DRAFT

Come to our writing thing on Saturday. Everyone can come and there is lots of time. Bring something. You will become a great writer. You can get a certificate. Tell people.

READER RESPONSE

“What time does it start? Do I need to book? I use a wheelchair. I cannot tell whether I can enter the room. Do I need a laptop?”

SUGGESTIONS FROM AN ILLUSTRATIVE AI REVIEW

A. Add the start and finish times.
B. Say that the room is fully accessible.
C. Remove the certificate promise.
D. Replace the invitation with an academic essay.
E. Explain what people can bring.
F. Say that places require booking.

## T1 — Find meaning problems.

Identify three conflicts between the intention and draft. Distinguish missing facts from invented promises.

## T2 — Judge each suggestion.

Mark Accept, Adapt or Reject. Give a reason grounded in intention or reader response.

## T3 — Write the revision.

Write 90–120 words. Preserve the invitation. Include time, capacity, booking and equipment. Handle access uncertainty without inventing an answer.

## T4 — Record the decisions.

Explain one acceptance, one adaptation and one rejection. Ask a reader to answer the original questions.

Original fictional input. Review pending.
