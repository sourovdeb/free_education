# Teacher guide: M06-U01

Teach learners to justify a reading decision before receiving an answer.

Training time: 30 minutes. Example classroom time: 20 minutes.

## Worked decision
Claim: Entry costs nothing. Decision: supported. Evidence: paragraph 1 says there is no entry charge. This does not mean visitors can take books home.

## Answers
### T1
B. Paragraphs 1 and 4 describe a trial without a continuation decision.

### T2
A Contradicted [2]; four seats do not need booking. B Supported [3]. C Not stated [4]; undecided. D Contradicted [1]; return books before leaving. E Contradicted [4]. F Not stated [2]; the notice leaves older children unspecified.

### T3
Possible: to include visitors who could not book. This is plausible, not directly stated. Other explanations need a logical link to paragraph 2.

### T4
Check all three functions. Do not invent December dates or a rule for thirteen-year-olds. Exact wording varies.

## Sample response
The centre is trying a reading room on four Saturdays in November. You can reserve a seat by email, but four seats are kept for people without bookings. Books must stay at the centre. You can bring your own book. Staff have not decided whether the room will continue, so check before planning a December visit.

## Feedback
Ask the learner to locate evidence. Then ask what it rules out. Give the key after that attempt. Correct the reasoning, not just the label.

## Adaptation
Gloss trial, reserve and donate when needed. Offer numbered paragraphs and print. Let learners answer orally before writing. Record oral support when interpreting writing evidence.

## Independent return
Without AI, classify these claims: every repair costs nothing; all places require booking; April sessions are confirmed. Then write a 40–60 word message explaining one rule and one uncertainty.

Every repair costs nothing: contradicted; parts cost money. All places require booking: supported. April sessions confirmed: not stated. Message must preserve those distinctions.

## Criteria
- Evidence: links claims to relevant wording.
- Distinctions: separates support, contradiction and absence.
- Writing: includes the requested facts without invention.
- Revision: explains one corrected interpretation.