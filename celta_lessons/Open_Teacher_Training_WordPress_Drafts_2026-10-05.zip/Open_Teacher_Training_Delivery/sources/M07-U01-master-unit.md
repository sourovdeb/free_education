# M07-U01 — Write for a reader

Version 3.0.0. Complete sample; educator review pending.

## Context

Training: 30 minutes. Classroom illustration: 25 minutes. Estimates only.

Level: A2–B1, provisional. Diagnose before use.

Teacher outcome: Use a model, a plan and reader response to teach purposeful writing.

Learner outcome: Write a request containing enough information for a useful reply.

## Input — From a notice to a message

Original fictional teaching material. Not a real service notice.

NOTICE

The Maple Centre runs conversation workshops on Tuesdays at 18:00 and Saturdays at 10:00. Each workshop lasts one hour. A trial visit is free. Booking is required. Write to the coordinator with your preferred session and one learning goal. Ask before bringing a guest. The notice does not describe step-free access.

MODEL MESSAGE

Subject: A Saturday trial visit

Hello,
I would like to attend the Saturday workshop. I want to practise asking questions at work. Is there space this Saturday? Could you also tell me whether the room has step-free access? Please confirm the date before I arrange transport.
Thank you,
Sam

YOUR SITUATION

You work on Saturdays. You want to practise explaining problems to customers. You would like a Tuesday trial. A friend wants to join you. You need confirmation before changing a work shift.

## Worked decision

The opening identifies the session. The next sentence states the goal. The questions request missing information. The final sentence explains why confirmation matters.

## Sequence

- 4 minutes: Diagnose and state the purpose.
- 6 minutes: Model one decision.
- 8 minutes: Attempt the task.
- 7 minutes: Compare evidence and revise.
- 5 minutes: Check independently and plan a return.

## T1 — Notice the message functions.

Mark the session, learning goal, missing information and confirmation request. Which details come from the notice?

Answer guidance: The Saturday time and booking rule come from the notice. The goal, access question and travel reason belong to the writer’s situation. The notice does not guarantee access.

## T2 — Make a four-part plan.

Write notes: session; goal; guest question; reason for confirmation.

Answer guidance: Tuesday; explaining customer problems; permission for a friend; work-shift arrangements.

## T3 — Write your request.

Write 70–100 words for the coordinator. Use your situation. Do not copy Sam’s access question unless it is relevant.

Answer guidance: A suitable message names Tuesday, states the customer goal, asks about bringing a friend and requests confirmation before changing a shift. It does not announce an unconfirmed booking.

## T4 — Test it with a reader.

Ask a partner to list your session, goal and questions. Revise anything the partner misunderstood.

Answer guidance: Revision follows actual reader response. Grammar feedback should not obscure missing information. Accept different register choices that suit the relationship.

## One possible response

Hello, I would like to book a trial visit for a Tuesday conversation workshop. I work on Saturdays, so I cannot attend that session. My learning goal is to practise explaining problems to customers in English. Is there a place available next Tuesday at 18:00? A friend would also like to come. Could you tell me whether guests can join a trial session? Please confirm the date and both places before I ask to change my work shift. Thank you.

Exact wording is not prescribed.

## Feedback

Respond as the coordinator first. Say what you can answer. Point out any missing decision. Then select one language feature to improve.

## Access

Offer sentence openings after planning. Permit handwriting or typing. Allow oral rehearsal but retain an independent written attempt. Teach script or spelling support separately when needed.

## Return without AI

Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.

A neighbourhood workshop offers a Wednesday photography walk at 16:00 or a Sunday indoor session at 11:00. Booking is required. The first visit costs nothing. Participants should ask whether equipment can be borrowed. You are available only on Sundays. You want to practise describing photographs in English. You do not own a camera.

Without AI, write 60–90 words asking for a Sunday place, explaining your goal and asking about equipment. Request confirmation.

Answer guidance: Message should contain Sunday, describing photographs, equipment question and confirmation. No invented promise of a camera or available place.

## Criteria

- Purpose: gives the reader a clear request.
- Content: includes required facts and questions.
- Organisation: orders information for a reply.
- Language: communicates meaning with appropriate support.

## Source and review

Source anchors: D5, R4, R9, R10. Local input is original fiction. No learner trial or educator approval occurred.
