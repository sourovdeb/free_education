# Teacher guide: M07-U01

Use a model, a plan and reader response to teach purposeful writing.

Training time: 30 minutes. Example classroom time: 25 minutes.

## Worked decision
The opening identifies the session. The next sentence states the goal. The questions request missing information. The final sentence explains why confirmation matters.

## Answers
### T1
The Saturday time and booking rule come from the notice. The goal, access question and travel reason belong to the writer’s situation. The notice does not guarantee access.

### T2
Tuesday; explaining customer problems; permission for a friend; work-shift arrangements.

### T3
A suitable message names Tuesday, states the customer goal, asks about bringing a friend and requests confirmation before changing a shift. It does not announce an unconfirmed booking.

### T4
Revision follows actual reader response. Grammar feedback should not obscure missing information. Accept different register choices that suit the relationship.

## Sample response
Hello, I would like to book a trial visit for a Tuesday conversation workshop. I work on Saturdays, so I cannot attend that session. My learning goal is to practise explaining problems to customers in English. Is there a place available next Tuesday at 18:00? A friend would also like to come. Could you tell me whether guests can join a trial session? Please confirm the date and both places before I ask to change my work shift. Thank you.

## Feedback
Respond as the coordinator first. Say what you can answer. Point out any missing decision. Then select one language feature to improve.

## Adaptation
Offer sentence openings after planning. Permit handwriting or typing. Allow oral rehearsal but retain an independent written attempt. Teach script or spelling support separately when needed.

## Independent return
Without AI, write 60–90 words asking for a Sunday place, explaining your goal and asking about equipment. Request confirmation.

Message should contain Sunday, describing photographs, equipment question and confirmation. No invented promise of a camera or available place.

## Criteria
- Purpose: gives the reader a clear request.
- Content: includes required facts and questions.
- Organisation: orders information for a reply.
- Language: communicates meaning with appropriate support.