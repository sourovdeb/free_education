# M07-U01 — Write for a reader

Read → attempt → explain → revise.

## From a notice to a message

NOTICE

The Maple Centre runs conversation workshops on Tuesdays at 18:00 and Saturdays at 10:00. Each workshop lasts one hour. A trial visit is free. Booking is required. Write to the coordinator with your preferred session and one learning goal. Ask before bringing a guest. The notice does not describe step-free access.

MODEL MESSAGE

Subject: A Saturday trial visit

Hello,
I would like to attend the Saturday workshop. I want to practise asking questions at work. Is there space this Saturday? Could you also tell me whether the room has step-free access? Please confirm the date before I arrange transport.
Thank you,
Sam

YOUR SITUATION

You work on Saturdays. You want to practise explaining problems to customers. You would like a Tuesday trial. A friend wants to join you. You need confirmation before changing a work shift.

## T1 — Notice the message functions.

Mark the session, learning goal, missing information and confirmation request. Which details come from the notice?

## T2 — Make a four-part plan.

Write notes: session; goal; guest question; reason for confirmation.

## T3 — Write your request.

Write 70–100 words for the coordinator. Use your situation. Do not copy Sam’s access question unless it is relevant.

## T4 — Test it with a reader.

Ask a partner to list your session, goal and questions. Revise anything the partner misunderstood.

Original fictional input. Review pending.
