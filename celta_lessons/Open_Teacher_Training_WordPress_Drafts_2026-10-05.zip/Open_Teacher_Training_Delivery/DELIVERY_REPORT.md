# WordPress delivery — 5 October 2026

32 drafts saved. 22 page candidates remain unsaved.

## Open the section

[Open the hub editor](https://sourovdeb.com/wp-admin/post.php?post=3672&action=edit)

[GitHub review branch](https://github.com/sourovdeb/free_education/pull/59)

[GitHub page registry](https://github.com/sourovdeb/free_education/blob/ott-v3-literacy-review-2026-09-30/open-teacher-training/v3/WEBSITE_DELIVERY.md)

The hub, Start, Course, Methods and Materials now link the saved creations. All 32 pages remain drafts. All have video and transcript spaces. Log into WordPress to review them. Nothing was published on WordPress. No menus, theme, plugins, account settings or public media uploads were changed.

## What is actually there

Eight section pages, eleven module pages, five complete sample packs, three retained unit specifications and five resource pages. Module 10 was not saved. The five complete sample packs have their actual input, tasks, answer guidance and revision/transfer material. The course's other 43 units are still specifications, not completed lessons. Educator review remains pending.

## Holds

M10 and the blueprint parent were blocked by the platform. Exact response:

> This tool call was blocked by OpenAI because we couldn't determine the safety status of the request.

P01–P20 were not attempted because their parent was held. No alternate endpoint or parent was used to bypass these blocks. All 22 candidates are preserved in this archive for review. No automatic import script is included. The daily check excludes these holds.

## Archive contents

54 prepared HTML source previews; their structured page candidates; nine SVG diagrams; an illustration crop; demonstration scripts; the teaching procedure; the glossary; the Mistral setup source; a registry and local checks.

These previews preserve more source detail than some resource landing pages. They are NOT an exact WordPress database backup. The hub/navigation added on the live draft site can differ. The registry records what was actually saved. Do not import the full tree again or assume every file has a WordPress ID.

## Future results

A daily repository check is enabled. It watches Open Teacher Training sources in the configured GitHub path and follows the saved delivery policy. It reuses verified draft IDs, preserves videos and manual edits, checks receipts and emails the owner only for material changes. It does not monitor unsaved future ChatGPT conversations. Its first run establishes a baseline without replaying this batch. Future execution and account access are not guaranteed merely by task creation.

## Add your video

Open the page editor. Find Video walkthrough. Insert a YouTube block in place of the placeholder, paste your video URL, choose Embed, and Preview. Add the transcript underneath. Save as a draft.

Reference checked 5 October 2026: https://wordpress.org/documentation/article/youtube-embed/

## Checks

The WordPress creation-marker query returned 32 pages, all drafts. A second draft query for the creation marker, video anchor and transcript placeholder also returned 32. Block trees were inspected for the navigation pages. The full M07-U02 content was read back, including expandable answers and a transfer task. No live browser, screen-reader or mobile rendering claim is made. Local structural and link checks are recorded in LOCAL_CHECKS.json.

## Registry

| Creation | WordPress ID | Delivery state | Title |
|---|---:|---|---|
| OTT-HUB | 3672 | DRAFT_VERIFIED | Open Teacher Training |
| OTT-START | 3673 | DRAFT_VERIFIED | Start here — Open Teacher Training |
| OTT-COURSE | 3675 | DRAFT_VERIFIED | Course modules |
| OTT-METHODS | 3676 | DRAFT_VERIFIED | Teaching methods library |
| OTT-MATERIALS | 3678 | DRAFT_VERIFIED | Teaching materials library |
| OTT-PRACTICE | 3679 | DRAFT_VERIFIED | Teaching practice |
| OTT-PORTFOLIO | 3681 | DRAFT_VERIFIED | Your teaching portfolio |
| OTT-ABOUT | 3683 | DRAFT_VERIFIED | About Open Teacher Training |
| M01 | 3688 | DRAFT_VERIFIED | M01 — Understand the learner |
| M02 | 3693 | DRAFT_VERIFIED | M02 — Plan and teach a first lesson |
| M03 | 3696 | DRAFT_VERIFIED | M03 — Teach grammar and functions |
| M04 | 3699 | DRAFT_VERIFIED | M04 — Teach vocabulary and expressions |
| M05 | 3701 | DRAFT_VERIFIED | M05 — Teach pronunciation for communication |
| M06 | 3705 | DRAFT_VERIFIED | M06 — Teach reading and listening |
| M07 | 3707 | DRAFT_VERIFIED | M07 — Teach speaking and writing |
| M08 | 3709 | DRAFT_VERIFIED | M08 — Run an inclusive classroom |
| M09 | 3713 | DRAFT_VERIFIED | M09 — Assess learning and give feedback |
| M10 | — | PLATFORM_HOLD | M10 — Teach online and with low bandwidth |
| M11 | 3731 | DRAFT_VERIFIED | M11 — Use AI without surrendering judgement |
| M12 | 3733 | DRAFT_VERIFIED | M12 — Teach, reflect and demonstrate |
| M02-U01 | 3748 | DRAFT_VERIFIED | M02-U01 — Give instructions people can act on |
| M01-U04 | 3750 | DRAFT_VERIFIED | M01-U04 — Set learning goals |
| M03-U01 | 3752 | DRAFT_VERIFIED | M03-U01 — Check meaning without guessing |
| M09-U02 | 3753 | DRAFT_VERIFIED | M09-U02 — Give usable feedback |
| M06-U01 | 3737 | DRAFT_VERIFIED | M06-U01 — Read for evidence |
| M06-U02 | 3740 | DRAFT_VERIFIED | M06-U02 — Check a summary |
| M07-U01 | 3744 | DRAFT_VERIFIED | M07-U01 — Write for a reader |
| M07-U02 | 3746 | DRAFT_VERIFIED | M07-U02 — Revise without losing meaning |
| OTT-BLUEPRINT | — | PLATFORM_HOLD | Blueprint — Read. Write. Understand. |
| P01 | — | DEPENDENCY_HOLD | P01 — Read. Write. Understand. |
| P02 | — | DEPENDENCY_HOLD | P02 — Start with the sources |
| P03 | — | DEPENDENCY_HOLD | P03 — What CELTA already contains |
| P04 | — | DEPENDENCY_HOLD | P04 — Attention is a design condition |
| P05 | — | DEPENDENCY_HOLD | P05 — Chunks must lead to depth |
| P06 | — | DEPENDENCY_HOLD | P06 — One loop, two audiences |
| P07 | — | DEPENDENCY_HOLD | P07 — Twelve modules remain |
| P08 | — | DEPENDENCY_HOLD | P08 — Reading: beyond answer hunting |
| P09 | — | DEPENDENCY_HOLD | P09 — Writing: meaning before polish |
| P10 | — | DEPENDENCY_HOLD | P10 — Speaking supports literacy |
| P11 | — | DEPENDENCY_HOLD | P11 — Media follows the task |
| P12 | — | DEPENDENCY_HOLD | P12 — The website section |
| P13 | — | DEPENDENCY_HOLD | P13 — AI assists; learners decide |
| P14 | — | DEPENDENCY_HOLD | P14 — Choose models through tests |
| P15 | — | DEPENDENCY_HOLD | P15 — Skills and workflows differ |
| P16 | — | DEPENDENCY_HOLD | P16 — Assess learning, not production |
| P17 | — | DEPENDENCY_HOLD | P17 — Two hundred hours: still provisional |
| P18 | — | DEPENDENCY_HOLD | P18 — Test before expanding |
| P19 | — | DEPENDENCY_HOLD | P19 — Protect people; publish evidence |
| P20 | — | DEPENDENCY_HOLD | P20 — What changed; what remains |
| OTT-SOURCES | 3757 | DRAFT_VERIFIED | Evidence review and sources |
| OTT-SKILL | 3758 | DRAFT_VERIFIED | Teaching materials and methods — Skill |
| OTT-MISTRAL | 3759 | DRAFT_VERIFIED | Mistral teaching studio — Setup guide |
| OTT-GLOSSARY | 3760 | DRAFT_VERIFIED | Teaching terms — Glossary bridge |
| OTT-MEDIA | 3761 | DRAFT_VERIFIED | Diagrams and video production scripts |
