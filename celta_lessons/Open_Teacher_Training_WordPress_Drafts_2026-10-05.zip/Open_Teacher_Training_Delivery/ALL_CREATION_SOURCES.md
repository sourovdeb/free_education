# Website creation source edition

Prepared from Open Teacher Training v3. This text is not a live WordPress backup.



---

## OTT-HUB — Open Teacher Training

Source: 02_website/open-teacher-training-drafts.xml#990001

Delivery: DRAFT_VERIFIED. WordPress ID: 3672.


<p>Read with evidence. Write for people. Teach through practice.</p>
<p>Begin with the literacy pilot. Four complete sample packs offer texts, tasks, answers and revision. An earlier instruction-giving pack remains available. All await educator review.</p>
<p>The curriculum contains twelve modules and forty-eight unit specifications. Specifications describe work still to be authored. The proposed 200-hour supported route requires mentor capacity. Self-study is not observed teaching competence.</p>
<p>Independent project. No Cambridge affiliation. No CELTA award. No compulsory paid AI. Original source documents and private candidate records are not redistributed.</p>



---

## OTT-START — Start here — Open Teacher Training

Source: 02_website/open-teacher-training-drafts.xml#990002

Delivery: DRAFT_VERIFIED. WordPress ID: 3673.

<h2>Start with a real reading task</h2><p>Open M06-U01: Read for evidence. Read the notice, classify claims, and explain one inference. Then write to a visitor. Use the answer guide after your attempt.</p><h3>Two routes</h3><p>Self-study gives access to materials and practice. Supported teaching requires real learners, an observer and feedback. No placement is promised before capacity exists.</p><h3>What to keep</h3><p>Save your first response, one correction and the reason for that correction. Return to the changed task after 2–7 days. The interval is a pilot choice.</p><h3>Access</h3><p>Use HTML or print. Ask for vocabulary or script support when needed. There is no compulsory video or paid AI.</p>



---

## OTT-COURSE — Course modules

Source: 02_website/open-teacher-training-drafts.xml#990003

Delivery: DRAFT_VERIFIED. WordPress ID: 3675.

<h2>Twelve modules</h2><p>Modules 1–4 cover learners, planning, grammar and vocabulary. Modules 5–8 cover sound/print, reading/listening, writing/speaking and inclusion. Modules 9–12 cover assessment, delivery, AI judgement and a teaching portfolio.</p><p>Each module has four unit specifications. Five units have complete sample packs. Other specifications require authoring. All examples await educator review.</p><p>The proposed activity budget totals 200 hours. It is not a claim of equivalence to 120 tutor-contact hours plus preparation.</p>



---

## OTT-METHODS — Teaching methods library

Source: 02_website/open-teacher-training-drafts.xml#990004

Delivery: DRAFT_VERIFIED. WordPress ID: 3676.

<h2>Choose from the outcome</h2><p>For comprehension, supply an actual text and ask for evidence. Model a difficult inference before expecting independent performance.</p><p>For writing, identify audience and purpose; inspect a model, plan, draft, receive reader response and revise.</p><p>For new language, select contextual explanation, guided discovery or a diagnostic sequence according to learner needs. Guided discovery is not automatically a whole lesson framework.</p><p>Meaning checks and instruction checks serve different purposes. The supplied glossary’s talk ratios and time caps are heuristics, not universal requirements.</p>



---

## OTT-MATERIALS — Teaching materials library

Source: 02_website/open-teacher-training-drafts.xml#990005

Delivery: DRAFT_VERIFIED. WordPress ID: 3678.

<h2>Sample packs</h2><p>M02-U01: instructions. M06-U01: reading evidence. M06-U02: checking summaries. M07-U01: writing for a reader. M07-U02: preserving meaning through revision.</p><p>Each literacy pack contains original input, tasks, keys, teacher guidance and an unseen transfer task. Learner-only PDFs exclude the answer page.</p><p>Content is sample-complete, not educator-approved. Do not describe the remaining specifications as finished teaching packs.</p>



---

## OTT-PRACTICE — Teaching practice

Source: 02_website/open-teacher-training-drafts.xml#990006

Delivery: DRAFT_VERIFIED. WordPress ID: 3679.

<h2>Rehearse, teach, review</h2><p>Compare the model with a weak example. Rehearse the teaching decision. Teach real learners only through a consented arrangement. Ask the observer to record what learners actually did.</p><p>Use feedback to change one feature, then retry. Rehearsal and AI role-play do not count as observed teaching with real learners.</p><p>The twelve-hour supported pathway remains a design target. Mentor availability and learner groups must be confirmed before enrolment promises.</p>



---

## OTT-PORTFOLIO — Your teaching portfolio

Source: 02_website/open-teacher-training-drafts.xml#990007

Delivery: DRAFT_VERIFIED. WordPress ID: 3681.

<h2>Keep evidence, not just certificates</h2><p>Include a learner profile, language analysis, lesson plans, original materials, observation records, feedback and revisions.</p><p>Label the conditions of each sample: self-study, rehearsal, observed teaching or independent assessment. Record assistance and accommodations.</p><p>Public portfolios require consent for any learner contribution. Personal candidate records stay private. A self-study completion record is not an assessed teaching qualification.</p>



---

## OTT-ABOUT — About Open Teacher Training

Source: 02_website/open-teacher-training-drafts.xml#990008

Delivery: DRAFT_VERIFIED. WordPress ID: 3683.

<h2>Independent teacher education</h2><p>This project preserves useful CELTA foundations while testing literacy-focused, internet-ready extensions. It is not affiliated with Cambridge and does not award CELTA.</p><p>Sources distinguish official requirements, centre guidance, research and project proposals. The current public syllabus already includes adult literacy and digital materials. No claim of superiority has been established.</p><p>Release v3 is a candidate. Source corrections, educator review and learner trials remain part of development.</p>



---

## M01 — M01 — Understand the learner

Source: 02_website/open-teacher-training-drafts.xml#990020

Delivery: DRAFT_VERIFIED. WordPress ID: 3688.

<h2>Understand learners</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M01-U01 · Diagnose reading needs</h3><p>Status: specification</p><p>Compare word decoding, vocabulary and comprehension using a short passage. Separate unfamiliar script from limited English.</p><p>Evidence: A learner profile with observed evidence.</p><h3>M01-U02 · Diagnose writing needs</h3><p>Status: specification</p><p>Compare planning, sentence formation, spelling and communication. Ask learners about purposes and previous schooling.</p><p>Evidence: A writing sample annotated by difficulty.</p><h3>M01-U03 · Identify access barriers</h3><p>Status: specification</p><p>Test keyboard, screen, print and audio routes. Ask about preferences; do not infer disability or attention from age.</p><p>Evidence: An access plan preserving the outcome.</p><h3>M01-U04 · Set learning goals</h3><p>Status: specification</p><p>Translate needs into observable actions. Distinguish a CEFR-informed task from a validated level decision.</p><p>Evidence: Two goals and a baseline task.</p>



---

## M02 — M02 — Plan and teach a first lesson

Source: 02_website/open-teacher-training-drafts.xml#990021

Delivery: DRAFT_VERIFIED. WordPress ID: 3693.

<h2>Plan and teach</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M02-U01 · Give instructions people can act on</h3><p>Status: complete_sample</p><p>Retain the existing club-choice task. Demonstrate the decision and verify learner action.</p><p>Evidence: An instruction rehearsal and revision.</p><h3>M02-U02 · Plan backwards from evidence</h3><p>Status: specification</p><p>Choose the final learner product first. Then select input, support and feedback.</p><p>Evidence: An aligned lesson plan.</p><h3>M02-U03 · Choose and adapt a framework</h3><p>Status: specification</p><p>Compare text-based, diagnostic and task-oriented sequences. Guided discovery is a clarification option, not a full framework.</p><p>Evidence: A justified sequence and alternative.</p><h3>M02-U04 · Monitor without rescuing</h3><p>Status: specification</p><p>Observe a misunderstanding before responding. Try a hint, then check the learner response.</p><p>Evidence: A monitoring and feedback record.</p>



---

## M03 — M03 — Teach grammar and functions

Source: 02_website/open-teacher-training-drafts.xml#990022

Delivery: DRAFT_VERIFIED. WordPress ID: 3696.

<h2>Grammar and functions</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M03-U01 · Explain meaning in context</h3><p>Status: specification</p><p>Analyse a sentence within a message. Identify its intended meaning before naming form.</p><p>Evidence: A meaning explanation and checks.</p><h3>M03-U02 · Notice grammar across a text</h3><p>Status: specification</p><p>Track pronouns, tense and linking relations. Explain how these support coherence.</p><p>Evidence: A reference-chain annotation.</p><h3>M03-U03 · Teach functions for readers</h3><p>Status: specification</p><p>Compare requests, explanations and clarification. Preserve purpose while changing register.</p><p>Evidence: Two audience-specific messages.</p><h3>M03-U04 · Move from control to transfer</h3><p>Status: specification</p><p>Use focused practice after diagnosis. Check the target in a different writing or speaking task.</p><p>Evidence: A delayed transfer sample.</p>



---

## M04 — M04 — Teach vocabulary and expressions

Source: 02_website/open-teacher-training-drafts.xml#990023

Delivery: DRAFT_VERIFIED. WordPress ID: 3699.

<h2>Vocabulary and expressions</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M04-U01 · Choose useful vocabulary</h3><p>Status: specification</p><p>Select words needed for the task. Identify blocking vocabulary without preteaching every unknown word.</p><p>Evidence: A selection with reasons.</p><h3>M04-U02 · Teach chunks and collocations</h3><p>Status: specification</p><p>Use phrase patterns in messages. Contrast a natural combination with an understandable but unusual one.</p><p>Evidence: A phrase bank with contexts.</p><h3>M04-U03 · Infer and verify meaning</h3><p>Status: specification</p><p>Combine context, word parts and a dictionary. Mark uncertainty before checking.</p><p>Evidence: A word-inference record.</p><h3>M04-U04 · Retrieve through use</h3><p>Status: specification</p><p>Return to phrases in a changed context. Avoid promising a fixed encounter count.</p><p>Evidence: A spaced reuse sample.</p>



---

## M05 — M05 — Teach pronunciation for communication

Source: 02_website/open-teacher-training-drafts.xml#990024

Delivery: DRAFT_VERIFIED. WordPress ID: 3701.

<h2>Connect sound and print</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M05-U01 · Connect spelling and sound</h3><p>Status: specification</p><p>Notice a relevant spelling-sound pattern. Avoid implying English has one transparent letter-sound mapping.</p><p>Evidence: An annotated word set.</p><h3>M05-U02 · Use stress for meaning</h3><p>Status: specification</p><p>Compare focus within a sentence. Connect spoken prominence with a reader’s interpretation.</p><p>Evidence: A recorded or live demonstration.</p><h3>M05-U03 · Listen, transcribe, check</h3><p>Status: specification</p><p>Use a short supplied script. Compare a learner transcription with the source; diagnose the missed boundary.</p><p>Evidence: A corrected transcription with reasons.</p><h3>M05-U04 · Target intelligibility</h3><p>Status: specification</p><p>Choose one pronunciation feature affecting understanding. Permit accent variation that preserves meaning.</p><p>Evidence: A communication check.</p>



---

## M06 — M06 — Teach reading and listening

Source: 02_website/open-teacher-training-drafts.xml#990025

Delivery: DRAFT_VERIFIED. WordPress ID: 3705.

<h2>Read and listen with evidence</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M06-U01 · Read for evidence</h3><p>Status: complete_sample</p><p>Distinguish an explicit statement, an inference and an unsupported claim. Explain decisions using the supplied notice.</p><p>Evidence: An evidence-marked response.</p><h3>M06-U02 · Check a summary</h3><p>Status: complete_sample</p><p>Compare two supplied sources with a flawed summary. Keep uncertainty and attribution in the revised account.</p><p>Evidence: A corrected, sourced summary.</p><h3>M06-U03 · Read beyond one screen</h3><p>Status: specification</p><p>Move from a paragraph to a longer text. Track argument structure and competing interpretations.</p><p>Evidence: A paragraph map and explanation.</p><h3>M06-U04 · Listen beyond answer spotting</h3><p>Status: specification</p><p>Replay a difficult stretch. Compare prediction, heard evidence and revised interpretation.</p><p>Evidence: A listening evidence note.</p>



---

## M07 — M07 — Teach speaking and writing

Source: 02_website/open-teacher-training-drafts.xml#990026

Delivery: DRAFT_VERIFIED. WordPress ID: 3707.

<h2>Write, revise and respond</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M07-U01 · Write for a reader</h3><p>Status: complete_sample</p><p>Use a model to write an information request. Make the response easy to provide.</p><p>Evidence: A purposeful message and plan.</p><h3>M07-U02 · Revise without losing meaning</h3><p>Status: complete_sample</p><p>Evaluate feedback against the writer’s intention. Accept, adapt or reject suggestions with reasons.</p><p>Evidence: A before-and-after revision record.</p><h3>M07-U03 · Synthesize sources</h3><p>Status: specification</p><p>Combine claims without copying source wording or inventing certainty. Attribute evidence and mark disagreement.</p><p>Evidence: A short source-based explanation.</p><h3>M07-U04 · Speak to improve writing</h3><p>Status: specification</p><p>Rehearse an explanation; ask listeners what they understood. Use that response to revise a text.</p><p>Evidence: A reader-response revision.</p>



---

## M08 — M08 — Run an inclusive classroom

Source: 02_website/open-teacher-training-drafts.xml#990027

Delivery: DRAFT_VERIFIED. WordPress ID: 3709.

<h2>Adapt participation</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M08-U01 · Support literacy differences</h3><p>Status: specification</p><p>Offer decoding or language support based on evidence. Do not diagnose a medical condition.</p><p>Evidence: An adaptation rationale.</p><h3>M08-U02 · Reduce interface demands</h3><p>Status: specification</p><p>Use headings, predictable controls and optional breaks. Keep challenge in the learning, not navigation.</p><p>Evidence: An access-tested page.</p><h3>M08-U03 · Use languages as resources</h3><p>Status: specification</p><p>Allow planning or explanation through known languages when useful. Keep the target outcome explicit.</p><p>Evidence: A plurilingual mediation task.</p><h3>M08-U04 · Coordinate mixed levels</h3><p>Status: specification</p><p>Keep a shared purpose with different support. Do not simply give more work to faster learners.</p><p>Evidence: A differentiation plan.</p>



---

## M09 — M09 — Assess learning and give feedback

Source: 02_website/open-teacher-training-drafts.xml#990028

Delivery: DRAFT_VERIFIED. WordPress ID: 3713.

<h2>Assess transfer</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M09-U01 · Align assessment</h3><p>Status: specification</p><p>Map each outcome to a task and observable criterion. Separate comprehension from writing accuracy.</p><p>Evidence: An assessment map.</p><h3>M09-U02 · Give usable feedback</h3><p>Status: specification</p><p>Point to a specific feature and its effect. Require a revision rather than only a score.</p><p>Evidence: Feedback followed by a change.</p><h3>M09-U03 · Test independence</h3><p>Status: specification</p><p>Use a comparable unseen task without AI. Keep agreed access accommodations and record them.</p><p>Evidence: A delayed transfer sample.</p><h3>M09-U04 · Moderate judgement</h3><p>Status: specification</p><p>Have educators compare samples against criteria. Record disagreement and refine descriptors.</p><p>Evidence: A moderation record.</p>



---

## M10 — M10 — Teach online and with low bandwidth

Source: 02_website/open-teacher-training-drafts.xml#990029

Delivery: PLATFORM_HOLD. WordPress ID: none.

<h2>Design for internet and print</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M10-U01 · Build a chunk</h3><p>Status: specification</p><p>Package one meaningful decision with input, action and feedback. Do not cut sentences merely to fit a timer.</p><p>Evidence: A complete learning page.</p><h3>M10-U02 · Select media</h3><p>Status: specification</p><p>Use video for demonstration; use text for reading; use audio for listening. Include an equivalent route where appropriate.</p><p>Evidence: A media-choice justification.</p><h3>M10-U03 · Publish without duplication</h3><p>Status: specification</p><p>Maintain one master unit. Generate web, PDF and channel drafts with matching versions.</p><p>Evidence: A traceable release.</p><h3>M10-U04 · Test access</h3><p>Status: specification</p><p>Check keyboard operation, reflow, contrast and downloads. Test with people before claiming conformance.</p><p>Evidence: An accessibility issue log.</p>



---

## M11 — M11 — Use AI without surrendering judgement

Source: 02_website/open-teacher-training-drafts.xml#990030

Delivery: DRAFT_VERIFIED. WordPress ID: 3731.

<h2>Use AI with judgement</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M11-U01 · Understand model limits</h3><p>Status: specification</p><p>Distinguish model, prompt, skill, tool and workflow. Generated language is not a source citation.</p><p>Evidence: A tool-choice explanation.</p><h3>M11-U02 · Ask for hints</h3><p>Status: specification</p><p>Provide the source and the attempt. Request a hint without a completed answer.</p><p>Evidence: A hint-and-retry record.</p><h3>M11-U03 · Audit generated material</h3><p>Status: specification</p><p>Verify meaning, levels, answers, facts and rights. Reject convincing but unsupported content.</p><p>Evidence: An annotated AI output.</p><h3>M11-U04 · Choose models empirically</h3><p>Status: specification</p><p>Run the same cases under a cost ceiling. Record correctness, retries, latency and unsupported claims.</p><p>Evidence: A comparison record without invented scores.</p>



---

## M12 — M12 — Teach, reflect and demonstrate

Source: 02_website/open-teacher-training-drafts.xml#990031

Delivery: DRAFT_VERIFIED. WordPress ID: 3733.

<h2>Demonstrate teaching</h2><p>Curriculum candidate. Complete samples are labelled.</p><h3>M12-U01 · Plan a three-lesson sequence</h3><p>Status: specification</p><p>Link reading, writing and dialogue across lessons. Explain the return and transfer tasks.</p><p>Evidence: A coherent mini-course.</p><h3>M12-U02 · Teach and review</h3><p>Status: specification</p><p>Use real learners with consent and a named observer. Record what was taught and feedback received.</p><p>Evidence: Observed teaching evidence.</p><h3>M12-U03 · Build an honest portfolio</h3><p>Status: specification</p><p>Include plans, materials, learner evidence and changes. Distinguish rehearsal from observed competence.</p><p>Evidence: A status-labelled portfolio.</p><h3>M12-U04 · Maintain and improve</h3><p>Status: specification</p><p>Review problems and evidence after delivery. Correct sources and versions without erasing the history.</p><p>Evidence: A release decision with limits.</p>



---

## M02-U01 — M02-U01 — Give instructions people can act on

Source: 02_website/open-teacher-training-drafts.xml#990040

Delivery: DRAFT_VERIFIED. WordPress ID: 3748.

<h1>M02-U01 — Give instructions people can act on</h1>
<p>Version 0.1.0 · Draft illustration · Module 2
Audience: trainee teachers preparing to teach adults.
Example class: adult English learners, provisionally A2; no real group has been assessed.
Training session: 30 minutes. Embedded classroom task: 3 minutes, not additional to the rehearsal budget. Optional later practice is outside the 30 minutes.</p>
<h2>Outcome and evidence</h2>
<p>By the end, the trainee can give a short instruction for a paired choice task, demonstrate the intended response and revise the instruction after a peer rehearsal.</p>
<p>Evidence: a written instruction, a demonstration, an observation note and a revised version. Peer rehearsal shows preparation, not assessed classroom competence. A later real-classroom observation requires the supported-practice arrangements.</p>
<h2>The classroom task</h2>
<p>Two learners choose one Saturday English-club activity together and give one reason. They can choose a story club, a conversation club or a photo discussion. The exact learner sheet is supplied separately.</p>
<h2>Compare two original illustrative instructions</h2>
<p><strong>Less clear:</strong> “So, what I thought we could perhaps do now, after you have had a look through these possibilities, is consider them together and see whether you can come to some kind of decision and then, once that is done, explain it.”</p>
<p><strong>Clearer for this task:</strong> “Work with a partner. Read the three cards. Choose one activity together. Say why. You have three minutes.”</p>
<p>The first version leaves the grouping, number of choices, output and time unclear. The second states them. This is a task-specific design judgement, not a tested claim that shorter language is always better.</p>
<h2>Demonstrate rather than only describe</h2>
<p>Trainer: “I choose the story club because I like stories. Which activity do you choose?”
Peer: “I choose the photo discussion.”
Trainer: “We need one choice together. Let's choose the photo discussion.”</p>
<p>Use a brief check only where needed: “One activity or three?” Expected answer: “One.” With a group still unsure about grouping, ask or demonstrate who works together. Avoid a ritual series of checks after the action is already clear.</p>
<h2>Thirty-minute sequence</h2>
<table>
<thead>
<tr>
  <th>Stage</th>
  <th style="text-align:right">Minutes</th>
  <th>What happens</th>
</tr>
</thead>
<tbody>
<tr>
  <td>Notice the problem</td>
  <td style="text-align:right">3</td>
  <td>Identify the information missing from the less-clear instruction.</td>
</tr>
<tr>
  <td>Compare models</td>
  <td style="text-align:right">4</td>
  <td>Mark grouping, action, output and time in the clearer version.</td>
</tr>
<tr>
  <td>Inspect a demonstration</td>
  <td style="text-align:right">3</td>
  <td>Explain what the sample exchange makes visible.</td>
</tr>
<tr>
  <td>Write your version</td>
  <td style="text-align:right">5</td>
  <td>Create an instruction for the supplied task and one justified check.</td>
</tr>
<tr>
  <td>Rehearse once</td>
  <td style="text-align:right">4</td>
  <td>One trainee instructs; a peer begins; an observer notes action and questions.</td>
</tr>
<tr>
  <td>Revise and retry</td>
  <td style="text-align:right">6</td>
  <td>Change one source of confusion; repeat; compare notes cautiously.</td>
</tr>
<tr>
  <td>Self-check</td>
  <td style="text-align:right">3</td>
  <td>Use the four criteria below and identify one unresolved issue.</td>
</tr>
<tr>
  <td>Transfer plan</td>
  <td style="text-align:right">2</td>
  <td>Name a different task and what its instruction would need.</td>
</tr>
<tr>
  <td>Total</td>
  <td style="text-align:right">30</td>
  <td>Optional later classroom use is separate.</td>
</tr>
</tbody>
</table>
<h2>Tasks and answer guidance</h2>
<p><strong>T01:</strong> Underline what is missing or ambiguous in the less-clear version. Reasonable answers include the exact grouping, required choice, final response and time. Do not penalise another valid observation.</p>
<p><strong>T02:</strong> Write the instruction and a short demonstration. A possible answer is the clearer instruction above plus the sample exchange. Other concise, accurate versions are acceptable.</p>
<p><strong>T03:</strong> Rehearse, record a specific moment of uncertainty and revise. A good answer includes an observable event and a change linked to it. “It was good” is not sufficient evidence. Do not invent a learner response when no rehearsal occurred.</p>
<h2>Observation criteria</h2>
<p>Can the participant identify the grouping? Can they begin the intended action? Is the required result clear? Does the revision respond to a recorded issue? Record what happened, not a personality judgement.</p>
<p>A peer's success may reflect familiarity with the task. A second attempt may improve through repetition rather than wording alone. Treat these as alternative explanations; use a new task later before generalising.</p>
<h2>Access and adaptation</h2>
<p>The full task works with text, paper and speech. No video or AI is required. For a solo trainee: read both instruction versions, write a script and mark hypothetical difficulties; label this self-rehearsal, not observed learner evidence. For learners needing more support, model one complete exchange and supply “We choose ___ because ___.” For a more demanding variant, require the pair to agree between two different initial preferences without increasing the number of cards.</p>
<h2>Return later</h2>
<p>In a later session, write and rehearse instructions for a different activity, such as matching headings to short texts. Transfer the principles rather than copying the sentence sequence mechanically.</p>
<h2>Files and review</h2>
<p><code>learner-sheet.md</code>, <code>teacher-guide.md</code> and <code>unit.json</code> accompany this example. All dialogues, cards and answer illustrations were written for this kit. The lesson is not a reported classroom trial. No external teacher educator has approved it. The optional open licence remains an owner decision.</p>



---

## M01-U04 — M01-U04 — Set learning goals

Source: 02_website/open-teacher-training-drafts.xml#990041

Delivery: DRAFT_VERIFIED. WordPress ID: 3750.

<h2>M01-U04 — Set learning goals</h2><p>This preserves the earlier URL. The earlier M01-U01 outline is mapped to M01-U04 in the literacy sequence. M01-U01 now diagnoses reading needs.</p><p>Use an observed learner difficulty to write two goals. Name the final action, conditions and evidence. Separate reading comprehension from spelling accuracy.</p><p>Produce a goal card and a baseline task. This is a specification; source input and calibrated examples still need authoring.</p>



---

## M03-U01 — M03-U01 — Check meaning without guessing

Source: 02_website/open-teacher-training-drafts.xml#990042

Delivery: DRAFT_VERIFIED. WordPress ID: 3752.

<h2>M03-U01 — Explain meaning in context</h2><p>Preserved URL and topic. Supply a message and a contextual contrast. Ask meaning checks that do not require more difficult language than the target.</p><p>Produce an analysed example, expected answers and one alternative clarification strategy. This is a specification, not a completed classroom pack.</p>



---

## M09-U02 — M09-U02 — Give usable feedback

Source: 02_website/open-teacher-training-drafts.xml#990043

Delivery: DRAFT_VERIFIED. WordPress ID: 3753.

<h2>M09-U02 — Give usable feedback</h2><p>This preserves the earlier URL. The earlier M09-U01 feedback outline maps to M09-U02. M09-U01 now addresses assessment alignment.</p><p>Point to a text feature and explain its effect on the reader. Ask the writer to choose a change and justify it. Check the revised meaning.</p><p>Produce a before-and-after sample and feedback-decision log. This is a specification; examples still need authoring.</p>



---

## M06-U01 — M06-U01 — Read for evidence

Source: 02_website/open-teacher-training-drafts.xml#991100

Delivery: DRAFT_VERIFIED. WordPress ID: 3737.

<h1>M06-U01 — Read for evidence</h1>
<p>Version 3.0.0. Complete sample; educator review pending.</p>
<h2>Context</h2>
<p>Training: 30 minutes. Classroom illustration: 20 minutes. Estimates only.</p>
<p>Level: A2–B1, provisional. Diagnose before use.</p>
<p>Teacher outcome: Teach learners to justify a reading decision before receiving an answer.</p>
<p>Learner outcome: Distinguish stated facts, contradictions and information not supplied.</p>
<h2>Input — The reading room notice</h2>
<p>Original fictional teaching material. Not a real service notice.</p>
<p>[1] The Harbour Learning Centre is trying a reading room for four Saturdays in November. The room will open from 10:00 until 12:00. There is no entry charge. Visitors can borrow books during the session, but they must return them before leaving.</p>
<p>[2] Adults can attend alone. Children under twelve need an adult with them. The notice does not give a rule for older children. Twelve seats can be reserved by email. The centre will keep four other seats for people who arrive without booking.</p>
<p>[3] Visitors may read their own books or choose from the centre’s collection. They may use a phone to look up a word, but calls must be taken outside. Headphones are needed for audio. There will be a quiet area and a table for discussion.</p>
<p>[4] After the trial, staff will ask visitors what worked. They have not decided whether the room will continue. A local company has offered to donate books, but no donation has arrived yet.</p>
<h2>Worked decision</h2>
<p>Claim: Entry costs nothing. Decision: supported. Evidence: paragraph 1 says there is no entry charge. This does not mean visitors can take books home.</p>
<h2>Sequence</h2>
<ul>
<li>4 minutes: Diagnose and state the purpose.</li>
<li>6 minutes: Model one decision.</li>
<li>8 minutes: Attempt the task.</li>
<li>7 minutes: Compare evidence and revise.</li>
<li>5 minutes: Check independently and plan a return.</li>
</ul>
<h2>T1 — Choose the main purpose.</h2>
<p>A: Announce a permanent library. B: Explain a trial reading room. C: Sell donated books.</p>
<p>Answer guidance: B. Paragraphs 1 and 4 describe a trial without a continuation decision.</p>
<h2>T2 — Classify each statement.</h2>
<p>Write Supported, Contradicted, or Not stated. Cite a paragraph. A: All seats need booking. B: Visitors can bring their own books. C: The room will continue in December. D: Books can be taken home. E: A book donation has arrived. F: Visitors aged thirteen need an adult.</p>
<p>Answer guidance: A Contradicted [2]; four seats do not need booking. B Supported [3]. C Not stated [4]; undecided. D Contradicted [1]; return books before leaving. E Contradicted [4]. F Not stated [2]; the notice leaves older children unspecified.</p>
<h2>T3 — Explain one inference.</h2>
<p>Why might the centre keep some seats unreserved? Give one possible explanation. Mark it as an inference.</p>
<p>Answer guidance: Possible: to include visitors who could not book. This is plausible, not directly stated. Other explanations need a logical link to paragraph 2.</p>
<h2>T4 — Write to a visitor.</h2>
<p>Write 50–70 words for a friend. Include a booking fact, a borrowing rule and one uncertainty.</p>
<p>Answer guidance: Check all three functions. Do not invent December dates or a rule for thirteen-year-olds. Exact wording varies.</p>
<h2>One possible response</h2>
<p>The centre is trying a reading room on four Saturdays in November. You can reserve a seat by email, but four seats are kept for people without bookings. Books must stay at the centre. You can bring your own book. Staff have not decided whether the room will continue, so check before planning a December visit.</p>
<p>Exact wording is not prescribed.</p>
<h2>Feedback</h2>
<p>Ask the learner to locate evidence. Then ask what it rules out. Give the key after that attempt. Correct the reasoning, not just the label.</p>
<h2>Access</h2>
<p>Gloss trial, reserve and donate when needed. Offer numbered paragraphs and print. Let learners answer orally before writing. Record oral support when interpreting writing evidence.</p>
<h2>Return without AI</h2>
<p>Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.</p>
<p>The Riverside Centre will run a repair workshop on three Thursdays in March. Sessions start at 18:00 and finish at 19:30. Entry is free, but replacement parts are charged separately. Eight places must be booked by telephone. There are no walk-in places. Participants should bring one small item. Electrical appliances are not accepted. Tools stay at the centre. Staff will review attendance before deciding whether to add April sessions.</p>
<p>Without AI, classify these claims: every repair costs nothing; all places require booking; April sessions are confirmed. Then write a 40–60 word message explaining one rule and one uncertainty.</p>
<p>Answer guidance: Every repair costs nothing: contradicted; parts cost money. All places require booking: supported. April sessions confirmed: not stated. Message must preserve those distinctions.</p>
<h2>Criteria</h2>
<ul>
<li>Evidence: links claims to relevant wording.</li>
<li>Distinctions: separates support, contradiction and absence.</li>
<li>Writing: includes the requested facts without invention.</li>
<li>Revision: explains one corrected interpretation.</li>
</ul>
<h2>Source and review</h2>
<p>Source anchors: D2, D4, R2, R9. Local input is original fiction. No learner trial or educator approval occurred.</p>



---

## M06-U02 — M06-U02 — Check a summary

Source: 02_website/open-teacher-training-drafts.xml#991101

Delivery: DRAFT_VERIFIED. WordPress ID: 3740.

<h1>M06-U02 — Check a summary</h1>
<p>Version 3.0.0. Complete sample; educator review pending.</p>
<h2>Context</h2>
<p>Training: 35 minutes. Classroom illustration: 25 minutes. Estimates only.</p>
<p>Level: B1–B2, provisional. Diagnose before use.</p>
<p>Teacher outcome: Model source comparison without presenting fluent summaries as evidence.</p>
<p>Learner outcome: Reconcile two source accounts without removing their limitations.</p>
<h2>Input — Two accounts, one claim</h2>
<p>Original fictional teaching material. Not a real service notice.</p>
<p>SOURCE A — Learning-centre trial note, 6 May</p>
<p>[1] Eighteen volunteers attended four lunchtime reading sessions. The sessions combined short articles, discussion and a ten-minute writing task. Fourteen volunteers completed both the opening and closing quizzes. Their average scores rose from six to eight correct answers out of ten.</p>
<p>[2] The quizzes used different articles. Staff did not check whether those articles had the same difficulty. There was no comparison group. Six volunteers said discussion helped them. Others did not answer that question. The centre will repeat the trial before making a decision about expansion.</p>
<p>SOURCE B — Coordinator’s email, 8 May</p>
<p>[3] We are pleased that participants returned. The quiz results are encouraging, but they cannot show which activity caused the change. Some volunteers had attended English classes elsewhere during the same month. We have not tested whether improvements last.</p>
<p>[4] Next time, we will record attendance and ask about other learning. We also need a task using an unfamiliar article. The current results should not be advertised as proof that ten minutes of writing improves everyone’s reading.</p>
<h2>Worked decision</h2>
<p>A claim about score changes is supported by A[1]. A claim about writing causing improvement is not supported. A[2] and B[3] provide alternative explanations.</p>
<h2>Sequence</h2>
<ul>
<li>5 minutes: Diagnose and state the purpose.</li>
<li>7 minutes: Model one decision.</li>
<li>10 minutes: Attempt the task.</li>
<li>8 minutes: Compare evidence and revise.</li>
<li>5 minutes: Check independently and plan a return.</li>
</ul>
<h2>T1 — Identify the sample.</h2>
<p>How many attended? How many completed both quizzes? Why does the difference matter?</p>
<p>Answer guidance: Eighteen attended; fourteen completed both. The score change describes completers, not necessarily every attendee.</p>
<h2>T2 — Audit the summary.</h2>
<p>Flawed summary: “Eighteen learners proved that ten minutes of writing causes a lasting reading improvement. Everyone preferred discussion, so the centre will expand immediately.” Underline unsupported claims.</p>
<p>Answer guidance: Eighteen completers is wrong; only fourteen completed both. “Proved”, “causes”, “lasting”, “everyone” and “expand immediately” are unsupported or contradicted. A[2] and B[3–4] explain why.</p>
<h2>T3 — Rewrite with attribution.</h2>
<p>Write 70–100 words. State the result, sample and two limits. Name the source of one caution.</p>
<p>Answer guidance: Include fourteen completers, six-to-eight quiz result, unequal article difficulty/no comparison/other learning/no follow-up. Attribute the coordinator’s caution. Do not imply the intervention failed or succeeded causally.</p>
<h2>T4 — Explain an uncertainty.</h2>
<p>Tell a partner which finding would change your confidence. Then write one follow-up question.</p>
<p>Answer guidance: Accept a matched comparison, comparable quiz difficulty or delayed unfamiliar-text task. An additional satisfaction survey alone cannot establish causation.</p>
<h2>One possible response</h2>
<p>The centre reports that fourteen volunteers completed both quizzes, with average scores rising from six to eight out of ten. Eighteen people attended the sessions overall. The result does not establish what caused the change: article difficulty was not matched and there was no comparison group. The coordinator also notes that some people attended other English classes. No follow-up test established whether the change lasted. The centre plans another trial before deciding whether to expand.</p>
<p>Exact wording is not prescribed.</p>
<h2>Feedback</h2>
<p>Ask which source supports each clause. Keep a useful result without overclaiming. Do not replace unjustified optimism with unjustified pessimism.</p>
<h2>Access</h2>
<p>Read sources separately, then together. Explain average, comparison group and lasting. Allow first-language planning. Reduce output length before deleting source limitations.</p>
<h2>Return without AI</h2>
<p>Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.</p>
<p>A library tried a reminder message for a writing group. Twenty members received it. Twelve came that week, compared with eight the previous week. It rained heavily during the earlier meeting. The library did not ask whether members read the message. The organiser wrote: “Attendance rose, but we cannot identify the cause from these two meetings.”</p>
<p>Without AI, correct this claim: “The reminder made four extra people attend.” Write 50–70 words preserving the observed change and two limitations.</p>
<p>Answer guidance: Attendance changed from eight to twelve. This does not establish four specific additional people or a reminder effect. Weather differed; receipt/reading was unverified; no comparison group or repeated matched observations.</p>
<h2>Criteria</h2>
<ul>
<li>Accuracy: preserves the sample and result.</li>
<li>Attribution: locates the source of a caution.</li>
<li>Qualification: separates association and cause.</li>
<li>Independence: explains the rewrite without AI.</li>
</ul>
<h2>Source and review</h2>
<p>Source anchors: D4, R1, R6, R7, R9. Local input is original fiction. No learner trial or educator approval occurred.</p>



---

## M07-U01 — M07-U01 — Write for a reader

Source: 02_website/open-teacher-training-drafts.xml#991102

Delivery: DRAFT_VERIFIED. WordPress ID: 3744.

<h1>M07-U01 — Write for a reader</h1>
<p>Version 3.0.0. Complete sample; educator review pending.</p>
<h2>Context</h2>
<p>Training: 30 minutes. Classroom illustration: 25 minutes. Estimates only.</p>
<p>Level: A2–B1, provisional. Diagnose before use.</p>
<p>Teacher outcome: Use a model, a plan and reader response to teach purposeful writing.</p>
<p>Learner outcome: Write a request containing enough information for a useful reply.</p>
<h2>Input — From a notice to a message</h2>
<p>Original fictional teaching material. Not a real service notice.</p>
<p>NOTICE</p>
<p>The Maple Centre runs conversation workshops on Tuesdays at 18:00 and Saturdays at 10:00. Each workshop lasts one hour. A trial visit is free. Booking is required. Write to the coordinator with your preferred session and one learning goal. Ask before bringing a guest. The notice does not describe step-free access.</p>
<p>MODEL MESSAGE</p>
<p>Subject: A Saturday trial visit</p>
<p>Hello,
I would like to attend the Saturday workshop. I want to practise asking questions at work. Is there space this Saturday? Could you also tell me whether the room has step-free access? Please confirm the date before I arrange transport.
Thank you,
Sam</p>
<p>YOUR SITUATION</p>
<p>You work on Saturdays. You want to practise explaining problems to customers. You would like a Tuesday trial. A friend wants to join you. You need confirmation before changing a work shift.</p>
<h2>Worked decision</h2>
<p>The opening identifies the session. The next sentence states the goal. The questions request missing information. The final sentence explains why confirmation matters.</p>
<h2>Sequence</h2>
<ul>
<li>4 minutes: Diagnose and state the purpose.</li>
<li>6 minutes: Model one decision.</li>
<li>8 minutes: Attempt the task.</li>
<li>7 minutes: Compare evidence and revise.</li>
<li>5 minutes: Check independently and plan a return.</li>
</ul>
<h2>T1 — Notice the message functions.</h2>
<p>Mark the session, learning goal, missing information and confirmation request. Which details come from the notice?</p>
<p>Answer guidance: The Saturday time and booking rule come from the notice. The goal, access question and travel reason belong to the writer’s situation. The notice does not guarantee access.</p>
<h2>T2 — Make a four-part plan.</h2>
<p>Write notes: session; goal; guest question; reason for confirmation.</p>
<p>Answer guidance: Tuesday; explaining customer problems; permission for a friend; work-shift arrangements.</p>
<h2>T3 — Write your request.</h2>
<p>Write 70–100 words for the coordinator. Use your situation. Do not copy Sam’s access question unless it is relevant.</p>
<p>Answer guidance: A suitable message names Tuesday, states the customer goal, asks about bringing a friend and requests confirmation before changing a shift. It does not announce an unconfirmed booking.</p>
<h2>T4 — Test it with a reader.</h2>
<p>Ask a partner to list your session, goal and questions. Revise anything the partner misunderstood.</p>
<p>Answer guidance: Revision follows actual reader response. Grammar feedback should not obscure missing information. Accept different register choices that suit the relationship.</p>
<h2>One possible response</h2>
<p>Hello, I would like to book a trial visit for a Tuesday conversation workshop. I work on Saturdays, so I cannot attend that session. My learning goal is to practise explaining problems to customers in English. Is there a place available next Tuesday at 18:00? A friend would also like to come. Could you tell me whether guests can join a trial session? Please confirm the date and both places before I ask to change my work shift. Thank you.</p>
<p>Exact wording is not prescribed.</p>
<h2>Feedback</h2>
<p>Respond as the coordinator first. Say what you can answer. Point out any missing decision. Then select one language feature to improve.</p>
<h2>Access</h2>
<p>Offer sentence openings after planning. Permit handwriting or typing. Allow oral rehearsal but retain an independent written attempt. Teach script or spelling support separately when needed.</p>
<h2>Return without AI</h2>
<p>Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.</p>
<p>A neighbourhood workshop offers a Wednesday photography walk at 16:00 or a Sunday indoor session at 11:00. Booking is required. The first visit costs nothing. Participants should ask whether equipment can be borrowed. You are available only on Sundays. You want to practise describing photographs in English. You do not own a camera.</p>
<p>Without AI, write 60–90 words asking for a Sunday place, explaining your goal and asking about equipment. Request confirmation.</p>
<p>Answer guidance: Message should contain Sunday, describing photographs, equipment question and confirmation. No invented promise of a camera or available place.</p>
<h2>Criteria</h2>
<ul>
<li>Purpose: gives the reader a clear request.</li>
<li>Content: includes required facts and questions.</li>
<li>Organisation: orders information for a reply.</li>
<li>Language: communicates meaning with appropriate support.</li>
</ul>
<h2>Source and review</h2>
<p>Source anchors: D5, R4, R9, R10. Local input is original fiction. No learner trial or educator approval occurred.</p>



---

## M07-U02 — M07-U02 — Revise without losing meaning

Source: 02_website/open-teacher-training-drafts.xml#991103

Delivery: DRAFT_VERIFIED. WordPress ID: 3746.

<h1>M07-U02 — Revise without losing meaning</h1>
<p>Version 3.0.0. Complete sample; educator review pending.</p>
<h2>Context</h2>
<p>Training: 35 minutes. Classroom illustration: 30 minutes. Estimates only.</p>
<p>Level: B1–B2, provisional. Diagnose before use.</p>
<p>Teacher outcome: Teach accept, adapt and reject decisions using reader evidence.</p>
<p>Learner outcome: Evaluate feedback and revise a message while preserving its intention.</p>
<h2>Input — The workshop invitation</h2>
<p>Original fictional teaching material. Not a real service notice.</p>
<p>WRITER’S INTENTION</p>
<p>Invite beginners to a free Saturday writing workshop. It starts at 10:00 and ends at 11:30. Ten places are available. Booking is required. Participants may bring paper or a laptop. The organiser has not confirmed step-free access. The workshop offers practice and peer response, not certificates.</p>
<p>FIRST DRAFT</p>
<p>Come to our writing thing on Saturday. Everyone can come and there is lots of time. Bring something. You will become a great writer. You can get a certificate. Tell people.</p>
<p>READER RESPONSE</p>
<p>“What time does it start? Do I need to book? I use a wheelchair. I cannot tell whether I can enter the room. Do I need a laptop?”</p>
<p>SUGGESTIONS FROM AN ILLUSTRATIVE AI REVIEW</p>
<p>A. Add the start and finish times.
B. Say that the room is fully accessible.
C. Remove the certificate promise.
D. Replace the invitation with an academic essay.
E. Explain what people can bring.
F. Say that places require booking.</p>
<h2>Worked decision</h2>
<p>Accept A because the reader needs times. Reject B because access is unconfirmed. Adapt E into a choice: paper or laptop. Feedback is a proposal, not an authority.</p>
<h2>Sequence</h2>
<ul>
<li>5 minutes: Diagnose and state the purpose.</li>
<li>7 minutes: Model one decision.</li>
<li>10 minutes: Attempt the task.</li>
<li>8 minutes: Compare evidence and revise.</li>
<li>5 minutes: Check independently and plan a return.</li>
</ul>
<h2>T1 — Find meaning problems.</h2>
<p>Identify three conflicts between the intention and draft. Distinguish missing facts from invented promises.</p>
<p>Answer guidance: Missing: times, capacity, booking, equipment options. Invented: guaranteed writing success and certificates. “Everyone can come” ignores capacity and unconfirmed access.</p>
<h2>T2 — Judge each suggestion.</h2>
<p>Mark Accept, Adapt or Reject. Give a reason grounded in intention or reader response.</p>
<p>Answer guidance: A accept; B reject; C accept; D reject; E accept/adapt; F accept. Alternatives need a defensible explanation. Do not replace author judgement with a rigid label test.</p>
<h2>T3 — Write the revision.</h2>
<p>Write 90–120 words. Preserve the invitation. Include time, capacity, booking and equipment. Handle access uncertainty without inventing an answer.</p>
<p>Answer guidance: A suitable invitation states known details, describes practice and peer response, and asks people needing access information to contact the organiser before booking. It does not promise accessibility or certificates.</p>
<h2>T4 — Record the decisions.</h2>
<p>Explain one acceptance, one adaptation and one rejection. Ask a reader to answer the original questions.</p>
<p>Answer guidance: Evidence should show what changed and why. Reader success matters more than whether the AI’s preferred phrasing was used.</p>
<h2>One possible response</h2>
<p>Join our writing workshop this Saturday from 10:00 to 11:30. Beginners are welcome, and the session is free. We have ten places, so please book before coming. Bring paper or a laptop, whichever suits you. During the workshop, you will practise writing and exchange responses with another participant. This is a practice session, not a certificate course. Step-free access has not yet been confirmed. Please contact the organiser before booking if you need access information. We will check the room details rather than promise something we cannot verify. We look forward to hearing your ideas.</p>
<p>Exact wording is not prescribed.</p>
<h2>Feedback</h2>
<p>Review intention and content first. Check factual accuracy next. Then improve organisation and language. Keep the original and revised versions together.</p>
<h2>Access</h2>
<p>Offer a decision table. Read suggestions aloud if needed. Allow additional planning time. Do not mark assistive access as AI dependence.</p>
<h2>Return without AI</h2>
<p>Use after 2–7 days. This interval is a pilot choice. Keep access accommodations.</p>
<p>A community group plans a free listening circle on Thursday from 17:00 to 18:00. Six places require booking. Attendees can speak or listen. Recording is not allowed. The draft says: “Everyone must speak. Bring your phone and record the discussion. Arrive sometime after five.” A suggested rewrite adds a certificate and changes the meeting to Friday.</p>
<p>Without AI, write a 70–100 word correction. Preserve choice, timing, capacity and the recording rule. Explain two rejected changes.</p>
<p>Answer guidance: State Thursday 17:00–18:00, six booked places, choice to speak or listen, no recording. Reject Friday and certificate claims. Do not infer any other participation requirement.</p>
<h2>Criteria</h2>
<ul>
<li>Intention: preserves purpose and audience.</li>
<li>Truth: corrects invention and uncertainty.</li>
<li>Revision: responds to reader needs.</li>
<li>Agency: explains accepted and rejected suggestions.</li>
</ul>
<h2>Source and review</h2>
<p>Source anchors: D5, R4, R6, R8. Local input is original fiction. No learner trial or educator approval occurred.</p>



---

## OTT-BLUEPRINT — Blueprint — Read. Write. Understand.

Source: 01_blueprints/pages.json

Delivery: PLATFORM_HOLD. WordPress ID: none.

<h2>The blueprint, page by page</h2><p>Version 3.0.0 · 30 September 2026. Educator review remains pending.</p><p>Twenty pages preserve the revised blueprint. Each explains one part of the learning system. The course, sample packs and supporting guides remain separate creations.</p><p><a href="https://drive.google.com/file/d/1qsgSGdqEnYcxZvrmACWLY9Cow6wuxnGo/view">Blueprint PDF on Drive</a>. The file retains its existing access controls.</p>



---

## P01 — P01 — Read. Write. Understand.

Source: 01_blueprints/pages/P01.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>The revised purpose</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>The commitment</h2><p>Keep access free. Build teaching through evidence. Put literacy at the centre. Use technology for practice. Preserve human judgement.</p><h2>What changed</h2><p>The earlier twelve modules remain. Reading and writing become threads. Source evaluation joins comprehension. Revision becomes visible evidence.</p><h2>What this release is</h2><p>This is a curriculum candidate. Four literacy packs are complete. One earlier instruction pack remains. Forty-eight unit specifications guide expansion. Specifications are not finished lessons.</p><h2>What it is not</h2><p>It does not award CELTA. It claims no Cambridge affiliation. It proves no superior outcomes. Supported practice requires people.</p><p>Source IDs: C1, C2. See the evidence register.</p>



---

## P02 — P02 — Start with the sources

Source: 01_blueprints/pages/P02.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Keep, adapt, extend</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Keep</h2><p>Needs analysis, language awareness, practice. Keep observation and learner feedback. Keep purposeful texts and models.</p><h2>Adapt</h2><p>Replace rigid timing with estimates. Choose stages around the outcome. Distinguish centre rules from requirements.</p><h2>Extend</h2><p>Add cross-source reading and mediation. Record writing changes and reasons. Assess performance without AI assistance.</p><h2>Evidence boundary</h2><p>The source folder contains ten documents. The glossary is from 2008. Guidance notes include 2016 dates. The published syllabus is July 2024. Dates alone do not establish effectiveness.</p><p>Source IDs: C1, D2, D3, D4, D5, D6. See the evidence register.</p>



---

## P03 — P03 — What CELTA already contains

Source: 01_blueprints/pages/P03.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Avoid a false contrast</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Published coverage</h2><p>Writing includes processes and literacy. Materials include technology and adaptation. Classrooms include online environments. These are not absent foundations.</p><h2>Centre frameworks</h2><p>Your writing guide models texts. It includes planning and feedback. The summary also includes editing. It explicitly allows framework adaptation.</p><h2>Our difference</h2><p>We propose more sustained literacy. We make sources inspectable. We expose drafts and revisions. We offer internet and print routes.</p><h2>The comparison rule</h2><p>Compare teaching, support and outcomes. Do not compare logos alone. Do not equate headline hours.</p><p>Source IDs: C1, C2, D3, D5. See the evidence register.</p>



---

## P04 — P04 — Attention is a design condition

Source: 01_blueprints/pages/P04.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Not a generational diagnosis</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>What evidence supports</h2><p>PISA reports reading-performance declines. It studies fifteen-year-old students. It does not establish adult deficits. It cannot isolate one cause.</p><h2>What we will not claim</h2><p>No universal attention timer is established here. We reject an eight-second curriculum. Not everyone dislikes reading.</p><h2>What we will test</h2><p>Begin with one bounded task. Hide answers until an attempt. Offer breaks and return points. Extend practice after successful comprehension.</p><h2>Measure the right things</h2><p>Record explanations, not watch-time alone. Compare drafts, not posting frequency. Ask learners about barriers.</p><p>Source IDs: R1, R3. See the evidence register.</p>



---

## P05 — P05 — Chunks must lead to depth

Source: 01_blueprints/pages/P05.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Entry, practice, transfer</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Entry</h2><p>One question opens the unit. Read a short source extract. Identify one decision or difficulty.</p><h2>Practice</h2><p>Use a model and attempt. Return to the whole text. Add evidence and revise meaning.</p><h2>Transfer</h2><p>Read an unseen passage. Write for a changed audience. Explain choices without automated help.</p><h2>Pilot duration bands</h2><p>Try 3–6 minutes for entry. Try 15–25 minutes for practice. Try 30–45 minutes for transfer. These are adjustable design estimates. Accessibility needs take precedence.</p><p>Source IDs: R3, R5. See the evidence register.</p>



---

## P06 — P06 — One loop, two audiences

Source: 01_blueprints/pages/P06.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Trainees and language learners</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Learner evidence</h2><p>Read, locate, infer, explain. Plan, draft, revise, respond. Speak to negotiate intended meaning.</p><h2>Trainee evidence</h2><p>Design tasks around those actions. Predict and diagnose a difficulty. Model one strategy explicitly. Observe responses before giving feedback.</p><h2>Do not mix clocks</h2><p>Training may take thirty minutes. Its example may take five. Label both durations and outcomes.</p><h2>Return</h2><p>Use a changed task later. Remove hints for that check. Retain access accommodations throughout.</p><p>Source IDs: D4, D5, R4, R5. See the evidence register.</p>



---

## P07 — P07 — Twelve modules remain

Source: 01_blueprints/pages/P07.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Literacy crosses the programme</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>M01–M04</h2><p>Diagnose needs and access. Plan and give instructions. Teach grammar for meaning. Develop vocabulary in texts.</p><h2>M05–M08</h2><p>Connect sound, print and meaning. Teach reading and listening. Teach writing through reader response. Adapt access and participation.</p><h2>M09–M12</h2><p>Assess transfer and revision. Publish for web and print. Evaluate AI and source claims. Demonstrate teaching through a portfolio.</p><h2>What is ready</h2><p>Four unit designs per module. Five complete sample packs overall. Remaining specifications require authoring. The curriculum booklet identifies status.</p><p>Source IDs: C1, R9. See the evidence register.</p>



---

## P08 — P08 — Reading: beyond answer hunting

Source: 01_blueprints/pages/P08.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Model the invisible decisions</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Understand</h2><p>Set a reading purpose. Notice vocabulary and sentence relations. Identify references and implied meaning.</p><h2>Interrogate</h2><p>Separate statement from inference. Locate the supporting sentence. Compare a second source. Notice absence and uncertainty.</p><h2>Teach</h2><p>Model one difficult inference. Let learners attempt another. Ask what changed their interpretation.</p><h2>Assess</h2><p>Use an unseen comparable passage. Ask for evidence and explanation. Do not assess speed alone. Audio support changes the measured construct; record its use.</p><p>Source IDs: D4, R2, R9. See the evidence register.</p>



---

## P09 — P09 — Writing: meaning before polish

Source: 01_blueprints/pages/P09.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>A reader must do something</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Design</h2><p>Identify audience and purpose. Read a model for function. Plan the information order.</p><h2>Compose</h2><p>Write before requesting AI help. Keep the draft and decisions. Use examples without copying meaning.</p><h2>Revise</h2><p>Check the reader’s response. Address meaning and organisation first. Then inspect language and conventions.</p><h2>Assess</h2><p>Use a changed purpose later. Ask the writer to explain. Preserve voice and intended meaning. Fluency is not only speaking.</p><p>Source IDs: D2, D5, R4. See the evidence register.</p>



---

## P10 — P10 — Speaking supports literacy

Source: 01_blueprints/pages/P10.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Keep all four skills</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Before writing</h2><p>Rehearse an explanation with someone. Ask what remains unclear. Use notes, not memorised paragraphs.</p><h2>After reading</h2><p>Summarise without looking at sentences. Compare interpretations with a partner. Return to evidence after disagreement.</p><h2>After drafting</h2><p>Ask a reader to respond. Record misunderstanding without blaming them. Revise the message accordingly.</p><h2>Listening and pronunciation</h2><p>Use supplied scripts or recordings. Replay a troublesome stretch. Connect stress with intended meaning. Target intelligibility, not accent imitation.</p><p>Source IDs: D2, D6, R9. See the evidence register.</p>



---

## P11 — P11 — Media follows the task

Source: 01_blueprints/pages/P11.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Do not replace reading</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Website</h2><p>The complete learning route lives here. Use HTML for text and tasks. Keep sources, answers and downloads together.</p><h2>Video</h2><p>Show one teaching decision. Add captions and a transcript. Pause for an actual learner attempt. Do not make streaming compulsory.</p><h2>LinkedIn</h2><p>Publish a problem and example. Link back to the practice. Treat reactions as discovery evidence.</p><h2>Print and audio</h2><p>Provide printable workbooks. Audio supports access and rehearsal. Reading assessment still needs text. Declare accommodations and task changes.</p><p>Source IDs: T1, R2, R10. See the evidence register.</p>



---

## P12 — P12 — The website section

Source: 01_blueprints/pages/P12.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Preserve the earlier architecture</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>The route</h2><p>Start → Course → Methods → Materials → Practice. Keep existing module IDs and slugs. Add a literacy pilot entry.</p><h2>One page</h2><p>Show an outcome and input. Add an attempt and feedback. Link a next task and sources.</p><h2>WordPress</h2><p>Use draft Pages as before. Check existing slugs before importing. Update existing pages by verified ID. Do not import duplicate trees.</p><h2>What ships</h2><p>An offline HTML learning hub. An updated WordPress draft export. No hosting or menu changed. No student submissions are collected.</p><p>Source IDs: T1. See the evidence register.</p>



---

## P13 — P13 — AI assists; learners decide

Source: 01_blueprints/pages/P13.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Separate use from learning</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Before AI</h2><p>Attempt the reading or draft. Record the difficulty in words. Select the assistance being requested.</p><h2>During AI</h2><p>Request a hint or question. Check claims against the source. Reject invented evidence or meaning.</p><h2>After AI</h2><p>Explain which suggestions were accepted. Revise using that explanation. Try another task without AI.</p><h2>Evidence balance</h2><p>Research supports some designed tutors. Other designs harmed later performance. Neither result proves universal benefit. Our literacy design still needs trials.</p><p>Source IDs: R6, R7, R8. See the evidence register.</p>



---

## P14 — P14 — Choose models through tests

Source: 01_blueprints/pages/P14.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Not brand or size alone</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Drafting candidate</h2><p>Mistral Small 4 is documented. Test hosted access before use. Do not assume laptop feasibility.</p><h2>Local candidate</h2><p>Ministral 3 3B is documented. Give one stage per turn. Verify memory and runtime first.</p><h2>Review</h2><p>Use source-bound checks and a rubric. A second pass may help. It is not independent validation. Human review remains necessary.</p><h2>Timing</h2><p>Temperature 0.8 is not seconds. Measure first-token and completion separately. Log failures, costs and revisions. Do not promise instant complete packs.</p><p>Source IDs: T3, T4, T5. See the evidence register.</p>



---

## P15 — P15 — Skills and workflows differ

Source: 01_blueprints/pages/P15.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>One procedure; one source</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Skill</h2><p>Stores when and how to act. Loads only relevant supporting files. Produces a reviewable lesson candidate.</p><h2>Agent</h2><p>Combines instructions, model and tools. It needs actual source access. A name grants no capabilities.</p><h2>Workflow</h2><p>Coordinates repeated execution and state. It needs implementation and permissions. It is optional for the pilot.</p><h2>Publishing</h2><p>Requires a separate explicit action. Verify the destination and receipt. Keep keys outside prompts. Avoid duplicate schedulers.</p><p>Source IDs: T3, T6. See the evidence register.</p>



---

## P16 — P16 — Assess learning, not production

Source: 01_blueprints/pages/P16.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Separate four status fields</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Learning evidence</h2><p>Baseline → supported attempt → delayed transfer. Compare task demands and conditions. Record source-use and revision quality.</p><h2>Teaching evidence</h2><p>Observe lessons with real learners. Retain plans and feedback. Rehearsal does not count as teaching.</p><h2>Technical evidence</h2><p>Passing checks confirms only their scope. It does not establish classroom effectiveness. It does not confer approval.</p><h2>Status</h2><p>Work: candidate or reviewed. Validation: static or executed checks. Approval: pending or named decision. Deployment: not deployed or verified.</p><p>Source IDs: C2, D1, R6. See the evidence register.</p>



---

## P17 — P17 — Two hundred hours: still provisional

Source: 01_blueprints/pages/P17.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>An activity budget, not equivalence</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Allocation</h2><p>Study and demonstrations: 40 hours. Observation: 20 hours. Planning and materials: 60 hours. Real teaching: 12 hours. Feedback and revision: 40 hours. Assessment and portfolio: 28 hours.</p><h2>Accounting</h2><p>Count each activity once. Module work draws from this budget. Breaks and retries are recorded separately.</p><h2>Support</h2><p>No twelve-hour placement is guaranteed. Mentors and learner groups need confirmation. Self-study cannot replace observed practice.</p><h2>Capacity example</h2><p>Six trainees need 72 observation hours. Feedback time comes in addition. This arithmetic is not funded provision.</p><p>Source IDs: C2. See the evidence register.</p>



---

## P18 — P18 — Test before expanding

Source: 01_blueprints/pages/P18.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>A bounded pilot</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Week one</h2><p>Review sources and page usability. Test M06-U01 with three volunteers. Record misunderstandings and access problems.</p><h2>Weeks two and three</h2><p>Try summary checking and writing. Compare initial and revised work. Make one targeted change per failure.</p><h2>Week four</h2><p>Run delayed transfer tasks. Ask participants to explain decisions. Have an educator review samples.</p><h2>Expansion gate</h2><p>All core tasks must be usable. No unresolved factual or access blocker. Report actual completion and missing data. A pilot cannot prove CELTA superiority.</p><p>Source IDs: R4, R5. See the evidence register.</p>



---

## P19 — P19 — Protect people; publish evidence

Source: 01_blueprints/pages/P19.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>An internet-ready release</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Public material</h2><p>Publish original models and tasks. Include sources, versions and limitations. Keep a correction route visible.</p><h2>Private material</h2><p>Exclude candidate grades and identifiers. Do not upload student work without permission. Do not republish centre handouts wholesale.</p><h2>Maintainability</h2><p>Keep Markdown and JSON as sources. Generate web pages and PDFs. Archive superseded versions without activating them.</p><h2>Future readiness</h2><p>Review evidence each term. Recheck model availability before use. Change tools without changing learning outcomes. Predictions remain design scenarios.</p><p>Source IDs: D1, R8, T1. See the evidence register.</p>



---

## P20 — P20 — What changed; what remains

Source: 01_blueprints/pages/P20.md

Delivery: DEPENDENCY_HOLD. WordPress ID: none.

<p>Read the evidence register</p><p>Version 3.0.0 · 30 September 2026 · Educator review pending.</p><h2>Completed here</h2><p>Inventory of all 88 baseline files. Revision mapping for 66 guide pages. Twelve modules with 48 specifications. Four new literacy pilot packs. Updated skill, website and Mistral adapter.</p><h2>Still untested</h2><p>The complete 200-hour delivery. Educator approval and learner trials. Target model and account integration. Full accessibility conformance.</p><h2>Source gaps</h2><p>The internal page link was unavailable. The novel note contains progress only. No Oxford curriculum was supplied. Neither was invented or substituted.</p><h2>Next use</h2><p>Open the HTML hub. Read M06-U01. Try its source-and-evidence task. Record one concrete improvement.</p><p>Source IDs: C1, D2, R1, R3, R4, R6, R7. See the evidence register.</p>



---

## OTT-SOURCES — Evidence review and sources

Source: 08_evidence/SOURCE_REGISTER.md

Delivery: DRAFT_VERIFIED. WordPress ID: 3757.

<h1>Sources and boundaries</h1><p class="tag">CANDIDATE · EDUCATOR REVIEW PENDING</p><p>Evidence, scope and proposals remain separate.</p><section class="card" id="C1"><h2>C1 · Cambridge: CELTA syllabus and assessment guidelines</h2><p>official specification · July 2024</p><p>Covers adult literacy, writing processes, online classrooms and digital materials. Includes five integrated topic areas.</p><p><strong>Limit:</strong> A specification does not establish implementation quality. No course-equivalence assessment was performed.</p><p><strong>Our proposal:</strong> Retain all five areas. Extend literacy practice and digital evaluation.</p><p>Location: pp. 4–5, 8–11, 13–18</p><p><a href="https://www.cambridgeenglish.org/Images/21816-celta-syllabus.pdf">Read the source</a></p></section><section class="card" id="C2"><h2>C2 · Cambridge: CELTA course requirements</h2><p>official requirements · 2026-09-30</p><p>At least 120 tutor-contact hours; allow 80 additional learning hours. Six assessed teaching hours and six directed-observation hours. Online and mixed formats are offered.</p><p><strong>Limit:</strong> Our 200-hour estimate is not 120 hours of tutor contact. Hours alone cannot show equivalent provision.</p><p><strong>Our proposal:</strong> Separate self-study, mentorship, rehearsal and real teaching.</p><p>Location: Course in detail; assessment</p><p><a href="https://www.cambridgeenglish.org/educators-organisations/professional-development/teaching-qualifications/celta/about/">Read the source</a></p></section><section class="card" id="C3"><h2>C3 · Cambridge: generative AI guidance</h2><p>official guidance · Accessed 2026-09-30</p><p>Addresses AI use in assessed work, attribution and centre guidance.</p><p><strong>Limit:</strong> Does not endorse this project or validate AI outputs.</p><p><strong>Our proposal:</strong> Teach attribution and verification. Never claim AI is absent from CELTA.</p><p>Location: pp. 1–2</p><p><a href="https://www.cambridgeenglish.org/Images/745146-guidance-for-use-of-generative-ai-tools-on-celta-and-delta.pdf">Read the source</a></p></section><section class="card" id="D1"><h2>D1 · Supplied candidate record booklet</h2><p>user-supplied private record · C1/2026</p><p>Confirms teaching practice, assignments, feedback and portfolio responsibilities.</p><p><strong>Limit:</strong> Contains personal records. Not reproduced or linked publicly. No appeal or grade review undertaken.</p><p><strong>Our proposal:</strong> Use assessment structure only. Keep personal records outside the release.</p><p>Location: Course requirements; candidate responsibilities; assessment overview</p><p>Owner-supplied source. Original not redistributed.</p></section><section class="card" id="D2"><h2>D2 · Neil Anderson: glossary of CELTA terms</h2><p>user-supplied glossary · February 2008</p><p>Prioritises teaching over terminology. Defines MFPA, feedback, meaning checks and instruction checks.</p><p><strong>Limit:</strong> Local catchphrases and numerical rules are not universal empirical laws.</p><p><strong>Our proposal:</strong> Preserve distinctions. Qualify fixed encounter counts, time caps and talk ratios.</p><p>Location: pp. 1–7; supplied A_GLOSSARY_OF_COMMON_CELTA_TERMS2.docx</p><p>Owner-supplied source. Original not redistributed.</p></section><section class="card" id="D3"><h2>D3 · Blue Lesson Frameworks: summary</h2><p>centre guidance · Supplied folder; date not established</p><p>States frameworks can be adapted. Writing includes editing, correction and publishing.</p><p><strong>Limit:</strong> Centre guidance is not identical to Cambridge regulations.</p><p><strong>Our proposal:</strong> Adapt, rather than reject, the sequence.</p><p>Location: Framework summary; writing sequence</p><p>Owner-supplied source. Original not redistributed.</p></section><section class="card" id="D4"><h2>D4 · Simon Brooks: Reading guidance</h2><p>centre guidance · 2016</p><p>Includes purposeful reading, detailed comprehension and text-based justification.</p><p><strong>Limit:</strong> Timings and vocabulary counts belong to an illustrative template.</p><p><strong>Our proposal:</strong> Add cross-source checking and independent transfer.</p><p>Location: 45-minute template; detailed-reading stage</p><p>Owner-supplied source. Original not redistributed.</p></section><section class="card" id="D5"><h2>D5 · Simon Brooks: Writing guidance</h2><p>centre guidance · 2016</p><p>Uses model texts, genre analysis, planning, supported writing and reader feedback.</p><p><strong>Limit:</strong> The example is a 45-minute lesson, not the full writing curriculum.</p><p><strong>Our proposal:</strong> Extend drafting into documented revision and delayed transfer.</p><p>Location: Single-page table; visually inspected</p><p>Owner-supplied source. Original not redistributed.</p></section><section class="card" id="D6"><h2>D6 · Other supplied lesson frameworks</h2><p>centre guidance · 2016 where marked</p><p>Listening, speaking, grammar, lexis and functions connect context, comprehension, language analysis, practice and feedback. Stage-name guidance distinguishes clarification from whole-lesson frameworks.</p><p><strong>Limit:</strong> Text inspected for all seven. Not every layout was visually inspected.</p><p><strong>Our proposal:</strong> Retain these foundations across modules. Track source terminology rather than silently harmonising it.</p><p>Location: Seven remaining documents: Listening; Speaking; grammar text; lexis text; functional language text; situational lexis; Stage names &amp; Aims</p><p>Owner-supplied source. Original not redistributed.</p></section><section class="card" id="R1"><h2>R1 · OECD: PISA 2025 Results, Volume I</h2><p>international assessment report · 8 September 2026</p><p>Reports declining reading performance across OECD countries. Reading scores fell 28 points between 2015 and 2025.</p><p><strong>Limit:</strong> Participants are 15-year-olds. Associations do not establish technological causation or adult language-learning effects.</p><p><strong>Our proposal:</strong> Prioritise comprehension and evidence evaluation; do not stereotype a generation.</p><p>Location: Overview and key findings</p><p><a href="https://www.oecd.org/en/publications/pisa-2025-results-volume-i_73451bc5-en.html">Read the source</a></p></section><section class="card" id="R2"><h2>R2 · Clinton: Reading from paper compared to screens</h2><p>systematic review and meta-analysis · 2019</p><p>Across 33 studies, paper showed a comprehension advantage, especially for expository texts; narrative differences were not clear.</p><p><strong>Limit:</strong> Results vary by task and design. Not proof that digital learning cannot work.</p><p><strong>Our proposal:</strong> Offer print and screen routes. Preserve text and purposeful rereading.</p><p>Location: Abstract; moderator results</p><p><a href="https://onlinelibrary.wiley.com/doi/full/10.1111/1467-9817.12269">Read the source</a></p></section><section class="card" id="R3"><h2>R3 · Rey et al.: A meta-analysis of the segmenting effect</h2><p>meta-analysis · 2019</p><p>Meaningful, coherent segments supported retention and transfer in multimedia learning.</p><p><strong>Limit:</strong> Does not establish a universal five-minute lesson or an eight-second attention span.</p><p><strong>Our proposal:</strong> Segment by meaning. Let users control pacing. Build longer practice afterwards.</p><p>Location: Abstract; 56 investigations</p><p><a href="https://doi.org/10.1007/s10648-018-9456-4">Read the source</a></p></section><section class="card" id="R4"><h2>R4 · IES: Teaching Secondary Students to Write Effectively</h2><p>evidence-based practice guide · 2016; revised 2019</p><p>Recommends Model–Practice–Reflect, integrated reading/writing and using assessment to guide writing instruction.</p><p><strong>Limit:</strong> Grades 6–12. Adaptation to adult ELT is a design inference, not a demonstrated effect here.</p><p><strong>Our proposal:</strong> Include models, drafts, feedback decisions and revision.</p><p>Location: Recommendations 1–3</p><p><a href="https://ies.ed.gov/ncee/wwc/practiceguide/22">Read the source</a></p></section><section class="card" id="R5"><h2>R5 · Agarwal, Nunes &amp; Blunt: Retrieval practice in classrooms</h2><p>systematic review · 2021</p><p>Classroom experiments generally support retrieval practice across varied settings.</p><p><strong>Limit:</strong> Most included research came from WEIRD settings. Recall alone does not establish writing transfer.</p><p><strong>Our proposal:</strong> Add return tasks and changed-context performance, not only recognition quizzes.</p><p>Location: Abstract; 50 experiments</p><p><a href="https://doi.org/10.1007/s10648-021-09595-9">Read the source</a></p></section><section class="card" id="R6"><h2>R6 · Bastani et al.: Generative AI without guardrails can harm learning</h2><p>randomised field experiment · 2025</p><p>Nearly 1,000 Turkish high-school maths learners received different GPT-4 interfaces. Unrestricted assistance improved practice but reduced later unassisted performance; teacher-designed hints mitigated this harm.</p><p><strong>Limit:</strong> One school, maths, short-term outcomes, 2023 deployment. Not direct evidence about adult ELT writing.</p><p><strong>Our proposal:</strong> Attempt first. Use hints. Assess later without AI.</p><p>Location: Abstract; discussion</p><p><a href="https://doi.org/10.1073/pnas.2422633122">Read the source</a></p></section><section class="card" id="R7"><h2>R7 · Kestin et al.: AI tutoring compared with active learning</h2><p>randomised crossover trial · 2025</p><p>A designed AI tutor improved short-term learning relative to an active-learning class in introductory college physics.</p><p><strong>Limit:</strong> Two lesson topics, one university context. Not evidence that any chatbot replaces teachers.</p><p><strong>Our proposal:</strong> Test purpose-built tutoring rather than rejecting or celebrating AI wholesale.</p><p>Location: Methods; results; discussion</p><p><a href="https://doi.org/10.1038/s41598-025-97652-6">Read the source</a></p></section><section class="card" id="R8"><h2>R8 · UNESCO: AI competency framework for teachers</h2><p>competency framework · 2024</p><p>Organises teacher AI competence around human agency, ethics, foundations, pedagogy and professional learning.</p><p><strong>Limit:</strong> A normative framework, not a trial proving learning gains.</p><p><strong>Our proposal:</strong> Teach judgement and privacy alongside prompts and tools.</p><p>Location: Framework overview</p><p><a href="https://www.iicba.unesco.org/fr/africa-education-knowledge-platform/ai-competency-framework-teachers">Read the source</a></p></section><section class="card" id="R9"><h2>R9 · Council of Europe: CEFR Companion Volume</h2><p>language-education framework · 2020</p><p>Extends descriptors to mediation, online interaction and plurilingual competence.</p><p><strong>Limit:</strong> No formal CEFR alignment or level validation was performed for these materials.</p><p><strong>Our proposal:</strong> Use observable tasks and provisional level labels.</p><p>Location: Publication overview</p><p><a href="https://www.coe.int/en/web/education/newsroom/-/asset_publisher/fkf5o6A9gZZK/content/id/63912058">Read the source</a></p></section><section class="card" id="R10"><h2>R10 · Council of Europe: Online interaction in the classroom</h2><p>professional guidance · Accessed 2026-09-30</p><p>Connects synchronous and asynchronous online interaction with action-oriented language tasks.</p><p><strong>Limit:</strong> Guidance is not evidence for any one platform.</p><p><strong>Our proposal:</strong> Use reader replies and collaboration, not engagement clicks.</p><p>Location: Overview</p><p><a href="https://www.coe.int/en/web/common-european-framework-reference-languages/online-interaction-in-the-classroom">Read the source</a></p></section><section class="card" id="T1"><h2>T1 · W3C: WCAG 2 overview</h2><p>accessibility standard overview · Accessed 2026-09-30</p><p>WCAG 2.2 provides testable accessibility criteria for web content.</p><p><strong>Limit:</strong> This release has not undergone a full accessibility conformance audit.</p><p><strong>Our proposal:</strong> Test keyboard access, contrast, reflow and text alternatives.</p><p>Location: What is in WCAG; conformance</p><p><a href="https://www.w3.org/WAI/standards-guidelines/wcag/">Read the source</a></p></section><section class="card" id="T2"><h2>T2 · W3C: Use Clear Words</h2><p>supplemental accessibility guidance · 2021; web presentation 2022</p><p>Recommends explaining unfamiliar terminology and using clear labels.</p><p><strong>Limit:</strong> Supplemental guidance is not itself a WCAG conformance requirement.</p><p><strong>Our proposal:</strong> Explain terms in context; retain disciplinary precision.</p><p>Location: What to do; getting started</p><p><a href="https://www.w3.org/WAI/WCAG2/supplemental/patterns/o3p01-clear-words/">Read the source</a></p></section><section class="card" id="T3"><h2>T3 · Mistral: Create a Skill in Studio</h2><p>official product documentation · Accessed 2026-09-30</p><p>Skills store activation conditions, procedures and supporting files. Visibility, versioning and tests are separate concerns.</p><p><strong>Limit:</strong> Account UI and availability were not tested. September screenshots may differ.</p><p><strong>Our proposal:</strong> Use one canonical skill and a thin adapter.</p><p>Location: Steps 1–8</p><p><a href="https://docs.mistral.ai/getting-started/quickstarts/studio/create-skill">Read the source</a></p></section><section class="card" id="T4"><h2>T4 · Mistral: Small 4 model card</h2><p>official model specification · 16 March 2026; checked 2026-09-30</p><p>Lists mistral-small-2603, structured outputs and tool support. It has 119B total parameters, not a laptop-sized 6.5B model.</p><p><strong>Limit:</strong> Capabilities do not certify teaching quality. No target-model benchmark ran.</p><p><strong>Our proposal:</strong> Hosted drafting candidate; test with the included cases.</p><p>Location: Model card</p><p><a href="https://docs.mistral.ai/models/mistral-small-4-0-26-03">Read the source</a></p></section><section class="card" id="T5"><h2>T5 · Mistral: Ministral 3 3B model card</h2><p>official model specification · December 2025; checked 2026-09-30</p><p>Documents a small text-and-vision model.</p><p><strong>Limit:</strong> Local memory and runtime depend on quantisation and context. No installation or speed test occurred.</p><p><strong>Our proposal:</strong> Optional staged local route; never assign sole factual approval.</p><p>Location: Model card</p><p><a href="https://docs.mistral.ai/models/model-cards/ministral-3-3b-25-12">Read the source</a></p></section><section class="card" id="T6"><h2>T6 · Mistral: Durable agents</h2><p>official developer documentation · Accessed 2026-09-30</p><p>Describes workflow-backed agent state, activities and tool integration.</p><p><strong>Limit:</strong> Instructions and diagrams are not a deployed worker.</p><p><strong>Our proposal:</strong> Keep automation optional and separate from first-unit use.</p><p>Location: Overview</p><p><a href="https://docs.mistral.ai/studio/workflows/building-workflows/durable_agents">Read the source</a></p></section>



---

## OTT-SKILL — Teaching materials and methods — Skill

Source: 03_skills/teaching-materials-methods/SKILL.md

Delivery: DRAFT_VERIFIED. WordPress ID: 3758.

<h2>Teaching skill v3.0.0</h2><p>This is the source procedure. It is not an installed agent. Supporting files remain in the master package.</p><pre><code>---
name: teaching-materials-methods
description: Design, adapt, review, and package ELT materials or teacher-training units.
version: 3.0.0
metadata:
  project: open-teacher-training
  status: candidate
  tags: [education, elt, teaching, materials, curriculum]
---

# Teaching Materials And Methods

## Purpose
Build one useful unit.
Keep claims traceable.
Keep access free.
Separate training from teaching.
Never imply accreditation.
Never publish from here.

## Use this skill
Use for these tasks:
- teacher-training units
- classroom lesson packs
- method comparisons
- worksheet creation
- answer-key creation
- pronunciation practice
- reading tasks
- listening scripts
- speaking tasks
- writing tasks
- assessment rubrics
- accessibility adaptations
- material audits
- channel draft preparation

## Do not use
Avoid these tasks:
- live publishing
- account changes
- teacher certification
- learner surveillance
- high-stakes grading
- hidden data collection
- credential handling

Use separate workflows instead.

## Required inputs
Recover these first:
- task mode
- target audience
- learner context
- learning outcome
- time budget
- delivery mode
- access constraints
- requested artefacts

Use supplied sources first.
Mark missing facts clearly.

## Optional inputs
Use when supplied:
- existing lesson
- learner samples
- course module
- house style
- source list
- website target
- video target
- social target

## Output contract
Small tasks stay small.
Full packs contain:
1. brief
2. assumptions
3. observable outcome
4. method choice
5. alternative method
6. master unit
7. learner sheet
8. teacher guide
9. answer guidance
10. assessment criteria
11. revision task
12. source notes
13. access route
14. review status

Status stays explicit:
`draft`
`ready_for_review`
`approved`
`published`

Never skip states.

## Preflight
Read supplied files first.
Check actual file access.
Check available tools.
Check runtime versions when needed.
Check user permissions.
Check source rights.
Check privacy limits.
Check external costs when needed.

Then choose routing.

```text
Full unit needed?
  YES -&gt; build pack
  NO  -&gt; build request

Important claim disputed?
  YES -&gt; evidence review
  NO  -&gt; normal check

Publishing requested?
  YES -&gt; prepare handoff
  NO  -&gt; stop locally
```

## Reuse policy
Reuse working material first.
Inspect the body first.
Do not trust titles.
Do not clone blindly.

Prefer existing templates.
Prefer existing validators.
Revalidate reused material.
Avoid new dependencies.

New dependencies need reasons.
Ask permission before installs.
Provide no-install fallbacks.

## Literacy revision contract

Read `references/literacy-and-media.md` for reading or writing work.
Use `references/source-boundary.md` when adapting course sources.

Preserve the user’s source meanings. Separate Cambridge requirements, centre guidance, research and project proposals. Never infer that a dated handout makes its methods ineffective.

Specify both audiences: trainee teacher and language learner. Label both clocks. For reading, include the actual text, evidence questions and a changed-text return. For writing, include audience, purpose, a model, planning, a draft, feedback decisions and revision. Preserve speaking and listening where they serve the outcome.

Use meaningful chunks as entry points. Reassemble them into complete texts and sustained tasks. Do not assume a universal attention span, fixed word-encounter count or compulsory talk ratio.

Keep a no-AI route. Ask for an attempt before hints. In an independent assessment, withhold answer-generating assistance but preserve agreed access accommodations. Never call AI scoring an educator’s assessment.

For complete v3 literacy packs, use schema_version 2.0. Record actual input, output, transfer input, AI policy, teacher evidence and learner evidence in `literacy`. Source IDs resolve through the package evidence register. For legacy manifests, retain schema 1.0 compatibility.

## Procedure

### 1. Recover context
Identify task mode.
Separate both audiences.

Teacher trainees differ.
English learners differ.

Record both levels separately.
Record both timings separately.

Allowed modes:
- `teacher_training`
- `classroom_lesson`
- `adaptation`
- `audit`
- `method_comparison`

Default project context:
- adult teaching focus
- text-first materials
- optional AI use
- draft-only output

Assumptions need labels.

### 2. Define evidence
Choose one outcome.
Make it observable.
Define success evidence.

Watching proves attendance only.
Role-play proves rehearsal only.
Observation requires real teaching.

Teacher-training mode needs:
- trainee outcome
- learner task
- evidence criterion

### 3. Choose method
Read method guidance.
Match method to context.
Give one reason.
Give one alternative.
Name its trade-off.

Avoid universal claims.
Avoid method worship.
Avoid forced PPP use.
Avoid forced AI use.

### 4. Build materials
Provide actual materials.
Avoid empty placeholders.

Each activity needs:
- instructions
- input
- grouping
- timing
- learner product
- feedback route

Add examples when useful.
Label invented examples.

Language work may inspect:
- meaning
- form
- pronunciation
- use
- register
- variation

Reading needs exact input.
Listening needs supplied script.
Speaking needs communicative purpose.
Writing needs revision.
Pronunciation targets intelligibility.

### 5. Add feedback
Match answers exactly.
Explain open-answer criteria.
Link feedback to evidence.
Include another attempt.
Add later transfer practice.

Keep answers separate.
Check total timing.

### 6. Check access
Provide text alternatives.
Avoid paid-AI dependency.
Avoid streaming dependency.
Avoid colour-only cues.

Media plans need transcripts.
Scripts are not media.

### 7. Check evidence
Use source discipline.
Separate these categories:
- verified evidence
- user information
- inference
- project choice
- illustration
- unknown information

Changing facts need dates.
Versioned interfaces need checks.

Important disputes use:
- proposition
- supporting evidence
- strongest alternative
- finding
- change condition
- design consequence

Use rigorous analysis selectively.
Do not duplicate research.

### 8. Check rights
Prefer original content.
Check reuse permission.
Protect learner privacy.
Never fabricate consent.
Never fabricate review.
Never fabricate citations.

### 9. Validate structure
Use the quality gates.
Check these areas:
- alignment
- language
- completeness
- timing
- access
- evidence
- rights
- privacy
- assessment integrity
- release integrity

Full packs use manifests.
Run validator when available.

Validator success means structure.
It proves nothing else.

### 10. Repair
Use targeted repairs.
Allow two repair passes.
Record stale dependencies.
Then report blockers.

Do not loop endlessly.

### 11. Return output
Return artefacts first.
Then show checks.
Then show gaps.
Then show next action.

Never claim unseen results.
Never claim unsaved files.
Never claim publication receipts.

## Failure handling

### Missing input
Name the missing input.
Use safe assumptions only.
Otherwise stop that branch.

### Contradictory sources
Show both sources.
State the conflict.
Avoid forced certainty.

### Tool unavailable
Use manual fallback.
Do not invent tools.

### Empty tool output
Check expected postcondition.
Treat emptiness as failure.

### Rights uncertainty
Block public release.
Keep private draft only.

### Privacy uncertainty
Remove personal data.
Otherwise stop publication.

### Context limit
Chunk by unit.
Checkpoint completed work.
Continue from state.

## Small-model route
Use linear execution.
One stage per turn.
One artefact per stage.

Sequence:
`brief → outcome → method → material → key → checks`

Reload identifiers often.
Checkpoint completed stages.
Avoid whole-course generation.
Escalate one question only.

## Model realism
No prompt guarantees quality.
No model guarantees accuracy.
Host behavior needs testing.
Use separate review cases.

Model adapters stay small.
Do not fork skills.

## Publishing handoff
Publishing stays separate.
Use one master version.
Avoid duplicate packages.

Handoff should include:
- unit ID
- version
- content hash
- approval reference
- desired action
- destination IDs

Never include secrets.
Keep credentials outside prompts.

Retry public actions carefully.
Check destination first.
Avoid duplicate publication.

## Stop conditions
Stop when one applies:
- requested artefact completed
- blocker prevents correctness
- rights remain unresolved
- privacy remains unresolved
- repair budget exhausted
- authorization boundary reached

## Acceptance criteria
A complete pack needs:
- explicit audience
- observable outcome
- aligned evidence
- complete materials
- usable answers
- realistic timing
- access route
- source notes
- rights notes
- honest status

## Supporting files
Read only needed files.

- `references/course-context.md`
- `references/method-selection.md`
- `references/evidence-and-quality.md`
- `references/publishing-handoff.md`
- `references/sources.md`
- `templates/MASTER_UNIT.md`
- `templates/CLASSROOM_PACK.md`
- `templates/REVIEW_AND_CLAIMS.md`
- `templates/unit-manifest.json`
- `examples/M02-U01/`
- `scripts/validate_unit.py`
- `scripts/test_validate_unit.py`
</code></pre>



---

## OTT-MISTRAL — Mistral teaching studio — Setup guide

Source: 04_mistral_studio/SETUP_PAGES.json

Delivery: DRAFT_VERIFIED. WordPress ID: 3759.

<p>Guide version: 30 September 2026. Interface and model claims are retained from that edition. Recheck the linked documentation before configuration. This page does not claim new account tests.</p><h2>1. Build one unit first</h2><p>A source-bound route</p><h3>First</h3><p>Open the canonical skill. Attach only needed references. Keep source and instructions distinct.</p><h3>Then</h3><p>Use one complete pilot example. Test before adding functions. Keep outcomes and levels explicit.</p><h3>Do not assume</h3><p>An account grants no integration. A model label proves no quality. A schema does not execute.</p><h3>Status</h3><p>No Mistral setup was changed. No target model was called. This is an implementation guide.</p><p>Source IDs: T3, T6.</p><h2>2. Create the skill</h2><p>Documentation-based click route</p><h3>Open</h3><p>Studio → Build → Skills. Click New Skill. Your older screenshot shows Context instead. Use the visible Skills control.</p><h3>Add</h3><p>Title: teaching-materials-methods. Description: create or review source-bound English teaching materials. Paste the canonical SKILL.md procedure.</p><h3>Attach</h3><p>Add literacy-and-media.md and source-boundary.md. Add SOURCE_REGISTER.md when needed. Add one complete example, not the whole archive.</p><h3>Save</h3><p>Click Create Skill. Reopen the saved version. Keep visibility private during testing. Labels may vary by account.</p><p>Source IDs: T3.</p><h2>3. Create an agent</h2><p>Use a thin adapter</p><h3>Open</h3><p>Use Agents or Playground. Inspect existing settings before editing. Preserve the earlier working agent.</p><h3>Add</h3><p>Create a candidate agent. Name: OTT literacy v3. Use AGENT_ADAPTER.txt as instructions.</p><h3>Choose</h3><p>Select an actually available model. Begin with one hosted drafting candidate. Verify source access with a test.</p><h3>Check</h3><p>The saved agent must retrieve input. It must distinguish uncertainty. Do not publish from this test.</p><p>Source IDs: T3, T4, T5.</p><h2>4. Models and the 0.8 question</h2><p>Measure rather than assume</p><h3>Hosted candidate</h3><p>Mistral Small 4: mistral-small-2603. Its documented tools do not certify outputs. Its total model is 119B.</p><h3>Local candidate</h3><p>Consider Ministral 3 3B only after a memory check. Use one stage per turn. Do not infer speed from size.</p><h3>Settings</h3><p>Keep supported defaults first. Compare temperature settings only when available. Temperature 0.8 is not seconds.</p><h3>Record</h3><p>Measure latency and complete output separately. Record correctness, cost and retries. No benchmark ran in the target account.</p><p>Source IDs: T4, T5.</p><h2>5. Test with the literacy pack</h2><p>One request, observable evidence</p><h3>Request</h3><p>Use M06-U02 source texts. Ask for a lesson and keys. Keep source attribution explicit.</p><h3>Compare</h3><p>The sample has eighteen attendees. Only fourteen completed both quizzes. A score rise does not prove causation.</p><h3>Reject</h3><p>Reject invented sources or guarantees. Reject missing input or transfer tasks. Ask for one targeted repair.</p><h3>Checkpoint</h3><p>Record the model and settings. Save the output and issue. After two repair cycles, stop and report the blocker.</p><p>Source IDs: R6, R7, T3.</p><h2>6. Sources are not instructions</h2><p>Files, libraries and permissions</p><h3>Knowledge</h3><p>Supply relevant source excerpts and provenance. Keep private candidate records outside public libraries.</p><h3>Skills</h3><p>Supply activation and procedure. Do not paste every reference into instructions.</p><h3>Functions</h3><p>Define only tools that can execute. Inspect parameters and returned evidence. Do not add a publishing function merely for appearance.</p><h3>Records</h3><p>Keep source version and output identity. Record unknowns instead of inventing them. Distinguish retrieval from verification.</p><p>Source IDs: T3, T6.</p><h2>7. Automate only after a unit works</h2><p>An optional developer route</p><h3>Sequence</h3><p>Source → material → checks → educator review → delivery. Preserve a resume checkpoint.</p><h3>Owner</h3><p>Use one execution owner. Reuse an existing workflow if suitable. Do not activate duplicate schedules.</p><h3>Failure</h3><p>Bound retries and record errors. Check receipts before repeating writes. Keep secrets outside prompts.</p><h3>Boundary</h3><p>Worker code needs implementation. Content generation is not deployment. No scheduled job was created.</p><p>Source IDs: T6.</p><h2>8. Accept only what was checked</h2><p>Release gates</p><h3>Content</h3><p>Source, task, key and transfer agree. Reader purpose survives revision. Missing evidence stays visible.</p><h3>Access</h3><p>Text and print work without AI. Keyboard and mobile testing are needed. No full conformance claim is made.</p><h3>Human review</h3><p>An educator checks teaching suitability. Learners try the actual tasks. Improvement requires observed evidence.</p><h3>Delivery</h3><p>Verify requested uploads separately. Keep approval distinct from storage. Storing a draft is not teaching endorsement.</p><p>Source IDs: T1, R4, T3.</p>



---

## OTT-GLOSSARY — Teaching terms — Glossary bridge

Source: 08_evidence/GLOSSARY_BRIDGE.md

Delivery: DRAFT_VERIFIED. WordPress ID: 3760.

<h1>Glossary bridge</h1>
<p>Source terminology is retained. Adaptations are labelled.</p>
<h2>MFPA</h2>
<p>Source: Meaning, form, pronunciation, appropriacy.</p>
<p>Adaptation: Retain all four considerations.</p>
<p>Example: A request changes with audience.</p>
<p>Anchor: D2 pp. 2, 5</p>
<h2>MFPR</h2>
<p>Source: Some centre sheets use register instead of appropriacy.</p>
<p>Adaptation: Explain the related but non-identical labels.</p>
<p>Example: Register is one part of context-sensitive use.</p>
<p>Anchor: D6 lexis/function sheets</p>
<h2>Concept check</h2>
<p>Source: Checks understanding of language meaning.</p>
<p>Adaptation: Do not confuse with instructions.</p>
<p>Example: Does “borrow” mean keep forever?</p>
<p>Anchor: D2 pp. 2–3</p>
<h2>Instruction check</h2>
<p>Source: Checks what learners should do.</p>
<p>Adaptation: A demonstration can be preferable.</p>
<p>Example: Should you write or discuss?</p>
<p>Anchor: D2 p. 3</p>
<h2>Gist</h2>
<p>Source: General understanding of a text.</p>
<p>Adaptation: Use when the reading purpose needs it.</p>
<p>Example: Choose the notice’s main purpose.</p>
<p>Anchor: D2 p. 4; D4</p>
<h2>Detailed reading</h2>
<p>Source: Closer inspection of text meaning.</p>
<p>Adaptation: Require evidence, references and inference checks.</p>
<p>Example: Which sentence supports the booking rule?</p>
<p>Anchor: D4</p>
<h2>Fluency</h2>
<p>Source: Allows language use without tightly restricting choices.</p>
<p>Adaptation: Apply to writing as well as speaking.</p>
<p>Example: Draft a purposeful message.</p>
<p>Anchor: D2 p. 4</p>
<h2>Accuracy</h2>
<p>Source: Attention to correct language production.</p>
<p>Adaptation: Use alongside meaning; not as the sole writing criterion.</p>
<p>Example: Check whether tense changes the event time.</p>
<p>Anchor: D2 p. 2</p>
<h2>Guided discovery</h2>
<p>Source: A way to clarify language through examples.</p>
<p>Adaptation: Not automatically a whole lesson framework.</p>
<p>Example: Infer a pattern, then verify it.</p>
<p>Anchor: D2 p. 4; D6 stage names</p>
<h2>Micro-teaching</h2>
<p>Source: In this glossary: support during monitoring.</p>
<p>Adaptation: Elsewhere it can mean a brief teaching rehearsal. Label the meaning.</p>
<p>Example: Guiding a learner during controlled practice is not a recorded rehearsal.</p>
<p>Anchor: D2 p. 5</p>
<h2>Teacher talk time</h2>
<p>Source: The amount of teacher talk.</p>
<p>Adaptation: The glossary’s 70/30 ratio is a rough heuristic. Evaluate purpose and learner response.</p>
<p>Example: A model explanation can be useful.</p>
<p>Anchor: D2 p. 7</p>
<h2>Task before text</h2>
<p>Source: Give a reason to read or listen.</p>
<p>Adaptation: Useful routine, not a ban on reader-selected purposes.</p>
<p>Example: Read to decide whether to book.</p>
<p>Anchor: D2 pp. 6–7</p>
<h2>Lead-in</h2>
<p>Source: A stage establishing interest and context.</p>
<p>Adaptation: Five minutes is not mandatory.</p>
<p>Example: One picture may establish context.</p>
<p>Anchor: D2 p. 5</p>
<h2>Repeated encounters</h2>
<p>Source: The introduction suggests at least seven.</p>
<p>Adaptation: Do not promise a universal threshold.</p>
<p>Example: Use retrieval and meaningful return tasks.</p>
<p>Anchor: D2 p. 1; R5</p>
<h2>Feedback</h2>
<p>Source: May address content or language.</p>
<p>Adaptation: Connect comments to revision decisions.</p>
<p>Example: The reader could not find the time.</p>
<p>Anchor: D2 p. 4; D5</p>
<h2>Mediation</h2>
<p>Source: Helping others access or construct meaning.</p>
<p>Adaptation: Our extension uses CEFR-informed tasks.</p>
<p>Example: Explain a notice for another reader.</p>
<p>Anchor: R9</p>
<h2>Transfer</h2>
<p>Source: Performance in a changed context.</p>
<p>Adaptation: A project assessment design, not a glossary quotation.</p>
<p>Example: Write a fresh request without hints.</p>
<p>Anchor: R5; R6</p>
<h2>AI hint</h2>
<p>Source: A bounded aid after an attempt.</p>
<p>Adaptation: Separate assistance from an independent check.</p>
<p>Example: Point to a paragraph without giving the answer.</p>
<p>Anchor: R6; R8</p>




---

## OTT-MEDIA — Diagrams and video production scripts

Source: 09_media/

Delivery: DRAFT_VERIFIED. WordPress ID: 3761.

<h2>Diagrams and demonstration scripts</h2><p>Diagrams represent project designs, not measured results. No video was produced. The scripts are production plans.</p><h3>Ai</h3><p>AI hints follow an attempt and do not replace an independent assessment.</p><h3>Cycle</h3><p>Reading leads through evidence checking, writing and revision to an independent changed task.</p><h3>Evidence</h3><p>Compare claims with source evidence before deciding.</p><h3>Keep</h3><p>Preserve foundations, adapt local heuristics, extend digital literacy.</p><h3>Ladder</h3><p>Short entry tasks lead to sustained reading and independent transfer.</p><h3>Media</h3><p>The website is the master; print provides access; video demonstrates; LinkedIn helps discovery.</p><h3>Modules</h3><p>Twelve preserved modules, with literacy across the sequence.</p><h3>Pipeline</h3><p>Content creation, review, approval and delivery are separate states.</p><h3>Revision</h3><p>Writing revision responds to readers while preserving the writer’s intention.</p><h1>Demonstration scripts</h1>
<p>No video or audio was rendered. Captions must be checked after production. All notices are fictional teaching inputs.</p>
<h2>M06-U01 — Read for evidence</h2>
<p>Proposed 75-second demonstration. Learners can pause.</p>
<table>
<thead>
<tr>
  <th>Time</th>
  <th>Show</th>
  <th>On-screen prompt</th>
</tr>
</thead>
<tbody>
<tr>
  <td>0–10s</td>
  <td>Title and one source paragraph</td>
  <td>What does the source actually say?</td>
</tr>
<tr>
  <td>10–25s</td>
  <td>Highlight the model’s evidence</td>
  <td>Claim: Entry costs nothing. Decision: supported. Evidence: paragraph 1 says there is no entry charge. This does not mean visitors can take books home.</td>
</tr>
<tr>
  <td>25–40s</td>
  <td>Show a task without its key</td>
  <td>A: Announce a permanent library. B: Explain a trial reading room. C: Sell donated books.</td>
</tr>
<tr>
  <td>40–55s</td>
  <td>Reveal the supporting evidence</td>
  <td>B. Paragraphs 1 and 4 describe a trial without a continuation decision.</td>
</tr>
<tr>
  <td>55–65s</td>
  <td>Show one revision decision</td>
  <td>Preserve meaning. Explain a change.</td>
</tr>
<tr>
  <td>65–75s</td>
  <td>Link to the full text task</td>
  <td>Read, write and retry.</td>
</tr>
</tbody>
</table>
<p>Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.</p>
<p>LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.</p>
<h2>M06-U02 — Check a summary</h2>
<p>Proposed 75-second demonstration. Learners can pause.</p>
<table>
<thead>
<tr>
  <th>Time</th>
  <th>Show</th>
  <th>On-screen prompt</th>
</tr>
</thead>
<tbody>
<tr>
  <td>0–10s</td>
  <td>Title and one source paragraph</td>
  <td>What does the source actually say?</td>
</tr>
<tr>
  <td>10–25s</td>
  <td>Highlight the model’s evidence</td>
  <td>A claim about score changes is supported by A[1]. A claim about writing causing improvement is not supported. A[2] and B[3] provide alternative explanations.</td>
</tr>
<tr>
  <td>25–40s</td>
  <td>Show a task without its key</td>
  <td>How many attended? How many completed both quizzes? Why does the difference matter?</td>
</tr>
<tr>
  <td>40–55s</td>
  <td>Reveal the supporting evidence</td>
  <td>Eighteen attended; fourteen completed both. The score change describes completers, not necessarily every attendee.</td>
</tr>
<tr>
  <td>55–65s</td>
  <td>Show one revision decision</td>
  <td>Preserve meaning. Explain a change.</td>
</tr>
<tr>
  <td>65–75s</td>
  <td>Link to the full text task</td>
  <td>Read, write and retry.</td>
</tr>
</tbody>
</table>
<p>Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.</p>
<p>LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.</p>
<h2>M07-U01 — Write for a reader</h2>
<p>Proposed 75-second demonstration. Learners can pause.</p>
<table>
<thead>
<tr>
  <th>Time</th>
  <th>Show</th>
  <th>On-screen prompt</th>
</tr>
</thead>
<tbody>
<tr>
  <td>0–10s</td>
  <td>Title and one source paragraph</td>
  <td>What does the source actually say?</td>
</tr>
<tr>
  <td>10–25s</td>
  <td>Highlight the model’s evidence</td>
  <td>The opening identifies the session. The next sentence states the goal. The questions request missing information. The final sentence explains why confirmation matters.</td>
</tr>
<tr>
  <td>25–40s</td>
  <td>Show a task without its key</td>
  <td>Mark the session, learning goal, missing information and confirmation request. Which details come from the notice?</td>
</tr>
<tr>
  <td>40–55s</td>
  <td>Reveal the supporting evidence</td>
  <td>The Saturday time and booking rule come from the notice. The goal, access question and travel reason belong to the writer’s situation. The notice does not guarantee access.</td>
</tr>
<tr>
  <td>55–65s</td>
  <td>Show one revision decision</td>
  <td>Preserve meaning. Explain a change.</td>
</tr>
<tr>
  <td>65–75s</td>
  <td>Link to the full text task</td>
  <td>Read, write and retry.</td>
</tr>
</tbody>
</table>
<p>Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.</p>
<p>LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.</p>
<h2>M07-U02 — Revise without losing meaning</h2>
<p>Proposed 75-second demonstration. Learners can pause.</p>
<table>
<thead>
<tr>
  <th>Time</th>
  <th>Show</th>
  <th>On-screen prompt</th>
</tr>
</thead>
<tbody>
<tr>
  <td>0–10s</td>
  <td>Title and one source paragraph</td>
  <td>What does the source actually say?</td>
</tr>
<tr>
  <td>10–25s</td>
  <td>Highlight the model’s evidence</td>
  <td>Accept A because the reader needs times. Reject B because access is unconfirmed. Adapt E into a choice: paper or laptop. Feedback is a proposal, not an authority.</td>
</tr>
<tr>
  <td>25–40s</td>
  <td>Show a task without its key</td>
  <td>Identify three conflicts between the intention and draft. Distinguish missing facts from invented promises.</td>
</tr>
<tr>
  <td>40–55s</td>
  <td>Reveal the supporting evidence</td>
  <td>Missing: times, capacity, booking, equipment options. Invented: guaranteed writing success and certificates. “Everyone can come” ignores capacity and unconfirmed access.</td>
</tr>
<tr>
  <td>55–65s</td>
  <td>Show one revision decision</td>
  <td>Preserve meaning. Explain a change.</td>
</tr>
<tr>
  <td>65–75s</td>
  <td>Link to the full text task</td>
  <td>Read, write and retry.</td>
</tr>
</tbody>
</table>
<p>Production note: do not force long text into a timed frame. Use a short highlighted excerpt and the accompanying transcript. Timing is an estimate, not tested narration speed.</p>
<p>LinkedIn draft: Try a source-and-evidence task before trusting a fluent answer. This unit supplies text, a decision, feedback and a changed-context return. The sample awaits educator review.</p>


