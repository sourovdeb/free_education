# Open Teacher Training

Open START_HERE.html.

32 WordPress drafts saved. 22 candidates not saved. Read DELIVERY_REPORT.md for the exact holds. No automatic importer is included. Prepared previews are not a WordPress database backup.
