# Start here

## What this contains

Six prompts specify the workflow. Settings define layout and appearance. Source notes record verified distinctions. Validation records distinguish packaging from execution.

## First use

Unzip beside your production workspace. Open Hermes in that workspace. Supply your book and transcript. Supply narration or presenter footage. Run prompts/01_build_controller.md with production_defaults.json. Let Hermes inspect existing implementations. Missing access remains a reported gap.

The controller loads stage prompts. You needn't paste everything repeatedly. No integration exists through text alone.

## Repeated use

Run prompts/06_assemble_recycle.md. Select your source folder. Keep saved style settings. Use ALL for complete assembly. Use RESHUFFLE for presentation changes.

These action names require implementation. This package hasn't installed them. The launcher must be created locally.

## The screen split

Coordinates use top-left pixel origin. Rectangle endpoints are exclusive.

| Region | Rectangle | Size |
|---|---|---|
| Lesson | [0, 0, 1280, 1080] | 1280x1080 |
| Presenter | [1280, 0, 1920, 1080] | 640x1080 |

Compose the lesson at its size. Don't squeeze a 16:9 scene. Fit presenter media without stretching. Absent presenter footage leaves transparency. Don't generate an avatar.

## Headless distinction

The inspected Ahujasid bridge rejects background-mode. Other implementations require inspection. The CLI fallback remains Blender automation. It does not become MCP execution. A virtual-display GUI isn't background-mode.

## Rendering distinction

No finished programme is exported. Internal assets and proof-frames are allowed. Saving .blend does not produce video. Playback and final rendering consume resources.

## Reuse

Keep asset masters outside books. Keep beat plans inside jobs. Cache meanings, alignment, and appearances. Recompute only affected results. Do not copy the entire library.

## Status

Blender/Hermes/model tests have not run. Hardware savings have not been measured. See VALIDATION.md for actual checks.
