# Sources and adaptation record

Review date: 3 October 2026.

## Supplied project sources

- `Resolve_Transcript_Visuals_v2.md`: preserved semantic direction, seeded variation, editable text, audio-before-alignment ordering, module reuse, and no programme export.
- `LIBRARY_SKILLS_BUNDLE.md`: inspected teaching sections including ELT365 and Weekly Book Reading. Reused lexis, thought groups, the lexical-stress/prominence/performance distinction, and Idea–Example–Try. The package does not reproduce unrelated personal records or deployment instructions.
- `Blender Storyboard Planning.txt`: preserved chapter/scene/beat hierarchy, papercraft, 2.5D staging, asset continuity, and VSE assembly. Replaced mandatory agent brands, an assumed Blender version, fixed shot quotas, compulsory exports, and tiny-caption assumptions with the current brief.
- `Master20Standard.md`: reused capability inspection, dependency restraint, source preservation, and truthful validation status. No claim of passing its complete 74-entry audit is made.

## Verified external sources

### S1 — Hermes MCP documentation
https://hermes-agent.nousresearch.com/docs/user-guide/features/mcp/

Inspected documentation for `mcp_servers`, tool discovery, stdio/HTTP connections, and tool filtering. A listed tool is not proof of successful execution on the user's host. Use the installed profile path and supported configuration.

### S2 — Ahujasid MCP for Blender
https://github.com/ahujasid/mcp-for-blender
https://raw.githubusercontent.com/ahujasid/mcp-for-blender/main/addon.py

The supplied historical repository URL redirects here. Inspected `BlenderMCPServer.start()` in the fetched main-branch addon, around lines 1155–1159. It returns when `bpy.app.background` is true. Startup callbacks also skip background-mode. This is evidence about this inspected implementation, not every Blender MCP. A GUI or virtual display preserves a different execution mode.

Also inspected API discovery handlers. Commands may expose names different from internal handler names. Discover schemas instead of copying internal names into Hermes calls.

### S3 — Blender Grease Pencil migration
https://developer.blender.org/docs/release_notes/4.3/grease_pencil_migration/

The indexed official page exposed its migration text, including data-model changes, modern drawing attributes, modifier changes, and removal of the old screen-space thickness switch. This supports version inspection and pixel-to-world stroke calibration. It does not identify the user's installed version.

### S4 — Blender Grease Pencil release notes
https://developer.blender.org/docs/release_notes/4.3/grease_pencil/

Inspected indexed official release text for Grease Pencil changes and geometry-node support. Published sample file-size improvements are not estimates for this user's projects.

### S5 — Blender Shader to RGB
https://docs.blender.org/manual/en/latest/render/shader_nodes/color/shader_to_rgb.html

Verified the indexed official description identifying non-photorealistic use and EEVEE-only support. Direct manual-page retrieval failed. The proposed Diffuse -> Shader to RGB -> Color Ramp -> Emission graph still requires an actual target render test.

### S6 — Blender Line Art
https://docs.blender.org/manual/en/latest/grease_pencil/modifiers/generate/line_art.html

Verified indexed official descriptions of scene/collection/object line generation and Use Cache. Direct manual-page retrieval failed. Cache sharing is not automatically the same as temporal baking. Baking remains a conditional implementation step, tested locally.

## Research limits

Several Blender manual/API pages could not be fetched directly. No complete current manual inspection is claimed. Exact CLI flags, compositor/strip APIs, colour-management enums, and render-engine settings must be verified against the installed executable and its API. No provider installation, tool connection, rendering, or local-user hardware benchmark occurred.

## Design choices, not source claims

The palette, pixel rectangles, font-size targets, light angles, shape language, material recipes, animation rhythm, resource warning levels, action names, and JSON format are proposed production choices. They are not vendor defaults, guaranteed savings, or proofs of aesthetic quality.
