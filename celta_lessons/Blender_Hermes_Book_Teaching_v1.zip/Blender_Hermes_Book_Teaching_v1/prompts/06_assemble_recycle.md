# Assemble and recycle

Run BLENDER_BUILD_TO_REVIEW for this job. Keep non-reasoning configuration unchanged. Load saved runners and presets. Build only missing required components.

Select the requested mode:
ALL | AUDIO | STORYBOARD | CUTOUT | TOON3D | BOOK | TEACH | RESHUFFLE.
Use ALL when unspecified. Resolve prerequisites through existing stages. Don't ask routine approval questions.

Use a 1920x1080 master frame. Keep lesson pixels x=0..1279. Keep presenter pixels x=1280..1919. Both regions span the height. Use square pixels without stretching. Compose lesson scenes at 1280x1080. Compose presenter footage at 640x1080.

Use Blender's Video Sequence Editor. Inspect installed strip APIs first. Use scene strips within chapters. Cache costly shots internally. Retain the editable .blend originals. Don't load every book scene. Assemble chapters through a manifest.

Place lessons without automatic scaling. Fit presenter footage without distortion. Default to containment, not cropping. Crop only when configured. Without footage, preserve that transparency. Exclude placeholder guides from output. Add no synthetic presenter.

Clip effects to their panel. Include shadows, transitions, and pointers. Check the boundary throughout movement. Enforce boundaries through compositor masks. Transparency doesn't reserve specific pixels. Verify an actual composited frame. Check one frame at 100%. Scale preview masks with resolution.

Reuse narration and timing maps. Use one designated voice track. Mute duplicate embedded source audio. Cut presenter footage in synchronization. Preserve explicitly marked practice holds. Prevent duplicate voice processing.

RESHUFFLE changes compatible presentation only. Keep source, numbers, timing, pedagogy. Use deterministic seeded selections. Reuse saved interpretation records. Make no further model calls.

Hash sources, presets, assets, versions. Invalidate only affected downstream results. Update objects through stable IDs. Preserve overrides and unrelated edits. Resume from successful checkpoints. Record failures; preserve completed chapters.

Run proof-frame and audio checks. Inspect first/middle/last and transition frames. Test text and narration changes. Test unchanged reruns without duplicates. Test missing assets and interruptions. Structure checks aren't visual inspection. Record tests that never ran.

Keep one active render worker. Avoid simultaneous GPU speech/model processing. Read available memory before dispatch. Apply the calibration profile. Checkpoint on persistent resource pressure. Don't claim enforced hardware caps.

Save chapter projects and manifests. Save materials, rigs, and actions. Record source provenance and licenses. Keep sources relative where possible. Never bundle secrets or fonts.

Stop before finished-video export. Internal assets and proof-frames qualify. Do not render delivery movies. Publish nothing. Return paths and test gaps. Headless completion leaves windows closed.
