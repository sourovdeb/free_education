# Build the controller

Build BLENDER_BUILD_TO_REVIEW for Hermes. Keep my non-reasoning configuration unchanged. Reuse my scripts and assets. Return implementation files and evidence.

Inspect Blender, Hermes, and MCP. Record executable paths and versions. Read the installed server implementation. Discover its tools before calling. Test its background-mode behavior. Ahujasid's inspected bridge rejects background-mode. Do not assume another implementation. Preserve working integrations without upgrading.

Prefer an existing headless-capable connection. Otherwise use Hermes's terminal tool. Run Blender's background Python interface. Label this route HEADLESS_CLI. It is not MCP execution. Keep MCP for interactive inspection. A minimized window remains GUI-driven.

Require MCP transport when requested. Expose this runner through it. Reuse an installed MCP SDK. Add only the missing adapter. Report dependencies before installing anything. Avoid maintaining competing scene builders.

Load production_defaults.json from this package. It defines our production contract. It isn't Blender-native configuration. Implement its settings through bpy. Prefer bpy.data over UI operators. Probe unavoidable operator context requirements. Do not simulate mouse drawing.

Create independently callable stages:
INGEST -> AUDIO -> ALIGN -> DIRECT -> BUILD -> ASSEMBLE -> CHECK -> SAVE.
Support BOOK, SKETCH, and CUTOUT. Include TOON3D and TEACH. Include AUDIO and RESHUFFLE controls. Names describe our proposed actions. Register only implementations that exist.

Retrieve relevant reading-library sections. Reuse lexis and thought groups. Separate stress, prominence, and performance. Retain Idea–Example–Try where appropriate. Exclude unrelated publication/account instructions.

The model supplies meaning decisions. Code supplies geometry and timings. Process one meaning-window per call. Start with six sentences maximum. Split by available context capacity. Include a short continuity record. Track coverage across every window. Return records, not deliberation essays.

Validate records before scene construction. Repair failing records once. Then preserve affected reading text. Mark its illustrations as unresolved. Continue the remaining supported work.

Create a one-click desktop launcher. Discover paths during installation. Let it select source folders. Save settings between book jobs. Run existing stages without regeneration. Produce actual files where possible. Otherwise identify missing local access.

Save sources and working copies. Checkpoint after each completed shot. Save .blend projects without programme-export. Internal proof frames remain permitted. Do not publish or upload. End with locations and gaps.
