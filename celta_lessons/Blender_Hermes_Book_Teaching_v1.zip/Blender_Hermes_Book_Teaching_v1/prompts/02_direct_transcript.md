# Prepare audio and direct

Prepare the job's audio first. Reuse verified cleanup/alignment tools. Reuse available Resolve/Fairlight work. Do not rebuild working utilities. Blender is the assembly destination. Never invent voice-isolation bpy methods.

Use supplied narration before generating. Retain presenter speech when supplied. Never replace it with TTS. Otherwise discover available speech engines. Keep source wording unchanged. Keep pronunciation directions outside quotations. Finish timing edits before alignment.

Default to MINIMUM_GAPS pacing. Remove nonspeech gaps with handles. Keep consonants and word endings. Preserve explicitly marked practice intervals. Protect deliberate source repetitions. Remove only confirmed false starts. Apply cuts to presenter footage. Save source-to-edited interval mappings.

Apply isolation through verified tools. Identify denoising-only fallbacks as denoising. Offer the DEEP_READER preset. Lower pitch without slowing duration. Start with minus one semitone. Retain pitch variation and intelligibility. Compare versions at matched loudness. Measure peaks and processed duration. Unavailable tools remain reported gaps.

Now direct the finished transcript. Use source IDs and alignment. Return JSON records without commentary. Do not invent word timestamps. Without audio, propose animatic timing. Label that timing PROVISIONAL.

Select the family through meaning:
ACTION -> SKETCH or CUTOUT.
SPACE/POSITION -> TOON3D or CUTOUT.
CONTRAST -> TEXT_COMPARISON.
SEQUENCE -> TIMELINE.
RELATIONSHIP -> NODE_MAP.
QUANTITIES -> CHART.
LEXIS -> WORD_CARD.
GRAMMAR -> PHRASE_BLOCKS.
PRONUNCIATION -> STRESS_OR_LINKING.
OTHER -> BOOK_LINE.

Choose one visual per beat. Keep book wording on screen. Use context, not isolated keywords. Example: 'Take off your coat.' Show coat removal, not aircraft.

Choose shots through dramatic function. Use establishing shots for orientation. Use inserts for consequential objects. Use reactions after meaningful reversals. Preserve eyelines and screen direction. Do not impose shot-count quotas. Hold when narration needs time.

Preserve characters, costumes, and props. Distinguish narration from character beliefs. Label visual interpretations as interpretations. Do not reveal later chapters.

Filter through existing asset manifests. Record missing assets as requests. Let code randomize compatible variants. Seed choices by beat identity. Keep typography and palette stable. Avoid the previous three variants. Relax cooldown when alternatives disappear. Never randomize facts or pronunciation.

Return one record per beat:
beat_id, source_ids, timing_ref, family,
shot_type, asset_ids, action_id, target_ids,
data_ref, teaching_ref, variant_candidates,
needed_asset, content_status.

Reference supplied IDs without renaming. Let code calculate frame boundaries. Preserve gaps in coverage records.
