# Build sketch and cutout

Build SKETCH and CUTOUT assets. Load production_defaults.json before construction. Consume the validated beat records. Reuse matching assets before creating.

Compose inside 1280x1080 lesson pixels. The presenter owns remaining pixels. Use an orthographic lesson camera. Calculate its bounds from resolution. Separate overlays from scenery. Keep overlays fixed during camerawork.

SKETCH uses gesture and contour. Prioritize silhouette and line-of-action. Build foreground, midground, and background. Establish depth through overlap. Use three tonal masses. Add hatching only where explanatory. Preserve negative space around reading.

Use renderable Grease Pencil objects. Never substitute viewport Annotations. Inspect the installed drawing API. Modern APIs differ from legacy. Create strokes through supported data-access. Use curves when they suffice. Preserve point and fill data.

At 1080px height, target these widths:
Silhouette: 3px.
Interior contour: 1.5px.
Teaching pointer: 4px.
Derive radii from camera projection. Recheck after zoom or scaling. Never assume a pixel-width property.

Use the package's INK_PAPER palette. Paper grounds the composition. Ink carries contours and text. Teal marks learning focus. Ochre fills emphasis patches. Coral marks correction alternatives. Lavender distinguishes thought or recollection. Labels must accompany colour distinctions.

CUTOUT uses layered paper silhouettes. Use curves or mesh planes. Separate heads, torsos, and limbs. Place pivots at plausible joints. Parent pieces to control empties. Use armatures only when needed. Keep two-to-four depth layers initially. Give layers different movement amplitudes. Use differential motion under orthographic-projection.

Animate anticipation, action, and settle. Use pose-to-pose keyframes and holds. Reuse point, walk, turn, react. Animate drawings on twos. Keep text timings at timeline-rate. On-twos alone doesn't halve rendering. Cache frames only when identical.

Test Build for stroke reveals. Otherwise use curves or masks. Start entrances around 0.3 seconds. Let narration determine reading duration. Keep line-boil optional and subtle. Never apply jitter to words.

Apply paper texture without displacement. Reuse one small tile initially. Avoid displacement and particle simulation. Fake shadows with shape layers. Hide guides from review output.

Use pragmatic asset names.
Examples: tree_big, tree_small, child_pointing, river_curve, classroom_board, door_opening
Record real names in asset_manifest.json. Record bounds, pivots, palette, version. Save .blend masters and evidence. Do not claim unseen renders.
