# Build 3D teaching scenes

Build TOON3D from validated beats. Load production_defaults.json and existing assets. Use 3D when depth explains. Prefer diagrams for abstract relations.

Construct a tabletop-diorama composition. Use silhouette, overlap, and staging. Default to an orthographic camera. Use three-quarter views for demonstrations. Keep perspective optional and purposeful. Avoid orbiting during book reading.

Build from cubes and cylinders. Use low-resolution spheres when needed. Keep shared meshes and materials. Instance repeated scenery without realizing. Use Geometry Nodes for repetition. Use Array for simpler repetition. Add Bevel only where visible. Avoid subdivision by default.

Prefer existing puppet rigs. Use empties for rigid hinges. Reuse armatures for character motion. Reuse actions for gestures. Inspect action-slot compatibility before assigning. Keep costumes and proportions consistent.

Use EEVEE when available. Verify background rendering before scaling. Identify its engine enum locally. Do not confuse Cycles settings. Check GPU availability before rendering.

Create two material routes.
FLAT: palette colour -> Emission -> Material Output.
CEL: Diffuse BSDF -> Shader to RGB -> Color Ramp -> Emission -> Material Output.
Use Constant interpolation for CEL. Start with three value bands. Shader to RGB requires EEVEE. Test the actual material output.

Use one Area light initially. Begin around 45-degree azimuth. Begin around 35-degree elevation. Calibrate power against scene scale. Keep text on emission materials. Fake contact shadows where suitable. Avoid HDRIs as compulsory dependencies.

Limit Line Art by purpose. Restrict sources to relevant collections. Enable contours before adding creases. Don't outline every mesh edge. Use cached calculations where supported. Bake only after fixing geometry/camera. Invalidate outlines after camera changes. Retain editable source geometry.

Use motion to demonstrate meaning. For 'under', move below something. For 'through', show actual traversal. Make preposition references unambiguous. For processes, reveal components sequentially. For comparisons, keep cameras identical. Don't distort numerical chart bars.

Follow the resource calibration profile. Start near 50000 evaluated triangles. Start near 30000 Grease-Pencil points. These are targets, not guarantees. Sample memory and render time. Process one shot per worker. Release its memory before continuing.

Reduce hidden geometry and overdraw. Then reduce previews and samples. Preserve legibility and source coverage. Start without simulations or raytracing. Report any artistic degradation.

Save .blend shots and controls. Inspect camera renders when available. Viewport success doesn't establish rendering. Export no finished programme.
