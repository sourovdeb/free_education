# Animate reading and teaching

Build BOOK and TEACH compositions. Load production_defaults.json and validated records. Reuse the reading/teaching library's methods.

Preserve every supplied book word. The source controls written wording. Narration controls observed timing. Flag disagreements without concealing them. Reflow lines; never summarize quotations. Keep teaching additions separately labelled.

Use Blender Text objects. Preserve text data for editing. Keep extrusion at zero initially. Use serif type for quotations. Use sans-serif for teaching labels. Inspect fonts and required glyphs. Do not distribute font files.

Measure glyph height and bounds. Start reading text at 56px. Start labels at 38px. Keep headings near 72px. These describe target screen size. They aren't Blender point-size values. Targets describe full-resolution pixels. Reflow overflow before shrinking text.

Use two lesson sublayouts.
READ: the current line dominates. Keep nearby context when useful.
EXPLAIN: artwork dominates above reading. Retain source text below it.
Both occupy the lesson rectangle. Neither consumes the presenter's third.

Build three reusable text treatments.
LINE_REVEAL: use a clipping mask.
FOCUS_SWEEP: animate an underline curve.
PHRASE_BUILD: reveal phrase-sized text groups.
Preserve the complete source string. Reveal timing follows actual alignment. Line timestamps support line reveals. Word highlights require word timings. Do not guess missing timestamps.

Use alpha, transforms, and keyframes. Use Auto-Clamped Bezier for entrances. Use Constant interpolation for holds. Avoid per-letter objects across books. Build one window at once. Reuse masters rather than regenerate.

Separate stress, prominence, and performance. Mark lexical stress above syllables. Use an underline for prominence. Represent linking with connecting arcs. Label illustrative intonation as guidance. Measurements require actual audio analysis. Use verified pronunciation sources. Keep one accent convention throughout.

Teach meaning, form, and pronunciation. Reuse Idea–Example–Try where useful. Distinguish learner-facing from teacher-facing instructions. Keep exercises outside book quotations. Preserve explicit practice intervals. Otherwise display 'Pause to practise'.

Build charts from supplied data. Preserve units, dates, and denominators. Calculate scales/labels in code. Use meshes and curve paths. Use arrows for evidenced relationships. Label inferred links as interpretations. Use equal projection for comparisons.

Use paper/ink for reading contrast. Use teal pointers, ochre fills. Put ink text over fills. Never rely on colour alone. Preserve source and target IDs.

Check wording, glyphs, timing, arithmetic. Inspect representative animation frames. Report pronunciation or rendering gaps. Save without programme export.
