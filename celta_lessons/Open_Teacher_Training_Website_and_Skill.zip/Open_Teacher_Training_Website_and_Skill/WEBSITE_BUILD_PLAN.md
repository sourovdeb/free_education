# A dedicated Open Teacher Training section on sourovdeb.com
Version 1.0 · 13 September 2026 · Proposed implementation, not a deployed site

## 1. The decision
Build a **small teaching school inside your existing website**, not another category in the general blog. Use **ELT365 — Open Teacher Training** as the proposed public identity; retain “Open Source CELTA 2.0” as an internal project title. Keep the existing site, hosting and theme initially. No new domain, paid LMS or custom AI dashboard is needed for the proposed first release.

Proposed root: `/open-teacher-training/`.
Main website menu label: **Open Teacher Training**.
Section navigation: **Start · Course · Methods · Resources · Practice**.
Standards, sources, corrections and project scope belong in the section footer.

Do not claim accreditation, equivalence, guaranteed employment or superiority. Make public learning and human-assessed practice separate routes.

## 2. What is already on the site
A public-content inspection found an existing `/elt-masterclass/` course index with a 60-day structure. The homepage also lists English-teaching material, methodology posts and ELT365 entries. The inspected Day 7 article already discusses board work, instructions and instruction-checking questions. [S1–S3]

**Design implication:** use the existing material as an archive to audit and reuse. Do not automatically copy every article into the new course. This was a selected-page content inspection, not a full archive, visual, performance or WordPress-admin audit.

Proposed mapping:

| Existing asset | New role | Before including it |
|---|---|---|
| ELT Masterclass index | Earlier course/archive entry point | Add a clear link to the new programme; preserve its URL. |
| Methodology articles | Readings or revised method cards | Check language, claims, examples and source rights. |
| English-learning lessons | Classroom materials linked from training units | Check level fit, instructions, answers and actual materials. |
| ELT365 micro-lessons | Short practice and revision | Deduplicate by content, not title alone. |
| Personal essays and unrelated posts | Stay in the main website | Do not import automatically into the course. |

Keep old URLs unchanged at first. Any later consolidation needs an explicit mapping and tested redirects; a guessed duplicate is not permission to delete a post.

## 3. Whole-section structure
All paths below are proposals, not existing published pages.

```text
/open-teacher-training/                 Programme home
  start-here/                          Scope, readiness, routes, first task
  curriculum/                          Ordered modules and live lesson links
    first-useful-lesson/               Module 2 landing page
      giving-clear-instructions/       First teacher-training unit
    [other module pages added when ready]
  methods/                             Teaching decision library
    giving-instructions/               Reusable method card
    [other methods added when reviewed]
  resources/                           Classroom and trainee downloads
  practice/                            Rehearsal and supported-practice route
  standards/                           Rubrics, limitations, sources, corrections
```

The module-page nesting beneath `curriculum/` is intentional. Assign each WordPress Page's parent accordingly rather than entering slashes in its individual slug. WordPress Pages support this hierarchy. [S4, S5]

### Initial release: seven pages
Publish only **home, start-here, curriculum, the Module 2 page, one complete lesson, resources and standards** after review. At this stage Methods and Practice can be sections on the homepage, not empty destinations. Promote them to separate pages when they contain useful material. Show future curriculum units as plain “planned” text, not broken links or completed lessons.

The complete 12-module framework remains the previous blueprint. Do not try to produce twelve modules before testing one learning cycle.

## 4. Three content types, not one

| Type | Who uses it? | What it must contain |
|---|---|---|
| **Teacher-training unit** | An aspiring teacher | Teaching outcome, demonstration, explanation, rehearsal, observation task and revision. |
| **Teaching method card** | A teacher choosing an approach | When it fits, when it does not, procedure, example, fallback and evidence/limitations. |
| **Classroom material** | English-language learners | Usable text/cards/prompts, clear instructions and a separate teacher key. |

Example: **“How to teach clarification requests”** is a training unit; **“How to set up an information gap”** is a method card; **“Ask your partner to repeat a name”** is a classroom task. Link them, but do not make the learner read trainee-assessment instructions.

## 5. Homepage and lesson layout
### Programme home
Start with a one-sentence purpose: **Learn to teach English through demonstration, practice and revision.**
Primary action: **Start the first lesson** — only link it once it is published.
Secondary action: **Explore the curriculum**.

Then show: who this is for; the two routes; the first available unit; the twelve-module map; the material library; honest assessment limits; version and correction information. Avoid a wall of every post title.

### Standard training-unit page
```text
Breadcrumb + module + unit title
Audience / assumed prior knowledge / time / status / version
What you will be able to do
See an example — text first; optional demonstration video
Understand the teaching decision
Try it — concrete task and complete resources
Compare — explained example, not unexplained answer alone
Rehearse / teach — distinct and honestly labelled
Review — what happened, what evidence, what to change
Downloads — trainee materials / learner materials / teacher key
Sources + corrections + previous / next lesson
```

Show required learning content as HTML, not only a PDF. Use a transcript when video exists, and make the lesson usable without playing it. Use meaningful headings and links, clear instructions and relevant alternatives for images/media. These follow W3C accessibility guidance; they are requirements to test, not a claim of compliance. [S8]

Use your existing typography initially. Provisional design targets: comfortable text size around 18–20 px, restrained line length, visible focus indicators, no autoplay, no mandatory animations, and a single-column phone layout. Do not apply these targets globally to your current site without reviewing the impact.

## 6. WordPress build sequence
### A. Inspect and preserve
Record current theme, editor, existing page IDs/slugs, menu names, permalink structure, available backups and authorised capabilities. Use the current backup/staging facility when available; do not assume your hosting plan includes one. Never change global permalinks, theme or homepage assignment as part of this small section build.

### B. Create the programme home as a draft
Go to **Pages → Add New**. Title it **Open Teacher Training**; save as Draft; set slug to `open-teacher-training`. Use the included homepage block file as a starting point. Pages are appropriate for this non-chronological content. [S4, S5]

### C. Create the other six pilot pages as drafts
Set Parent to Open Teacher Training for Start Here, Curriculum, Resources and Standards. Set the Module 2 page's Parent to Curriculum, then the first lesson's Parent to Module 2. Check the resulting URLs. Do not link publicly to drafts.

### D. Make one reusable lesson pattern
Build and preview one complete unit. Select its content blocks → menu → **Create pattern**. Keep **Synced off** for the lesson-body pattern, so editing Lesson 2 does not also change Lesson 1. For a genuinely shared section notice or navigation strip, a synced pattern can be useful because edits propagate. Test a duplicate before adopting it. [S6]

### E. Add course navigation
For a block theme, use **Appearance → Editor** and edit the relevant Navigation block. The Site Editor requires an activated block theme. For a classic theme, use its existing menu controls, commonly **Appearance → Menus**. Do not switch themes solely to obtain the Site Editor. [S7, S9]

Add one main-menu link to the programme after the hub and first lesson are public. Do not use a live menu action that publishes empty pages. Keep section navigation limited to published destinations. During drafting, use the homepage's internal anchors.

### F. Add resources and media
Upload only reviewed, intentionally public resources. Put a visible file type/version next to each download. Keep assessment submissions and identifiable recordings out of this public resource workflow. Student work needs a separate, permission-tested private process before collection begins. Do not assume a hidden URL or a private-page label secures linked files.

For the pilot use text demonstrations and existing authorised video links where appropriate. Add video only when the demonstration exists, captions/transcript have been checked, and permissions are settled. Do not purchase or install media/LMS tools merely to make the draft look complete.

### G. Preview, approve and publish
Check the seven-page journey on a phone and with keyboard navigation. Open every download; confirm answer keys match task numbering; verify all cross-links. Obtain content approval and publish the reviewed pages. Only then add the public navigation and any main-homepage invitation. WordPress distinguishes Draft, Pending, Private and Published states. [S5]

Do not claim “live” from a successful save alone: read the public page while logged out and check its content. Keep a change log with page IDs, URL, version, reviewer and rollback information.

## 7. What not to build yet
The first release does not need student accounts, a grading engine, payment checkout, a forum, gamified progress, a chatbot, custom post types or dozens of plugins. These are deliberately deferred, not features that ordinary Pages magically provide.

Start with a downloadable progress checklist. It is self-recorded, not an assessment or cross-device tracking system. When mentor-reviewed submissions, controlled enrolment or genuine persistent progress are required, run a separate LMS/private-storage requirements review and verify current free-tier limits before choosing software.

Open reading can remain free; hosting, storage, maintenance and human feedback still need capacity.

## 8. One production pipeline
```text
Existing article or new brief
        ↓
open-teaching-studio skill
        ↓
One reviewed unit folder + stable unit ID
        ↓
Website draft + trainee pack + classroom material + key
        ↓
Human quality review and permission to publish
        ↓
Website lesson + YouTube demonstration + three LinkedIn adaptations
        ↓
Real feedback → correction log → new version
```

Hermes can be assigned drafting/recovery and n8n deterministic routing only after real connectors, credentials and permissions are configured. This package does not connect either system. Start with manual draft handoff; automate the workflow that has actually worked once.

Record `unit_id`, `version`, `audience`, `module`, `objective`, `status`, page ID and publication destinations in one manifest. Check existing unit IDs before creating new drafts. Updates modify the mapped draft after approval; they do not create another near-identical public post.

Use this release sequence: `draft → structural_check → educator_review → approved_for_publication → published`. A structural pass is not educator approval. A later material content change clears previous publication approval.

## 9. Finish the first slice
The first slice is done when a visitor can find the course, understand its limits, complete one unit without a video or AI account, access separate classroom materials, check their work, and understand their next step.

The first pilot theme is **giving instructions people can follow**. This fits the existing Module 2 and gives you a narrow task for testing website structure and teaching-material quality. The included sample is a newly drafted prototype, not a classroom-tested resource.

## Sources
Source IDs refer to `open-teaching-studio/references/SOURCES.md`, containing inspected source locations and limits. Proposed architecture, production cadence and design targets are project decisions, not research findings.
