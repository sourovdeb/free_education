# WordPress starter content

These are block-editor content files, not plugins, themes or independent websites.

Create a new draft Page; set its title separately. Open the editor menu → Code editor, paste one file's text, then return to Visual editor and preview. The theme should provide the Page title as the page's primary heading; the files use subheadings. Inspect the actual output. If you see an invalid-block warning, do not apply a site-wide fix: build the equivalent paragraph and heading blocks manually and report the warning.

`homepage.blocks.html` is a populated, honest programme-in-development draft with on-page anchors. Replace planned text with real reviewed links as the course is built. `lesson-template.blocks.html` is an intentionally unfilled skeleton: complete it before publication, then save an UNSYNCED pattern for separate lesson copies.

No custom JavaScript, third-party tracking, embedded video, forms, fonts or CSS is included. Display inherits the active theme. Nothing was tested inside the live WordPress editor.
