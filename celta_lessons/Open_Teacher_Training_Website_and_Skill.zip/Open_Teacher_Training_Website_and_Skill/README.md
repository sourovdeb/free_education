# Open Teacher Training — website section and teaching skill
Version 1.0 · 13 September 2026 · Prepared for Mishu / sourovdeb.com

## Start with these two files
**WEBSITE_BUILD_PLAN.md** explains the website structure and build sequence.
**open-teaching-studio/SKILL.md** is the reusable teaching-materials and methods skill.

This pack extends the previous Open Source CELTA 2.0 blueprint; it does not replace it. Public-facing identity proposed here: **ELT365 — Open Teacher Training**. The project is independent, does not award CELTA, and has not demonstrated equivalence or superiority to it.

## What is included
- A website architecture and step-by-step WordPress build plan.
- A separate bounded prompt for a website-building agent.
- A WordPress block-editor starter homepage and reusable lesson skeleton.
- One modular teaching skill with method-selection guidance, quality gates, reusable templates and sources.
- An original worked teacher-training unit, with a separate classroom handout and answer/observation guidance.
- A read-only Python structural checker and its tests. It does not assess teaching quality.

## Install the skill in Hermes
Extract this archive. Copy **only the `open-teaching-studio` folder**, with all its contents, into the skills directory for the Hermes profile you actually use. The documented default is:

```text
~/.hermes/skills/open-teaching-studio/SKILL.md
```

Use `/skills` to check discovery; in a new session try:

```text
/open-teaching-studio Create one teacher-training unit on giving clear instructions. Use Module 2. Include the trainee activity, a separate adult A2 classroom handout, answer guidance and a publication draft. Keep everything in draft.
```

These paths and skill invocation follow the official Hermes documentation inspected on 13 September 2026. Runtime discovery on your own machine has not been tested. Keep a backup before replacing an existing skill folder. A skill is instructions, not an installed WordPress connection, publishing credential or proof of subject expertise.

## Start the website
Open `WEBSITE_BUILD_PLAN.md`. For a first draft, open `website-starters/homepage.blocks.html` as a text file and copy its contents into a new WordPress Page using the editor's Code editor. Switch back to Visual editor and preview. Set the Page title to **Open Teacher Training**. Do not upload the archive through Plugins: it is not a WordPress plugin.

The starter uses ordinary paragraph and heading blocks, inherits your theme's appearance, and does not install scripts, fonts or external services. Its anchor links stay on the page. It requires a real WordPress preview before use; it was not tested inside your site.

## Optional structural check
With Python 3.9 or later, from the `open-teaching-studio` directory:

```bash
python scripts/validate_pack.py examples/instructions-unit/manifest.json
python -m unittest discover -s scripts -p 'test_*.py'
```

No extra Python packages, network access or API keys are required by these scripts. The generated sample remains an unpiloted draft even when structural checks pass.

## Review boundary
Inspected: the previously generated editable blueprint; the supplied rigorous-analysis framework; the public homepage, ELT Masterclass index and one instructions/ICQs article; official documentation listed in `open-teaching-studio/references/SOURCES.md`.

Not inspected: your WordPress dashboard, installed theme/plugins, hosting settings, unpublished posts, original CELTA tutor handouts or real classroom outcomes. No live website changes, installation, publication, student enrolment or external messages were performed.

## Rights
All sample activities and template wording in this pack were newly drafted. External sources remain separately controlled. CC BY-SA 4.0 remains a **proposed publication licence requiring the owner's decision and rights review**; this pack does not relicense your existing archive or third-party content. Do not distribute private materials from previous conversations with the public course.
