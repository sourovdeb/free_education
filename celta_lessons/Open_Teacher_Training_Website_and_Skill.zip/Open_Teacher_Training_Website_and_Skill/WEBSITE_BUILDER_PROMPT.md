# Bounded prompt for a website-building agent
Use this separately from the teaching-materials skill. It is a task specification, not evidence of website access.

```text
Build the first draft of an Open Teacher Training section on sourovdeb.com using WEBSITE_BUILD_PLAN.md and the supplied website-starters files.

Preserve the existing theme, homepage, URLs, ELT Masterclass index and unrelated posts. Public identity: ELT365 — Open Teacher Training. This project is independent and does not award CELTA. Do not publish claims of equivalence, accreditation or superiority.

FIRST: inspect the authorised WordPress connection and its actual read/write capabilities. Read the active theme/editor, relevant pages, menus, URL structure and backup availability. Do not infer access from this prompt or ask for credentials in a public document. Do not install plugins, change global settings or invent tool commands.

THEN: find existing pages at the proposed slugs to prevent duplicates. Create or update only the seven pilot DRAFT pages: programme home, Start Here, Curriculum, Module 2, giving-clear-instructions, Resources and Standards. Use the proposed parent hierarchy. Record IDs and preview locations. Use the supplied original lesson sample, clearly marked draft/unpiloted.

Use core blocks and an UNSYNCED lesson-body pattern. Shared notices can be synced. The homepage supplies internal navigation while downstream pages are drafts; do not expose links to inaccessible drafts. Leave future modules as labelled planned text. Do not add a public menu link yet.

Keep teacher-training instructions separate from learner-facing handouts. Do not copy private files, learner submissions, unlicensed coursebook pages or unreviewed archive posts into the public Media Library. No forms or personal-data collection in this first build.

VALIDATE: preview on phone and desktop; keyboard navigation; headings; task/key correspondence; download readability; links; published-versus-draft labels; no fabricated video or review status. Check that unrelated pages and URLs were unchanged. Report checks actually performed, not a generic “everything works”.

STOP AT: draft-ready with an exact change log, unresolved issues and rollback instructions. Publication and a live menu change require a separate explicit instruction. When a connector or feature is unavailable, deliver a complete local block/HTML/Markdown draft with an exact handoff; do not pretend to have edited WordPress.
```
