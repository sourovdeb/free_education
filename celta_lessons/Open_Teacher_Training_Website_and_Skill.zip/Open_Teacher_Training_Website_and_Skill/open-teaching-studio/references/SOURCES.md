# Source register and review boundary
Inspected 13 September 2026. URLs identify the sources; verify again for future version-specific work. Source descriptions below are intentionally narrow. No page grants blanket republication rights to its linked material.

## Website inspection
**S1 — Sourov Deb homepage**
https://sourovdeb.com/
Inspected public parsed content: topic organisation, listed teaching entries and existing navigation. Not a full visual, performance or administrative audit.

**S2 — ELT Masterclass course index**
https://sourovdeb.com/elt-masterclass/
Inspected index: existing 60-day structure, links and planned entries. Individual lessons not all reviewed.

**S3 — Day 7: Board Work, Instructions & ICQs**
https://sourovdeb.com/day-7-board-work-instructions-icqs-60-day-elt-masterclass/
Inspected selected content, including instruction-checking explanations. It is a reuse candidate, not independent proof of pedagogical effectiveness.

## WordPress, primary documentation
**S4 — Create pages**
https://wordpress.org/documentation/article/create-pages/
Pages, parent/subpage organisation and non-chronological use.

**S5 — Page/Post Settings sidebar**
https://wordpress.org/documentation/article/page-post-settings-sidebar/
Draft/publication settings, slugs, parent relationships and theme-dependent controls. Dashboard details can vary by installation.

**S6 — Synced Patterns (Reusable blocks)**
https://wordpress.org/documentation/article/reusable-blocks/
Creating a pattern and enabling synchronisation. Project recommendation: ordinary lesson bodies should be independent copies.

**S7 — Site Editor**
https://wordpress.org/documentation/article/site-editor/
Site Editor availability with block themes. The active theme on this website was not inspected.

**S9 — Navigation block**
https://wordpress.org/documentation/article/navigation-block/
Navigation editing and supported theme contexts; warns that creating a new page from navigation can publish an empty page.

## Pedagogy and accessibility
**S8 — W3C WAI: Writing for Web Accessibility**
https://www.w3.org/WAI/tips/writing/
Headings, meaningful links, alternatives, captions/transcripts and clear instructions. This pack is not an accessibility conformance audit.

**S10 — Council of Europe: Classroom teaching and CEFR**
https://www.coe.int/en/web/common-european-framework-reference-languages/classroom-teaching
Alignment using selected descriptors; action-oriented framework. This is not evidence validating the sample's provisional A2 label.

**S11 — British Council TeachingEnglish: A task-based approach**
https://www.teachingenglish.org.uk/professional-development/teachers/knowing-subject/task-based-approach
Task-centred sequence and attention to language emerging from performance. Method-choice heuristics in this pack are original design proposals, not comparative-effectiveness claims.

## Agent skill format
**S12 — Hermes Skills System**
https://hermes-agent.nousresearch.com/docs/user-guide/features/skills/
Default skill directory, SKILL.md and supporting resources, discovery and slash-command use. No user-machine installation was tested.

**S13 — Agent Skills specification**
https://agentskills.io/specification
Required name/description frontmatter, directory naming, optional resources and progressive loading. This pack uses the common format; host-specific behaviour still requires testing.

## User-provided project sources
**P1 — Open_Source_CELTA_2_0_Blueprint_Editable.md**
Read from the active conversation files. Contains the previous twelve-module programme, proposed hours, two routes and publishing system. These are inherited design decisions, not independent research findings.

**P2 — rigorous-analysis.zip**
Inspected the supplied SKILL.md framework and templates in this conversation. Adapted the framework's evidence labels, source-inspection boundaries, alternative explanations and correction discipline. The ZIP does not contain original CELTA teaching handouts.

## Explicit exclusions
No original CELTA course-document audit, live WordPress administration, installed-plugin review, measured learning outcomes or model-specific skill evaluation has been completed here. The Python tests are structural software tests only.
