# Project context
Version 1.0 · Design context, not proof of effectiveness

Public identity proposed: **ELT365 — Open Teacher Training**.
Internal working title: **Open Source CELTA 2.0**.
Website section proposed: `/open-teacher-training/` on sourovdeb.com.

The initial programme trains teachers of **adult English learners**. It is not an English course whose trainees can be assigned an A2 teacher-qualification level. Classroom samples can target particular language levels, provisionally and with justification.

The previous booklet proposes twelve modules:
1. Understand the learner.
2. Plan and teach a first useful lesson.
3. Teach grammar and functions.
4. Teach vocabulary and expressions.
5. Teach pronunciation for communication.
6. Teach reading and listening.
7. Teach speaking and writing.
8. Run an inclusive classroom.
9. Assess learning and give feedback.
10. Teach with the internet and without reliable internet.
11. Use AI without surrendering judgement.
12. Become a reflective, independent teacher.

Teaching practice is threaded through the programme. The proposed 200-hour supported pathway includes twelve observed teaching hours; these remain pilot design allocations, not verified completion times, equivalence claims or available mentoring promises. Do not assign those hours to a self-study user automatically.

Two routes remain distinct: open self-study materials and mentor-supported real teaching. Self-study, peer rehearsal and AI role-play do not count as observed real-learner practice. Only represent support as available after mentors, learners and a suitable private process are actually arranged.

Every unit is stored by stable ID and version. Example: `OTT-M02-U01`, version `0.1.0`. Metadata distinguishes audience, module, classroom example level, prerequisite knowledge, time, planned outcomes, rights review and publication status.

The website is the canonical full lesson. YouTube demonstrates decisions; LinkedIn offers a problem, example and practice invitation. These are adaptations of one reviewed unit, not three independently invented lessons.

The rigorous-analysis attachment contributes: inspected-source records, competing explanations, calibrated claims, actual-versus-assumed outcomes, reversible decisions and correction logs. It does not provide CELTA handouts or evidence of classroom success.

Public resources must exclude participant submissions, personal records and private project information. Keep the site's older ELT Masterclass and ELT365 URLs unchanged unless a separate migration is authorised.
