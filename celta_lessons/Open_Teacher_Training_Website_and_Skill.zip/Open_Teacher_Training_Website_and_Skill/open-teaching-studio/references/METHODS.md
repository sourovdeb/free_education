# Choose a teaching approach, then the techniques
The definitions grounded in sources below are distinct from the **proposed selection heuristics**. These heuristics are design decisions to test with the real group, not rankings of universal effectiveness.

## Start with the decision
Ask: what should learners be able to do, what can they already do, what is the obstacle, and what evidence would show progress? Relevant CEFR descriptors can help align planning, teaching and assessment; the CEFR does not validate an AI-generated lesson merely because it has a level label. [S10]

| Need or constraint | Candidate design | Main risk / fallback |
|---|---|---|
| A narrow unfamiliar language feature | Clear contextual model → explanation/noticing → supported practice → useful application | Mechanical accuracy may not transfer. Add a fresh communicative check. |
| Uncertain prior knowledge | Low-stakes attempt → diagnose → targeted teaching → new attempt | Do not turn the opening into a punitive test. Offer a model when the baseline is too difficult. |
| A meaningful problem requiring exchange | Prepare → carry out task → report → examine useful language → retry | An unsupported task can overwhelm. Add accessible input and preparation. |
| Discoverable pattern in a small text | Examples → focused questions → tentative rule → teacher check → use | Ambiguous data can teach a false rule. Give direct explanation when it is more efficient. |
| Reading/listening with a practical purpose | Set purpose → supported encounter → targeted processing → response | Not every text needs a prescribed gist-then-detail routine. Use tasks that match the purpose. |
| Writing for a real audience | Explore model → plan → draft → focused feedback → revise | Too many corrections obscure priorities. Select one or two relevant revision goals. |
| Pronunciation impedes understanding | Listen/notice → compare → supported production → meaningful exchange | Decontextualised imitation is insufficient. Check intelligibility in a new message. |
| Mixed needs, little equipment | Shared task with optional scaffolds and extension | Simplifying everything may remove the goal. Preserve the outcome while varying support. |

These are alternative designs, not eight obligations for every lesson.

## Task-based versus task-supported
British Council's task-based account centres a meaningful task and addresses language emerging from performance. [S11] An exercise whose sole purpose is using a predetermined form is not automatically a full task-based lesson. Call a lesson **task-supported** when it teaches selected language first and then uses a communicative task to practise it. Name the actual sequence, not a fashionable label.

For each communicative task specify a purpose, an information/decision gap where appropriate, who knows what, interaction, an outcome, and what the teacher will observe. A worksheet containing paired questions without a purpose is not enough.

## Useful techniques and their limits
**Instructions:** state the goal, first action, roles and a needed rule; show an example; observe the first attempt. Ask an instruction-checking question only for a likely confusion. Do not add “Are you in pairs?” when the arrangement is already obvious and functioning.

**Meaning checks:** use a situation, choice, timeline, example or question that tests the target distinction. Avoid questions more linguistically difficult than the point being checked. A learner saying yes to “Do you understand?” is not sufficient evidence by itself; a blanket ban on the phrase is also not a teaching method.

**Modelling and worked examples:** show both a usable version and a plausible weak version. Explain the consequential difference. Do not manufacture a weak version so absurd that it teaches no transferable judgement.

**Retrieval and later reuse:** build opportunities to attempt material again rather than only reread it. Treat the spacing and frequency as provisional design choices unless supported by relevant evidence; do not invent memory percentages.

**Feedback:** select an important observable gap, explain or model the correction, and arrange another attempt. Positive reaction, task completion and learning are distinct observations.

**Multilingual support:** allow meaning checks or planning with shared languages when it serves the task. Do not equate an English-only rule with quality, or assume all participants share a language.

**AI:** useful for generating variants or rehearsing a scenario after review. No paid AI is essential to the course. Check output, separate synthetic from real examples, and preserve a complete non-AI route.

## Method card contract
A reusable method card answers:
- What problem does it address, and for whom?
- When is it a poor fit?
- What are the actual steps, words, materials and checks?
- What does a weak implementation look like?
- What will be observed, and what happens when it fails?
- Which claims are sourced, which are design choices, and what remains untested?

Use short neutral examples. Do not teach methods through unsafe activities or force learners to reveal health, family or financial experiences.

## Language-specific checks
For vocabulary, select items serving a usable situation; give meaning in context, a natural example and useful combinations. For grammar, check meaning, form, use and restrictions rather than relying on a slogan. For pronunciation, make stress notation explicit, verify phonetic transcriptions, and distinguish intelligibility from accent imitation. For listening, use an actual audio file or label a supplied script as a live-read activity—not as an existing recording.
