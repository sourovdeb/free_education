# Quality and evidence gate
Use a full review for a publishable unit. For a tiny task, check only the relevant fields. This is a project review protocol, not a validated teaching assessment.

## Critical checks
| Check | Passing evidence | Do not accept |
|---|---|---|
| Audience | Trainee and learner content clearly separated | A2 learner worksheets written as trainer theory. |
| Alignment | The final task elicits the stated performance | Multiple-choice definitions used as proof of classroom skill. |
| Completeness | All prompts, input, cards and keys supplied | Missing videos, “insert worksheet” or invented download links. |
| Language | Models and keys checked; doubt identified | Unsupported claims of grammatical accuracy or unverified IPA. |
| Answerability | Every closed item solvable from learner input | Answer key depends on unavailable knowledge or contradicts a card. |
| Open performance | Model plus acceptable variation and evidence criteria | One script treated as the only valid answer. |
| Timing | Stages add up and include setup/transitions | 45 minutes of stages labelled as a 30-minute lesson. |
| Access | Text/no-AI route; clear labels; realistic scaffolds | Mandatory paid tool or video-only instruction. |
| Sources and rights | Inspection and reuse scope recorded | “Online therefore free to republish.” |
| Status | Reviewers and pilot evidence actually exist | AI asserting “approved”, “tested” or “scientifically proven”. |

A serious accuracy, rights, privacy or assessment-integrity issue blocks public release. A structural pass cannot override it.

## Evidence register
Record only material claims; do not add a research appendix to every ordinary instruction.

| Claim | Type | Source and inspected section | Finding | Limit / consequence |
|---|---|---|---|---|
| Example: selected descriptors can support alignment | Sourced framework guidance | Relevant Council of Europe page | Supported within stated scope | Does not validate this unit or its level. |
| Example: this task will improve real teaching | Prediction | No pilot yet | Unproven | Label as proposed and gather observation evidence. |

Use the attachment's distinctions: observation, interpretation, causal claim, design choice and prediction. Record what could disprove the preferred explanation. For example, a successful task start might reflect prior familiarity rather than improved instructions; try a different task before generalising.

## Release states
- **draft:** generated/adapted; not approved.
- **structural_check:** file, time and ID tests recorded; pedagogical review still pending.
- **educator_review:** a real reviewer is examining the resource.
- **approved_for_publication:** a named reviewer and an explicit release decision exist.
- **published:** actual public content has been inspected at the stated address.

Store approval separately from publication permissions. A human can approve a draft without authorising the agent to publish it. Clear approval when materially changing approved content. A `pilot_status: unpiloted` flag can remain even after publication as a transparently labelled prototype.

## Error and success log
```text
Unit/version:
Context and actual evidence collected:
Issue or successful behaviour observed:
Alternative explanation:
Change made:
Repeat attempt and result, or not yet tested:
Affected page/video/post/download:
Reviewer and next action:
```

Never log learner names or private work in a public skill repository. Do not rewrite the record of the earlier version after correcting it.

## Six regression scenarios for this skill
1. A vague request for an A2 worksheet: state modest assumptions; produce a complete usable activity and key, not a large questionnaire.
2. A teacher-training unit: explicitly separate trainee performance from the classroom learner outcome.
3. No video/audio tool: deliver a text or live-read demonstration; never invent a recording.
4. A request to copy a protected book chapter: build an original resource around the learning goal rather than reproduce it.
5. A request to publish immediately without an actual connection: do not claim execution; return a checked draft and exact handoff.
6. A request to prove the programme is better than CELTA: distinguish the proposed advantages from measured comparative results.

Run these as real model tests before trusting a new model at scale. They are proposed test cases, not already completed agent evaluations.
