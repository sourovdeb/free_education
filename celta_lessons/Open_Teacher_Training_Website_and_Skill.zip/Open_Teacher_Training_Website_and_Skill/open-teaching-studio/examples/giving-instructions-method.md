# Method card — Set up the first exchange
ID: OTT-METHOD-001 · Version 0.1.0 · Original design · Draft / unpiloted

## The teaching problem
Participants see a worksheet but do not know who begins, what to exchange or what to produce. This technique concerns task setup; it is not a complete language-teaching approach.

## Use it when
A pair or group task has a sequence that is not already familiar. Choose a shorter reminder when the group already knows the routine. When task language itself is unfamiliar, address that obstacle rather than repeatedly rewording instructions.

## Procedure
Identify the activity's outcome, first action, roles and any necessary rule. State them in manageable language. Demonstrate one exchange using an extra example, then let participants begin. Observe the first attempt. Ask a checking question only about an uncertainty that matters.

## Worked example
An information-gap timetable requires each learner to ask for missing times without revealing their own card.

Teacher: “Keep your card to yourself. A, ask about the first missing time. B, answer. A, write the time. Then B asks. Watch one example first.”

Demonstration: “What time is the language club?” — “It is at ten o'clock.” The listener writes 10:00 in a sample box. This model uses an extra event rather than disclosing answers on the task cards.

Possible check, only when needed: “Do you show your card?” — “No.” Then watch the actual first exchange.

## Weak implementation and repair
Weak: “Help each other complete everything.” It omits the exchange sequence and may encourage learners to show both cards.

Repair: demonstrate the first missing-information exchange and the listener's written response. The repair targets the particular gap; adding more unrelated checking questions would not.

## What to observe
Can participants take the intended roles, keep the missing information private and record the first requested time? Record any help. Correct answers alone are not evidence of good setup if learners saw both cards.

A plausible alternative explanation for success is that participants already knew the activity. Before generalising, observe the setup of a new comparable task.

## Access and fallback
Use separate paper cards, separate accessible text files, or a live spoken exchange. No AI or video is needed. Do not require public sharing of private messages or screens. When learners need language support, provide a question model or check the relevant time expressions first.

## Evidence and limits
This is an original instructional design proposal with no pilot evidence or measured effect size. The method connects to the worked unit OTT-M02-U01. Further reading candidates are listed in the skill's source register; the card does not imply endorsement by Cambridge, the British Council or another institution.
