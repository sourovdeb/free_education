# Teacher key and trainee observation guide
OTT-M02-U01 · Version 0.1.0 · Keep separate from the learner handout during the task.

## Closed answers
| ID | Answer | Source available to the other partner |
|---|---|---|
| A1 | 11:00 | Card B, Art class |
| A2 | 16:00 | Card B, Conversation club |
| B1 | 09:00 | Card A, Reading group |
| B2 | 14:00 | Card A, Computer class |

Accept equivalent unambiguous representations of these same times, such as “eleven o'clock” or “four in the afternoon”. The closed-answer check is whether the intended time was communicated, not whether handwriting matches the key exactly.

## Example exchange
A: “What time is the art class?”
B: “It is at eleven o'clock.”
A records 11:00.

Other intelligible, appropriate questions and responses can fulfil the goal. Do not require memorisation of this exact script.

## Open observation task
Record **yes / with support / not yet observed**, with a brief example:
1. Participants know who asks first and what to do next.
2. They keep their cards separate, preserving the missing information.
3. The listener writes the intended answer.
4. The teacher notices a problem and gives relevant help rather than restarting the entire explanation unnecessarily.

The teacher may use a short instruction, a demonstration or both. No fixed number of instruction-checking questions is required. These criteria are proposed training feedback, not a validated pass/fail qualification rubric.

## Revision prompt
“During the first exchange, I observed ____. One possible explanation is ____. I changed ____. On the next attempt, ____ happened / a repeat has not yet been possible.”

## What not to infer
Correct timetable answers alone do not prove effective instructions, language learning or teaching competence. Participants could rely on earlier knowledge, imitation or seeing both cards. Record the process and support, not only the finished worksheet.
