# Channel adaptations — draft only
Unit OTT-M02-U01 · Version 0.1.0
No post was published and no video was recorded. Do not add a lesson link until the website page is live and checked.

## YouTube demonstration script
**Working title:** Clear instructions: show the first step.
**Format:** Narration over text and fictional task cards. No real learner recording is required. Target length is provisional; time a rehearsal before adding timestamps.

Opening: “Here are two instructions for the same activity. Which one tells you how to begin?” Display the weak instruction from the teacher guide, then the revised instruction.

Demonstration: Show an extra sample event rather than revealing the task's answers. Narrate A asking the time, B answering and A recording it. Explain the first action, roles, written outcome and no-showing rule.

Judgement: “Shorter is not automatically better. The useful question is whether the participants can start correctly, and what support they need.”

Practice: Invite viewers to write an instruction for the timetable task. Distinguish solo rehearsal, peer rehearsal and real teaching.

Close: “Try one revision based on what you observe. The complete task and teacher guide belong with the website lesson.” Add the real link only after publication.

Accessibility handoff: the script is not timed captions. After recording, create captions from the actual audio, check them and publish a matching transcript.

## LinkedIn 1 — problem
A learner can understand every word in your instructions and still not know what to do first.

For your next activity, write down four things: the first action, the roles, the outcome and any rule that actually matters. Then demonstrate one exchange.

The test is not whether everyone nods. Watch how the activity begins.

## LinkedIn 2 — worked example
“Practise together” is a request, but it is not yet a task setup.

Try: “A asks about the missing time. B answers. A writes the time. Then swap. Watch one example first.”

That version makes the sequence visible. It still needs testing with the actual learners; familiar students may need less support, and a new group may need more.

## LinkedIn 3 — practice invitation
Choose one activity you already teach. Rewrite its instructions, then show the first step instead of explaining the entire activity again.

Record what participants actually do. Change one instruction based on that evidence.

For an open teacher-training project, I am developing practical units built around demonstration, rehearsal and revision. This is a prototype approach, not a claim of accreditation or proven superior results.
