# Complete the community timetable
Use one card per person. Do not show your card. Ask your partner for missing times and write the answers. Then swap roles.

Useful questions and answers:
“What time is the reading group?”
“It is at nine o'clock.”
“Could you say that again?”

## Card A — give only this card to learner A
Keep your card to yourself. Ask about the missing times.

| Event | Time |
|---|---|
| Reading group | 09:00 |
| Art class | **A1: __________** |
| Computer class | 14:00 |
| Conversation club | **A2: __________** |

## Card B — give only this card to learner B
Keep your card to yourself. Ask about the missing times.

| Event | Time |
|---|---|
| Reading group | **B1: __________** |
| Art class | 11:00 |
| Computer class | **B2: __________** |
| Conversation club | 16:00 |

These are fictional events and times. The table is an original classroom practice task.
