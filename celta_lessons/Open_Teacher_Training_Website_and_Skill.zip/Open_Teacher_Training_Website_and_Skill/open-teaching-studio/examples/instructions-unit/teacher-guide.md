# OTT-M02-U01 — Give instructions people can follow
Version 0.1.0 · Module 2 · TRAINER_UNIT · Draft / unpiloted

## Audience and assumptions
Trainee English teachers preparing to teach adults. The classroom example assumes adults around A2 who can ask “What time…?”, recognise the times used, and follow a short demonstration. The level is a planning estimate, not externally validated. Use fictional schedules. No personal information, accounts, AI or video required.

**Trainee outcome:** give and demonstrate a two-role information-gap task so both participants can start the correct first exchange without repeated explanation.
**Sample learner outcome:** exchange missing times and complete a four-event fictional timetable.
**Local observation criterion:** the two participants start with the correct roles, keep the information gap, and record the first missing time. Record support needed. This is a narrow rehearsal check, not proof of teaching competence.

Time: **30 minutes of trainee study/rehearsal**. Real-learner practice is a separate future activity requiring actual arrangements and observation. It is not included or claimed here.

## A realistic weak version
“Look at these schedules and practise the questions together. You have different information, so help each other and then we will check.”

It leaves the first speaker, the written outcome and the no-showing rule unclear. A confident pair might still succeed from prior experience; that would not establish that the instructions were clear.

## A usable version
“Keep your card to yourself. A, ask about the first missing time. B, answer. A, write the time. Then B asks. Watch one example first.”

Demonstrate using the sample below, which is not an answer from the actual cards:
A: “What time is the language club?”
B: “It is at ten o'clock.”
A writes **10:00** in an example box.

When the information gap could be lost, ask “Do you show your card?” Expected answer: “No.” Do not add checking questions for details already clear. Watch the first exchange and intervene only where the task cannot begin correctly.

## Thirty-minute sequence
| Stage | Minutes | What the trainee does | Evidence |
|---|---:|---|---|
| Baseline | 3 | Write a first instruction for the supplied schedule task without reading the improved model. | Save the actual wording. |
| Compare | 5 | Read weak and improved examples. Mark first action, roles, outcome and necessary rule. | Identify a consequential omission, not merely a shorter sentence. |
| Design | 5 | Write a personal instruction script and a ten-second demonstration using the sample event. | All needed information is present; language is manageable. |
| Rehearse | 8 | With two peers, set up the task. Watch the first exchange. Peers then finish both cards. In solo study, predict actions but label the activity simulation. | Roles, task start, gap preserved and support needed. |
| Review | 5 | Use the observation guide; compare the completed schedules with the key. | Distinguish task answers from instruction quality. |
| Revise | 4 | Change one important instruction and rehearse the setup again, or plan a repeat when peers are unavailable. | Revised wording plus an honest result or “not tested”. |
| **Total** | **30** | | |

## Materials and answers
Use `learner-handout.md`: Card A and Card B are separate learner copies. Use `answer-key.md` only for checking and observation. No additional worksheet is needed.

## Adaptations
Online: send each participant only their own card or put it in a private message; do not rely on public shared screens that reveal both. In person: separate paper copies. Low bandwidth: read the necessary lines and take notes. Prior-knowledge gap: teach/check time expressions before this example rather than treating unfamiliar language as an instruction failure.

A participant who needs a different access arrangement can have a support partner or accessible text. Adapt the mode while preserving the information gap and purpose. Do not equate speed with understanding.

## Progression to real teaching
When a real adult group and human observer are arranged, use a new but comparable task. Record what learners actually do and the help required. Peer rehearsal and solo prediction remain separate from observed teaching hours. Repeating a familiar task can improve performance through familiarity; test a fresh setup before attributing improvement to instructions alone.

## Evidence status
All examples, timings and criteria are original design proposals. No pilot, audio/video production or educator review has occurred. Framework sources and website-source boundaries are in `references/SOURCES.md` at the skill root. The existing website's Day 7 article is a possible further reading, not the source of these fictional schedules.
