# Give instructions people can follow
Module 2 · Teacher-training unit · 30 minutes · Prototype, not yet classroom-tested

## Your goal
Set up a two-role task so participants know how to begin. The example uses a fictional timetable with adult English learners. You do not need AI or a video account.

## Notice the difference
“Practise together and help each other” does not tell participants who speaks first or what to write.

Try: “Keep your card to yourself. A, ask about the first missing time. B, answer. A, write the time. Then B asks. Watch one example first.”

Demonstrate with an extra example: “What time is the language club?” — “It is at ten o'clock.” Show the listener writing 10:00. This example is not one of the task answers.

## Why this choice
The instructions identify the first action, roles, outcome and necessary rule. A demonstration shows the sequence. Whether this helps your group needs observation; do not infer success from a nod.

## Try it
Write your own instructions. Use Card A and Card B from the learner handout, giving each participant only their own card. Watch the first exchange. Did participants know how to begin? What help did they need?

With no practice partners, predict what a learner would do at each instruction. Mark this as solo rehearsal, not real teaching.

## Compare and revise
Use the separate answer and observation guide. Change one part of your instructions based on what happened. Try again with a fresh task when possible. Repeated success on the same activity may reflect familiarity, not only better instructions.

## Resource files
Editorial handoff: attach the reviewed learner handout and answer/observation guide as separate public resources, then replace this paragraph with real working links. This page is still a draft. Do not publish this handoff paragraph or invent download URLs.

## Next step
Apply the same design to another task with a different outcome. When mentor-supported real teaching is available, use the observer's notes to revise again. This unit alone does not assess teaching competence.

## Scope and sources
This is an original proposed unit. Its timings and local observation criteria are design choices, not validated findings. Publish a human review date only after review occurs. Link to the project's reviewed source register and correction route when those pages are available.
