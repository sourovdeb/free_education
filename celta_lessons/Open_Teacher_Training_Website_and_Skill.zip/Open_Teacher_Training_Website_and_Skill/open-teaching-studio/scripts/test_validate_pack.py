"""Regression tests for structural checks; these are not model/teaching tests."""
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from validate_pack import validate_manifest


class ValidatorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / 'unit'
        source = Path(__file__).resolve().parents[1] / 'examples' / 'instructions-unit'
        shutil.copytree(source, self.root)
        self.path = self.root / 'manifest.json'
        self.data = json.loads(self.path.read_text(encoding='utf-8'))

    def tearDown(self):
        self.temp.cleanup()

    def save(self):
        self.path.write_text(json.dumps(self.data), encoding='utf-8')

    def test_valid_draft(self):
        self.assertEqual(validate_manifest(self.path), [])

    def test_missing_handout(self):
        (self.root / 'learner-handout.md').unlink()
        self.assertTrue(validate_manifest(self.path))

    def test_bad_time_total(self):
        self.data['duration_minutes'] = 25
        self.save()
        self.assertTrue(any('total' in x for x in validate_manifest(self.path)))

    def test_negative_stage(self):
        self.data['stages'][0]['minutes'] = -1
        self.save()
        self.assertTrue(validate_manifest(self.path))

    def test_key_mismatch(self):
        self.data['answer_ids'].pop()
        self.save()
        self.assertTrue(any('correspond' in x for x in validate_manifest(self.path)))

    def test_file_escape(self):
        self.data['files']['review'] = '../outside.md'
        self.save()
        self.assertTrue(any('escapes' in x for x in validate_manifest(self.path)))

    def test_unsupported_approval(self):
        self.data['publication']['approved'] = True
        self.save()
        self.assertTrue(any('reviewer' in x for x in validate_manifest(self.path)))

    def test_published_without_url(self):
        self.data['status'] = 'published'
        self.data['publication']['approved'] = True
        self.data['human_review'] = {'status': 'reviewed', 'reviewer': 'Test fixture only', 'date': '2026-09-13'}
        self.save()
        self.assertTrue(any('URL' in x for x in validate_manifest(self.path)))

    def test_missing_item_marker(self):
        handout = self.root / 'learner-handout.md'
        handout.write_text(handout.read_text(encoding='utf-8').replace('A1:', 'Gap:'), encoding='utf-8')
        self.assertTrue(any('A1' in x for x in validate_manifest(self.path)))

    def test_bad_json(self):
        self.path.write_text('{', encoding='utf-8')
        self.assertTrue(validate_manifest(self.path))

    def test_audience_confusion(self):
        self.data['audience'] = 'english_learners'
        self.save()
        self.assertTrue(any('TRAINER_UNIT' in x for x in validate_manifest(self.path)))

    def test_invalid_field_types(self):
        self.data['mode'] = []
        self.data['status'] = {}
        self.data['audience'] = []
        self.data['human_review']['status'] = {}
        self.save()
        self.assertTrue(validate_manifest(self.path))

    def test_duplicate_ids(self):
        self.data['task_ids'].append('A1')
        self.save()
        self.assertTrue(any('duplicates' in x for x in validate_manifest(self.path)))

    def test_boolean_duration(self):
        self.data['duration_minutes'] = True
        self.save()
        self.assertTrue(validate_manifest(self.path))


if __name__ == '__main__':
    unittest.main()
