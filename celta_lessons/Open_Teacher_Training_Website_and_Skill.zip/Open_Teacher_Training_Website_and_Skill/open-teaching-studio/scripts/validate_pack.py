#!/usr/bin/env python3
"""Read-only structural checks for Open Teaching Studio unit manifests.

No network access, writes, pedagogy grading, or external dependencies.
A pass does not validate source truth, language quality, rights, or approval.
"""
import argparse
from datetime import date
import json
import math
from pathlib import Path
import re
from typing import List
from urllib.parse import urlsplit


REQUIRED_FILES = {'teacher_guide', 'learner_handout', 'answer_key', 'website_draft', 'review'}
STATUSES = {'draft', 'structural_check', 'educator_review', 'approved_for_publication', 'published'}


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def positive_number(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value > 0)


def validate_manifest(path: Path) -> List[str]:
    """Return structural errors. Never change a manifest or its status."""
    errors = []
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return ['Cannot read valid UTF-8 JSON: {}'.format(exc)]
    if not isinstance(data, dict):
        return ['Manifest must be a JSON object.']
    for field in ('unit_id', 'version', 'objective', 'audience', 'pilot_status', 'rights_status'):
        if not nonempty(data.get(field)):
            errors.append('{} must be a non-empty string.'.format(field))
    mode = data.get('mode')
    status = data.get('status')
    audience = data.get('audience')
    if not isinstance(mode, str) or mode not in {'TRAINER_UNIT', 'CLASSROOM_LESSON'}:
        errors.append('This checker supports TRAINER_UNIT and CLASSROOM_LESSON manifests only.')
    if not isinstance(status, str) or status not in STATUSES:
        errors.append('Unrecognised status.')
    if not isinstance(audience, str) or audience not in {'trainee_teachers', 'english_learners'}:
        errors.append('audience must be trainee_teachers or english_learners.')
    if data.get('mode') == 'TRAINER_UNIT' and data.get('audience') != 'trainee_teachers':
        errors.append('TRAINER_UNIT must identify the trainee_teachers audience.')
    if data.get('mode') == 'CLASSROOM_LESSON' and data.get('audience') != 'english_learners':
        errors.append('CLASSROOM_LESSON must identify the english_learners audience.')
    duration = data.get('duration_minutes')
    if not positive_number(duration):
        errors.append('duration_minutes must be a positive finite number.')
    stages = data.get('stages')
    total = 0.0
    stage_ids = set()
    stages_valid = isinstance(stages, list) and bool(stages)
    if not stages_valid:
        errors.append('stages must be a non-empty list.')
    else:
        for index, stage in enumerate(stages):
            if not isinstance(stage, dict):
                errors.append('Stage {} must be an object.'.format(index))
                stages_valid = False
                continue
            sid = stage.get('id')
            if not nonempty(sid) or sid in stage_ids:
                errors.append('Stage {} needs a unique non-empty id.'.format(index))
                stages_valid = False
            else:
                stage_ids.add(sid)
            minutes = stage.get('minutes')
            if not positive_number(minutes):
                errors.append('Stage {} needs positive finite minutes.'.format(index))
                stages_valid = False
            else:
                total += minutes
    if stages_valid and positive_number(duration) and not math.isclose(total, duration, abs_tol=0.001):
        errors.append('Stage total {} does not equal duration {}.'.format(total, duration))

    ids_valid = True
    for field in ('task_ids', 'answer_ids'):
        value = data.get(field)
        if not isinstance(value, list) or not all(nonempty(v) for v in value):
            errors.append('{} must be a list of non-empty strings; [] is allowed for no closed items.'.format(field))
            ids_valid = False
        elif len(value) != len(set(value)):
            errors.append('{} contains duplicates.'.format(field))
            ids_valid = False
    if ids_valid and set(data['task_ids']) != set(data['answer_ids']):
        errors.append('task_ids and answer_ids do not correspond.')

    files = data.get('files')
    contents = {}
    if not isinstance(files, dict):
        errors.append('files must be an object.')
    else:
        for role in sorted(REQUIRED_FILES - set(files)):
            errors.append('Missing file role: {}.'.format(role))
        root = path.parent.resolve()
        for role, value in files.items():
            if not nonempty(value):
                errors.append('File path for {} must be a non-empty string.'.format(role))
                continue
            relative = Path(value)
            candidate = (root / relative).resolve()
            if relative.is_absolute() or not candidate.is_relative_to(root):
                errors.append('File path escapes the unit folder: {}.'.format(role))
                continue
            try:
                text = candidate.read_text(encoding='utf-8')
                if not text.strip():
                    errors.append('File is empty: {}.'.format(role))
                contents[role] = text
            except (OSError, UnicodeError) as exc:
                errors.append('Cannot read file {}: {}.'.format(role, exc))
    if ids_valid:
        for field, role in (('task_ids', 'learner_handout'), ('answer_ids', 'answer_key')):
            if role in contents:
                for item in data[field]:
                    if not re.search(r'(?<![\w-])' + re.escape(item) + r'(?![\w-])', contents[role]):
                        errors.append('ID {} is not present in {}.'.format(item, role))

    review = data.get('human_review')
    publication = data.get('publication')
    review = review if isinstance(review, dict) else {}
    publication = publication if isinstance(publication, dict) else {}
    review_status = review.get('status')
    if not isinstance(review_status, str) or review_status not in {'not_reviewed', 'in_review', 'reviewed'}:
        errors.append('human_review.status must be not_reviewed, in_review, or reviewed.')
    if not isinstance(publication.get('approved'), bool):
        errors.append('publication.approved must be true or false.')
    requires_review = publication.get('approved') is True or (isinstance(status, str) and status in {'approved_for_publication', 'published'})
    if requires_review:
        if review.get('status') != 'reviewed' or not nonempty(review.get('reviewer')):
            errors.append('An approval claim needs a recorded human reviewer and reviewed status.')
        try:
            date.fromisoformat(review.get('date', ''))
        except (ValueError, TypeError):
            errors.append('An approval claim needs a valid ISO review date.')
    if isinstance(status, str) and status in {'approved_for_publication', 'published'} and publication.get('approved') is not True:
        errors.append('Approved/published status requires publication.approved true.')
    if data.get('status') == 'published':
        value = publication.get('url')
        try:
            parsed = urlsplit(value) if isinstance(value, str) else None
            valid_url = parsed and parsed.scheme in {'https', 'http'} and bool(parsed.netloc)
        except ValueError:
            valid_url = False
        if not valid_url:
            errors.append('Published status requires an absolute HTTP(S) URL; availability is not checked.')
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path, help='Path to a unit manifest.json')
    args = parser.parse_args()
    errors = validate_manifest(args.manifest)
    if errors:
        print('STRUCTURAL CHECK FAILED')
        for error in errors:
            print('- ' + error)
        return 1
    print('STRUCTURAL CHECK PASSED. No status was changed.')
    print('Not verified: pedagogy, language accuracy, rights, privacy, human approval authenticity, or publication.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
