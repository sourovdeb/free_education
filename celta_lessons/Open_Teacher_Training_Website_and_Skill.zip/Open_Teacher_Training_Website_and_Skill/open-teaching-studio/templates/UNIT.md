# Unit template
Replace the fields relevant to the task. Do not ship an unfilled template as a finished unit.

## Metadata
Unit ID / version / module:
Mode and audience:
Language-learner level and basis, when relevant:
Prior knowledge / group / context / equipment:
Time and whether live teaching is included:
Status / pilot status / source and rights review:

## Outcomes and evidence
Trainee outcome, for teacher training:
Classroom learner outcome, for language teaching:
Permitted support:
Local success criterion and what will be observed:

## Demonstration
Supply an actual text example or an existing accessible recording. Label simulations.
Show one plausible weak example and its improved version when useful.

## Why this approach
Chosen method, why it fits, limitation and fallback. Mark sourced claims versus design choices.

## Sequence
| Stage ID | Minutes | Purpose | Teacher action | Learner action | Evidence | Adaptation |
|---|---|---|---|---|---|---|

Total time must equal the sum. Specify live practice separately when not arranged.

## Complete materials
Deliver learner-facing prompts/text/cards in `learner-handout.md`.
Deliver answers/models/observation rubric in `answer-key.md`.
A resource is incomplete when learners must invent a missing text or find an unspecified video.

## Check and revision
A fresh attempt or transfer task:
What evidence to collect:
What to change if the task fails:
Later review opportunity:

## Website adaptation
Goal → demonstration → explanation → task → answer guidance → reflection → next step.
Use only real links or clearly labelled editorial notes in drafts. No public placeholder links.

## Final review
Record checks performed, unresolved issues, who has actually reviewed it, and next action. Use `draft` until a real release decision exists.
