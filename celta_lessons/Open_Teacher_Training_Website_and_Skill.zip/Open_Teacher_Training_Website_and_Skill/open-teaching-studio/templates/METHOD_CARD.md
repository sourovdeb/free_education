# [Method name]
Status: draft / reviewed / piloted — select truthfully.
Audience, prerequisite knowledge and suitable context:

## The problem it solves
One concrete teaching problem, not a universal promise.

## Use it when / choose something else when
Fit, constraints and an alternative.

## Procedure
State the actual sequence and required resources. Include sample teacher language.

## Worked example
Complete mini-example with learner response guidance.

## Weak implementation → repair
One realistic failure and a revision that addresses its cause.

## Check whether it helped
An observable behaviour, how it will be checked, and a plausible alternative explanation for success.

## Adaptations
One low-bandwidth/no-AI route and support suited to the audience.

## Evidence and limits
Inspected sources for material factual claims; design choices; untested predictions.

## Reuse metadata
ID, version, related training unit/material, rights status, reviewer and correction notes.
