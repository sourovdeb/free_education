# Create the section as WordPress draft pages
## What the file does
`open-teacher-training-drafts.xml` is a WordPress WXR 1.2 content import, not a plugin. It declares **24 ordinary Pages, all with status `draft`**, comments/pings closed and parent relationships. It includes no media downloads, user passwords, scripts, theme changes, menu changes, categories or existing post modifications.

Eight section pages + twelve module outlines + four pilot-unit pages = 24. The clear-instructions unit contains a full original text example; the other three pilot units contain explicitly marked outlines. This is a draft starting structure, not a completed course.

The official WordPress Importer supports importing content and author mapping. The exact screen wording may vary with the installed version. [S7]

## Before import
The official plugin directory displayed a compatibility-testing warning for recent major WordPress releases when checked. Verify compatibility with your actual installation and use staging; do not bypass the warning by installing unreviewed code. Manual native Page creation is the fallback. [S7]

Use a staging copy with a recoverable backup. Search Pages for “Open Teacher Training” and its intended slugs. Do not import over a same-named live section. Do not repeat the import to update pages: repeated imports can collide, skip items or create duplicates depending on the site's contents. Existing draft collisions need manual comparison.

## Import
1. Open WordPress administration on staging. Go to **Tools → Import → WordPress**. Install/run the official WordPress Importer when it is not already present; do not install unrelated import packages.
2. Select `open-teacher-training-drafts.xml`.
3. Assign the imported author to your existing WordPress account. Do not create a new author account for this kit. Leave attachment downloading off; no attachments are included.
4. Run the import once. Open **Pages → All Pages** and inspect the imported draft hierarchy.
5. Preview the root, Modules, Module 2 and its instructions unit. Check the parent chain and slugs. Do not publish the batch.

## After import
The pages use simple paragraph and heading blocks so the current theme supplies their appearance. They do not install a new visual theme. No YouTube embeds, forms, external fonts or public enrolment system are created.

Drafts intentionally have no public links to other unfinished pages. Add section navigation and previous/next links only to pages that you actually publish. No fake links or inert download buttons are supplied. Upload approved public resources separately and link their real locations.

The WXR creates content, not a menu. Add a Teacher Training menu item after the approved pilot route is published. Complete the three unit outlines before release. Confirm footer notices, real correction contact, licensing and reviewer information rather than inventing them.

## Rollback
Record the new page IDs immediately after import. To undo, move only those newly created Pages to Trash. Check IDs, title, parent and import batch marker before acting. Never bulk-delete all Pages or delete matching old content on a title guess. Restore the backup if a wider change occurred.

## Validation boundary
The XML was parsed and checked locally for item count, unique IDs, draft status, parent relationships and content type. A live WordPress import, site-specific slug handling, block rendering and theme compatibility have not been tested. Perform the staging checks above before relying on it.

## Manual alternative
Create the parent page and its children through Pages → Add New. Use the Parent setting to form the hierarchy shown in WEBSITE_SECTION_PLAN.md. Copy the text from the XML/page-copy files into normal blocks. This route needs no importer but requires more manual page creation. [S4]
