# Open Teacher Training

<!-- wp:heading -->
<h2 class="wp-block-heading">Learn. Teach. Improve.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A free, developing pathway for people learning to teach English to adults. Learn through examples, practical tasks, feedback and revision.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Two honest routes</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Open study: use public lessons and resources without a paid AI subscription.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Supported teaching practice: real teaching with human observation, available only when mentors and learner groups are confirmed. Self-study is not assessed teaching competence.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Start with one useful lesson</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The first pilot unit practises clear classroom instructions. It includes an original example, learner task, answer guidance and a revision activity. Add the public link here only after the reviewed unit is published.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Course status</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Twelve modules and a 200-hour total-learning pathway are proposed. The complete programme is not yet available. This draft structure contains one complete illustrative unit and three further pilot outlines.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Scope</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Draft blueprint: an independent programme, not affiliated with Cambridge or Oxford. It does not award CELTA. Proposed content and workload remain subject to review and piloting.</p>
<!-- /wp:paragraph -->
