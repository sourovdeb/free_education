# Prompt for the website-building agent
Copy this into the agent that has authorized access to the WordPress site. Attach the website kit. This prompt does not itself grant credentials or permission to publish.

```text
Build the Open Teacher Training section of sourovdeb.com using this kit.

Read WEBSITE_SECTION_PLAN.md, WORDPRESS_DRAFT_IMPORT_GUIDE.md and the existing course blueprint. The site already has /elt-masterclass/ and many teaching Posts. Preserve them.

1. Establish the scope of permission from this session: inspection, local files, WordPress drafts, or publication. Do not request permission again for already-authorized actions. Public release is a separate action unless explicitly covered.
2. Inspect the current WordPress version, actual editor/theme, existing Pages matching the proposed slugs, backup/staging route and available authenticated tools. Never put credentials in a prompt, generated content or report.
3. Use native Pages and the current theme. Prefer staging. Do not change global permalinks, homepage, existing URLs, credentials or theme files. Do not install an LMS or new paid service to solve a simple page-layout problem.
4. Compare existing pages before importing. The included XML supplies 24 DRAFT pages, not a finished course. It is not an idempotent database migration. Import once on staging, map the author to the existing owner, and check page statuses/parents/slugs afterward. Alternatively construct matching pages through the existing authorized interface.
5. Build one course layout and one unit layout with native blocks. Use independently editable unit bodies, not a globally synced lesson text. Shared navigation/disclaimers may be synced deliberately.
6. Create the complete M02-U01 prototype from the included example. The other three pilot units are outlines. Keep them unpublished until completed, checked and approved. Do not invent download, video, author-review or enrolment links.
7. Preserve all existing content. Identify a small set of reuse candidates, inspect their bodies and propose LINK / EXTEND / REBUILD / HOLD. Never infer body duplication from repeated titles alone.
8. On approved pilot pages, add working links only to published material. Provide text-first tasks, answer guidance and a printable learner route. Keep identifiable learner work out of public pages and downloads.
9. Verify preview, mobile layout, heading order, keyboard focus, download access, logged-out visibility, drafts, URLs and absence of accidental menu changes. Do not claim tests you did not run.
10. Return: actual page IDs and draft/preview URLs, what changed, checks performed, unresolved blockers, exact next action and rollback instructions. No fabricated deployed URL. Stop before publication when not authorized.

Use Hermes for design/review and n8n for deterministic execution only when an existing workflow is available and configured. Do not build automation before proving the first lesson works. If a needed connector is unavailable, report the precise unavailable operation and provide local draft files; do not claim the website was built.
```
