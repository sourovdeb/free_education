# Existing-material audit — start small
Status: initial candidates, not a complete website audit.

| Candidate | What was actually inspected | Possible use | What remains |
|---|---|---|---|
| `/elt-masterclass/` | Public index and availability labels | Earlier reading pathway, linked from About or further study | Individual article bodies and consistency with the new curriculum |
| Sample “5-Min Pro” lesson-planning post | Short explanation plus a one-minute aim/planning task | Optional pre-reading for Module 2 | Accuracy/editorial review; complete example, worksheet and evidence task |
| ELT365 items in the homepage index | Titles only | Candidates for modules 4–7 and short revision tasks | Open each body; check overlap, sources, language, rights and task quality |

Use this record for each next candidate:

Source URL and WordPress ID:
Actual body inspected and date:
Audience: English learner / trainee teacher / both (separate sections)
Proposed module and unit:
Accurate and useful elements:
Missing task, answer, example or feedback:
Rights/provenance:
Decision: LINK / EXTEND / REBUILD / HOLD
Reason and evidence:
Existing URL preserved:
Owner-approved next action:

A similar title does not prove duplicate content. A short reading is not defective because it is short; it simply serves a different purpose from a complete training unit.
