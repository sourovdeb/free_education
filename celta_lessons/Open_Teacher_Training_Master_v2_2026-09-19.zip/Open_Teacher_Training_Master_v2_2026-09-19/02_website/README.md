# Website section

Canonical section path:
`/open-teacher-training/`

Use Pages first.
Keep existing posts.
Keep existing URLs.

Core navigation:
`Start → Course → Methods → Materials → Practice`

Use draft pages first.
Pilot one unit first.
Keep publishing separate.
