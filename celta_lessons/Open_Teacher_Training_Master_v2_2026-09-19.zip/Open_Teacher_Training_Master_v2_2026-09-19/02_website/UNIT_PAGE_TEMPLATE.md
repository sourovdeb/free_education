# [Unit ID] — [Title]
Version: [version] · Status: draft · Module: [ID]
Audience: [trainee teacher / English learner]
Trainee prerequisites: [when relevant]
Example classroom: [age, provisional level, group, context]
Training time: [minutes] · Example classroom task: [minutes, separate]
Assumptions: [explicit; no invented learner diagnosis]

## Outcome and evidence
By the end, participants will be able to [observable action].
Evidence: [product/performance].
Success criteria: [what a reviewer can observe].
Evidence limitation: [simulation, self-study or real classroom observation].

## See an example
[Supply the actual original example, not a request to find one later.]

## Understand the decision
[Main method, why it fits, alternative and trade-off.]

## Inspect a weak example
[Original illustrative attempt, precise problem, improved version.]

## Do the task
[Inputs, directions, grouping, timing, participant product.]

## Teaching sequence
| Stage | Minutes | Teacher/trainer action | Learner/trainee action | Evidence/feedback |
|---|---:|---|---|---|

## Compare and improve
[Key or criteria, acceptable variations, model response, revision task.]

## Access and adaptation
[Text/print route; support; extension preserving the aim.]

## Keep the evidence
[What to keep privately; what it does and does not show.]

## Return later
[Small transfer/retrieval task; timing separate from core session.]

## Resources and provenance
[Actual files, sources, asset rights, version and unresolved checks.]

## Review record
[Checks really performed; named human reviewer only after actual review.]
