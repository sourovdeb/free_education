# A dedicated learning section for sourovdeb.com
## Decision
Build **Open Teacher Training** under `/open-teacher-training/` using the existing WordPress installation. Keep “Open Source CELTA 2.0” as an internal working title. Use “ELT365 — Open Teacher Training” as a proposed public identity, subject to the owner's decision.

Do not buy another domain, rebuild the entire site, or make a learning-management system a launch dependency. The first version is an organised public course with practical tasks and downloadable resources. This is a design recommendation, not a claim that WordPress alone supplies enrolment, secure submissions or assessment management.

## 1. What the existing site already gives you
The public site has teaching categories, ELT365 entries and a separate `/elt-masterclass/` index. That index describes a 60-day pathway, with later entries marked “Coming soon”. A sampled lesson-planning post is a short explanation and a practice prompt, rather than a complete assessed unit. [S1–S3]

**Consequence:** reuse selected material as readings, but add the missing course layer: a clear sequence, worked demonstrations, complete tasks, answer guidance, revision and evidence of teaching.

This is a limited public-content inspection, not a count or quality audit of every existing post. Repeated titles in the homepage index are candidates for review, not proof of duplicate bodies.

## 2. Information architecture
```text
sourovdeb.com
├── Existing writing, photography and language-learning content — keep
├── Existing /elt-masterclass/ — keep as an earlier reading pathway
└── /open-teacher-training/
    ├── start-here/          Who it is for; routes; readiness task
    ├── modules/             The ordered 12-module curriculum
    │   ├── 01-understand-learners/
    │   ├── 02-first-lesson/
    │   │   └── giving-clear-instructions/
    │   └── ... twelve modules in total
    ├── methods/             How to choose and adapt teaching methods
    ├── materials/           Classroom-ready packs and editable templates
    ├── practice/            Rehearsal, observation and supported practice
    ├── portfolio/           Evidence guide and self-study record
    └── about/               Scope, sources, corrections and contributors
```

Add one main-menu item: **Teacher Training**. Within the section, use a smaller navigation: **Start · Course · Methods · Materials · Practice**. Link Portfolio and About from relevant pages and the section footer. Keep the personal blog and learner-English pages distinct.

WordPress supports parent/child Pages and hierarchical page addresses. Pages are therefore the proposed course containers; existing Posts remain readings and announcements. The draft importer supplies this hierarchy. [S4]

## 3. What each part contains
| Part | Visitor's question | Required content |
|---|---|---|
| Hub | What is this, and where do I start? | Brief promise, pilot status, two routes, Start button, curriculum overview. |
| Start | Is this for me? | Teacher-training audience, sample task, language support, free-access scope, no paid-AI requirement. |
| Modules | What do I learn next? | Outcomes, prerequisites, ordered units, available/planned labels, evidence to keep. |
| Methods | Which approach fits this goal? | Purpose, conditions, procedure, example, limitations, alternatives and evidence status. |
| Materials | What can I use or adapt? | Learner sheet, teacher guide, answer key, assessment, editable source and version. |
| Practice | How do I improve my teaching? | Rehearsal protocol; observation guide; real-learner route only when human support exists. |
| Portfolio | What have I actually demonstrated? | Evidence map, reflection and revision log; distinguish self-study from observed performance. |
| About | Why should I trust this? | Independent status, authors/reviewers, source register, licence decision and correction route. |

The **Methods Library** teaches decision-making. The **Materials Library** supplies usable artefacts. Each material links to its method; each method links to an example pack. Neither replaces the ordered course.

## 4. The repeatable unit page
```text
Breadcrumb: Teacher Training > Module 2 > Unit 1
Title + outcome + estimated time + level/context + version

1. See a worked example (text always; video when produced)
2. Understand the teaching decision
3. Inspect a weak example and its correction
4. Do the practical task
5. Compare with answer guidance or performance criteria
6. Revise and try again
7. Download learner materials / teacher guide / editable source
8. Keep evidence and identify the next step

Sources · review status · corrections · previous / module / next
```

Keep the trainee-teacher instructions separate from what an English learner sees. A unit can teach a trainee to design an A2 task without claiming that the trainee's own English is A2. Keep teacher-training time and example classroom time separate.

## 5. WordPress implementation
**The minimal stack:** the current WordPress installation, its block editor where available, ordinary Pages, reusable design patterns, and your existing media/resources arrangements. No compulsory new recurring subscription is specified. Hosting, connectivity and any optional services are not thereby free.

**A. Preserve.** Back up the site and verify that a restoration route exists. Record the existing menu and relevant page IDs. Use staging where available. Do not change the global permalink settings, theme, homepage or existing post URLs for this project.

**B. Create drafts.** Use the supplied draft XML or create the eight section Pages manually. Create module Pages as children of Modules and unit Pages as children of their module. Keep unbuilt modules and incomplete units as drafts. Search for existing matching Pages before importing to avoid collisions.

**C. Create one layout.** In the block editor, build one course-page layout and one unit layout. Save the unit body as a **non-synced pattern** so editing one lesson does not edit every other lesson. A shared disclaimer or section-navigation block may be synced deliberately. WordPress distinguishes reusable/synced patterns from independently editable patterns. [S5–S6]

**D. Keep styling local.** Reuse existing typography and spacing where readable. Prefer a quiet single-column lesson body, restrained module cards and one obvious next action. Do not insert global CSS or edit theme files just to create the course. Check the actual editor and theme first; their identity was not verified in this review.

**E. Add navigation last.** After the pilot pages pass review, add Teacher Training to the main menu through the controls available in the site's actual theme. Do not assume that every theme uses the same menu screen. The supplied XML does not alter navigation.

**F. Publish selectively.** Publish the useful overview pages and only reviewed pilot units. Represent future modules as plain “Planned” labels rather than clickable dead ends. Check every public link logged out. The draft XML intentionally does not create links to unfinished units.

## 6. Reuse instead of mass duplication
For each candidate existing article, record its URL, actual contents, audience, possible module, missing material and proposed action. Use these decisions:

**LINK** when the article is a useful reading as it stands. **EXTEND** when it needs a worksheet, example or correction. **REBUILD** when the course needs a materially different teaching unit. **HOLD** when accuracy or rights remain unresolved.

Do not delete or redirect old posts as part of the pilot. Do not copy their full body into a second page merely to create another course URL. An old article can remain a reading while the new course page supplies practice and assessment. Any later merge/redirect needs a separate URL map and authorization.

Keep the existing ELT Masterclass available. After the new pilot is published, an approved banner there can direct readers to the newer practice-based pathway. Do not rename it silently or claim all its entries have been reviewed.

## 7. Public resources versus private learner work
Publish original worksheets, model answers, blank observation forms and anonymised fictional examples. Keep names, recordings, individual submissions and assessment discussions out of the public resource workflow.

Version 1 has **no submission portal**. Offer a downloadable portfolio checklist, not a fake dashboard or progress bar. Introduce authenticated storage, named access roles, consent arrangements, retention/deletion rules and a tested submission workflow before accepting identifiable learner work. Do not place private material in an openly downloadable folder.

Supported teaching practice is described as planned until mentors, adult learner groups and assessment capacity are genuinely available. Do not open unlimited enrolment based only on the existence of these pages.

## 8. Accessibility and practical access
Treat these as acceptance tests, not a pre-earned accessibility certificate: clear heading structure; useful link labels; keyboard navigation; visible focus; readable zoom; phone layout; meaningful alternatives to instructional visuals; reviewed captions and transcripts when media is published. W3C's structure and captions guidance informs these checks. [S8–S9]

Keep the full task usable without video, login, paid AI or colour printing. A large table may need a stacked version on a phone. Test the page without streaming and print the learner worksheet. Do not reuse an unrelated mandatory popup, timed writing test or wellbeing exercise as the course entry gate.

## 9. Production and automation
```text
Approved unit brief
      ↓
Hermes + teaching-materials-methods skill
      ↓
Master unit + classroom pack + source/check records
      ↓
Structural validation → educator/editor review
      ↓
Approved version
      ↓
n8n execution workflow, when configured
      ├── WordPress draft
      ├── YouTube script/captions package
      └── LinkedIn drafts
      ↓
Authorized release → receipt → corrections feed back to master
```

Hermes makes and explains decisions; n8n performs configured file/API steps. This kit is a blueprint for that integration, not an imported n8n workflow. No execution service is required to launch the first text lesson.

Keep one unit ID and version across channels. A future workflow should store WordPress page ID, content hash, review status and channel receipts. Upsert the known page ID rather than creating another post on every retry. Stop on uncertain responses before retrying a public action. Approval can cover a defined batch; a revised version needs renewed approval. Scripts do not award pedagogical approval.

## 10. Pilot release
The four pilot topics are: clear instructions (M02-U01), learner need to objective (M01-U01), checking meaning (M03-U01), and feedback leading to revision (M09-U01). This is a preview route across modules, not the complete sequential course.

**First acceptance milestone:** one visitor can find the hub, understand the scope, complete the full instructions unit, use its learner task, find the answer guidance and identify the next step without an explanation from you. The first unit may launch as text; publish a video link only after the video exists and is checked.

Full curriculum: 12 proposed modules and a planned 200-hour pathway from the booklet. Neither the current site nor this starter XML supplies a completed 200-hour programme. The next investment should be teaching review and a real pilot, not a certificate generator.

## 11. Definition of ready to launch
A ready pilot has a working route; accurate language and sources; no unresolved rights/privacy issue; functioning downloads; clear availability labels; no placeholder promises; a logged-out mobile/keyboard check; a real correction route; human editorial approval; and a rollback record. No claim of Cambridge/Oxford affiliation or superior outcomes appears.

Sources are identified in `../SOURCES.md`. All recommendations above are project design decisions unless expressly attributed.


---

# Source register and evidence boundary
Access/review date: 13 September 2026. URLs identify sources, not permissions to reproduce their contents. Recommendations in this kit are project design decisions unless attributed. No source supplies proof that this programme is superior to CELTA.

## Project inputs
**P1.** `Open_Source_CELTA_2_0_Blueprint_Editable.md`, version 0.2, supplied in this conversation. Used for the 12-module map, proposed 200-hour pathway, two routes and publishing architecture. The accompanying PDF was not re-analysed for this website task.
**P2.** Uploaded `rigorous-analysis.zip`, particularly its SKILL.md and templates. Used for source coverage, testable claims, competing explanations, bounded findings and correction records. This archive is an analysis framework, not the original CELTA course handouts.

## Public site — limited sample, not a full audit
**S1. Sourov Deb homepage.** `https://sourovdeb.com/` — inspected navigation, title index and listed teaching categories. Supports the existence of ELT365 and other teaching content; does not establish the quality or uniqueness of every article.
**S2. ELT Masterclass index.** `https://sourovdeb.com/elt-masterclass/` — inspected course description, sample early entries and later “Coming soon” labels. Supports preserving an existing course index rather than pretending the site has no course section.
**S3. Sample lesson-planning post.** `https://sourovdeb.com/5-min-pro-%C2%B7-how-to-plan-a-45-minute-lesson-from-scratch/` — inspected the short explanation and practice prompt. Treated as a candidate reading, not evidence that the entire archive has the same depth.

## Technical sources
**S4. WordPress, Create pages.** `https://wordpress.org/documentation/article/create-pages/` — supports Pages, parent/child hierarchy, draft settings and hierarchical addresses. Admin paths depend on the actual installed editor/theme.
**S5. WordPress, Block Patterns.** `https://wordpress.org/documentation/article/block-pattern/` — supports reusable block layouts and pattern editing.
**S6. WordPress, Synced Patterns (Reusable blocks).** `https://wordpress.org/documentation/article/reusable-blocks/` — supports the warning that deliberately synced content is shared across uses.
**S7. WordPress Importer, official directory and source.** `https://wordpress.org/plugins/wordpress-importer/` and `https://raw.githubusercontent.com/WordPress/wordpress-importer/master/src/class-wp-import.php` — supports WXR content import, author mapping and parent handling. The directory page displayed a warning about testing against recent major WordPress versions; that is not proof of an exploit or failure, but compatibility must be checked on staging. Source-code inspection is not a live import test. Do not install a development build merely to bypass a compatibility warning.
**S8. W3C WAI, Page Structure Tutorial.** `https://www.w3.org/WAI/tutorials/page-structure/` — informs semantic structure and navigation checks. This kit does not claim audited WCAG conformance.
**S9. W3C WAI, Captions/Subtitles.** `https://www.w3.org/WAI/media/av/captions/` — informs caption requirements and manual review of generated captions.
**S10. Hermes, Skills System.** `https://hermes-agent.nousresearch.com/docs/user-guide/features/skills` — supports default skill storage in `~/.hermes/skills/`, on-demand reference loading and slash-command access. Named profiles/custom HERMES_HOME locations must be checked in the actual installation.
**S11. Hermes, Creating Skills.** `https://hermes-agent.nousresearch.com/docs/developer-guide/creating-skills` — supports SKILL.md frontmatter plus references/templates/scripts organisation. This kit does not claim a tested installation in the user's runtime.

## Pedagogical source
**S12. British Council TeachingEnglish, Richard Frost, A task-based approach.** `https://www.teachingenglish.org.uk/professional-development/teachers/knowing-subject/task-based-approach` — inspected the article's descriptions of PPP and the task-based sequence. Professional guidance, not a controlled effectiveness comparison. Method-selection rules and original examples in this kit are design proposals; wider claims require further evidence.

## Deliberate gaps
No authenticated WordPress inspection; no full-site inventory; no private course-document audit; no formal qualification comparison; no independent educator review; no classroom trial; no live n8n/Hermes/WordPress integration. Generated page content, scripts and local checks must not be described as those activities.
