# Open Teacher Training

Master package v2
Date: 19 September 2026

## Start here
Use this order:

```text
01_blueprints
      ↓
02_website
      ↓
03_skills
      ↓
04_mistral_studio
      ↓
06_validation
```

## Canonical teaching skill
Use this file:
`03_skills/teaching-materials-methods/SKILL.md`

Older skill copies remain archived.
Do not maintain duplicates.

## Website build
Use this folder:
`02_website/`

Import drafts cautiously.
Test on staging first.

## Mistral setup
Use this folder:
`04_mistral_studio/`

Start without functions.
Add tools after testing.

## Governance
Use these files:
`00_governance/`

They define acceptance.
They do not deploy anything.

## Original outputs
Exact prior deliverables live here:
`05_original_deliverables/`

They preserve history.
