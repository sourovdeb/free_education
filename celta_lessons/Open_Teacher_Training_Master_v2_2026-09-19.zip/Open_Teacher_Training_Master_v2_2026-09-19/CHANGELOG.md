# Changelog

## Version 2.0
Date: 19 September 2026

Changes:
- merged project outputs
- kept original deliverables
- added skill governance
- created one canonical skill
- removed skill divergence
- added host adapter
- refreshed Mistral models
- retained website drafts
- retained blueprint PDFs
- added validation evidence
- added package hashes

No live systems changed.
No website was published.
