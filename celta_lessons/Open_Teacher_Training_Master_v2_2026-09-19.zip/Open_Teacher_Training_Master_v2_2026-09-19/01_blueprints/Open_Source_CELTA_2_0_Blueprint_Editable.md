# Open Source CELTA 2.0 — Editable blueprint

Version 0.2 · 13 September 2026

This is the editable text companion to the 20-page visual PDF. All proposed features and figures are design assumptions unless explicitly supported by a cited source.

<a id="p1"></a>

**Booklet page 1**

VISUAL BLUEPRINT / FOUNDER’S BOOKLET

# Open Source CELTA 2.0

An open teacher-training programme built around practice, feedback and visible evidence.

01 **Learn openly** *Clear explanations and demonstrations*

02 **Teach for real** *Supported lessons with adult learners*

03 **Improve visibly** *Feedback, revision and a teaching portfolio*

**12** proposed modules

**200** planned learning hours

**3** publishing channels

Free access to learning.  
Honest evidence of teaching ability.

Prepared for Mishu · 13 September 2026  
Based on the conversation blueprint and the attached *rigorous-analysis* framework.

Working title only. This independent project is not affiliated with Cambridge or Oxford, does not award CELTA, and has not established equivalence or superior outcomes. All proposed hours and features remain subject to piloting.

<a id="p2"></a>

**Booklet page 2**

01 / THE WHOLE SYSTEM

# The programme on one page

Build one connected learning pathway, not three separate content businesses.

DISCOVER

### LinkedIn

A problem, an example and a practice challenge.

SEE

### YouTube

Annotated demonstrations of teaching decisions.

DO

### Your website

The complete course, tasks and editable resources.

ALL THREE LEAD TO THE SAME COURSE

Start  
 readiness check

→

Learn  
 12 modules

→

Practise  
 real lessons

→

Revise  
 feedback

### Open learning route

Anyone can study the public materials. Self-study completion is not an assessed teaching qualification.

### Supported practice route

Places depend on mentors and learners. Human-reviewed teaching leads to a documented portfolio.

Evidence → review → correction → a better next version

## Find your way through the booklet

[**03–05** Evidence, access and learning method](#p3)
 [**06–08** The 12-module curriculum](#p6)
 [**09–11** Workload, assessment and prototype](#p9)
 [**12–13** Website and publishing system](#p12)
 [**14–17** Pilot, people, launch and governance](#p14)
 [**18–20** Working tools and source register](#p18)

<a id="p3"></a>

**Booklet page 3**

02 / EVIDENCE BEFORE AMBITION

# Keep the ambition. Test the claims.

The attachment supplies the analysis method; it is not a collection of CELTA teaching materials.

VERIFIED inspected external benchmark   PROPOSED design decision   TO TEST unproven outcome

**Actually reviewed:** the attachment’s SKILL.md, COMPACT\_PROMPT.md and TEMPLATES.md in full; the previous blueprint; and the official sources listed on page 20. Your original tutor handouts, lesson records and assessment evidence were not supplied in this archive. [[R1]](#sources)

## A fair starting benchmark

Cambridge specifies at least 120 tutor-contact hours plus 80 additional learning hours. Its published course includes six hours of assessed teaching, six hours of directed observation, and online or blended options. Its course page also links to AI guidance. [[R2]](#sources)

| Claim to examine | Finding now | Design consequence |
| --- | --- | --- |
| “CELTA is only 120 hours.” | **OVERSTATED**  High confidence; published workload is wider. [[R2]](#sources) | Compare like-for-like activity and support, not headline hours. |
| “It is entirely pre-internet.” | **CONTRADICTED as stated**  High confidence about published coverage. [[R2]](#sources) [[R3, pp. 4–5]](#sources) | Improve delivery and access without pretending digital coverage is absent. |
| “Its value is only the logo.” | **UNPROVEN**  No evaluation isolates the contribution of branding. | Test teaching, feedback and credibility separately. |
| “This course will be better.” | **UNPROVEN**  No pilot or comparison has occurred. | Specify measurable improvements and publish limitations. |

**Strongest alternative explanation:** Training quality may depend on mentoring, implementation and assessment—not simply on whether a course is paid or institution-branded. Test the new programme on its own evidence.

This is programme design, not an audit of your individual CELTA result. Missing records make that separate question not assessable here.

<a id="p4"></a>

**Booklet page 4**

03 / ACCESS AND LEARNER JOURNEYS

# Two routes. No misleading promise.

Start with adults learning to teach English to adults. Add specialist branches after the core works.

**ONE OPEN START**   
Explain a simple language point · adapt a short text · try a mini-lesson  
 Use the results to identify support needs, not to invent a CEFR score.

↙ Choose the appropriate route ↘

ROUTE A

## Study freely

Public lessons, captions, transcripts, audio, examples, templates and self-checks.

**Entry:** no paid course or AI subscription required. Offer a language-development bridge where needed.

**Output:** a self-study record and draft materials.

**Limit:** quizzes, AI role-play and peer rehearsal do not establish competence with real learners.

ROUTE B

## Teach with support

Real adult learners, a named mentor, observed lessons, feedback and reassessment.

**Entry:** a human-reviewed readiness task, suitable language accuracy, reliable participation and agreed privacy arrangements.

**Output:** a reviewed portfolio stating exactly what was observed.

**Limit:** free places cannot exceed funded or volunteered mentoring capacity.

Both routes can return to the same learning materials at any point.

## The access promise

Keep the core materials free to access. Provide a text-and-print route and a no-AI route. State unavoidable device, connection and printing costs rather than describing participation as costless.

A course completion record must name the issuing project, scope, dates and assessment status. It must not imply Cambridge accreditation, job eligibility or guaranteed employment.

<a id="p5"></a>

**Booklet page 5**

04 / THE LEARNING METHOD

# A loop, not a video playlist

Every unit ends with an observable action and a chance to improve it.

1

### See

Watch an authentic or clearly labelled simulated example.

2

### Explain

Identify the learner goal and the teacher’s decision.

3

### Build

Create a small plan, task or explanation.

4

### Rehearse

Try it with a peer or optional AI role-play.

5

### Teach

Use it with real learners on the supported route.

6

### Observe

Record what learners actually did or produced.

7

### Review

Receive a specific evidence-based next step.

8

### Revise

Change one decision, then try again.

↶ RETURN TO THE NEXT ATTEMPT, NOT TO THE BEGINNING OF THE WHOLE COURSE

### Weak feedback

“Your instructions need work.”

No evidence, no practical change, no way to know whether the next attempt improved.

### Useful feedback

“Two pairs started different tasks. Model one exchange before they begin; then ask a learner to show the first step.”

This is an invented example, not a recorded pilot finding.

**Revisit earlier skills.** Later modules should reuse instruction-giving, language analysis and checking learning. Treat the benefit of this particular course design as a hypothesis to evaluate, not an established result.

“Understand” is not enough as an assessment verb. Ask what the trainee will plan, explain, teach, notice or revise.

<a id="p6"></a>

**Booklet page 6**

05 / CURRICULUM · PART 1

# From learner needs to language

Modules 1–4: build a useful lesson before accumulating a large theory notebook.

01

## Understand the learner

Can identify a real, teachable learning goal.

**Explore** Needs, context, language samples, motivation and realistic progress.

**Practise** Interview an adult volunteer; distinguish their wish from evidence of what they can currently do.

**Keep as evidence** An anonymised learner profile and one achievable lesson objective.

**Quality check** Does the proposed lesson actually respond to this learner’s evidence?

02

## Plan and teach a first lesson

Can organise a short, purposeful learning sequence.

**Explore** Outcomes, staging, timing, grouping, instructions and demonstrations.

**Practise** Build a 30-minute lesson, rehearse one transition, then teach with support.

**Keep as evidence** A one-page plan, observation notes and a revised plan.

**Quality check** Do learners know what to do, and is there evidence of the intended learning?

03

## Teach grammar and functions

Can explain and practise language accurately in context.

**Explore** Meaning, form, pronunciation and use; choosing approaches for different aims.

**Practise** Compare two explanations; correct an oversimplified rule; design practice.

**Keep as evidence** A language-analysis sheet and a short teaching sequence.

**Quality check** Are the explanation, examples and checking questions accurate and appropriate?

04

## Teach vocabulary and expressions

Can help learners use words and phrases purposefully.

**Explore** Words, chunks, collocations, context, useful examples and revisiting language.

**Practise** Choose a small set for a real situation; build an activity and later return task.

**Keep as evidence** A vocabulary lesson and a follow-up practice activity.

**Quality check** Can learners use the language outside the original model sentence?

Practice thread: four supported 30-minute lessons across this block, after readiness screening.

<a id="p7"></a>

**Booklet page 7**

05 / CURRICULUM · PART 2

# From language to communication

Modules 5–8: teach people to understand, express themselves and participate.

05

## Teach pronunciation for communication

Can help learners communicate intelligibly.

**Explore** Sounds, word and sentence stress, connected speech and accent variation.

**Practise** Annotate a short dialogue; demonstrate how stress changes an intended message.

**Keep as evidence** An audio model, transcript and pronunciation activity.

**Quality check** Is the goal clearer communication rather than imitation of one prestige accent?

06

## Teach reading and listening

Can design tasks that develop comprehension.

**Explore** Purpose, text choice, likely barriers and progression from support to independence.

**Practise** Teach with an original or permitted text; add an audio or print alternative.

**Keep as evidence** A skills lesson, answer explanations and a task revision.

**Quality check** Does the lesson teach a useful process, rather than only reveal right answers?

07

## Teach speaking and writing

Can design a reason to communicate and improve.

**Explore** Information gaps, interaction, models, planning, drafting and revision.

**Practise** Run a speaking task; give feedback on a short text; support a second attempt.

**Keep as evidence** A speaking sequence and anonymised before-and-after writing.

**Quality check** Does the second attempt show a meaningful change linked to the task?

08

## Run an inclusive classroom

Can adapt participation without abandoning the learning goal.

**Explore** Mixed levels, multilingual resources, access needs and classroom organisation.

**Practise** Adapt one task for limited connectivity and for learners needing more support.

**Keep as evidence** Two adaptations and a brief explanation of the choices.

**Quality check** Who can participate, who is excluded, and how will you know?

Practice thread: eight supported 45-minute lessons across this block; vary aims and learner groups.

<a id="p8"></a>

**Booklet page 8**

05 / CURRICULUM · PART 3

# From teaching to professional judgement

Modules 9–12: judge evidence, use tools carefully and demonstrate independent decisions.

09

## Assess learning and give feedback

Can use learner evidence to change the next lesson.

**Explore** Starting points, useful checks, errors, feedback and progress over time.

**Practise** Create a short assessment; compare two feedback options; revise a plan.

**Keep as evidence** Assessment tasks, sample feedback and a justified next step.

**Quality check** Does the evidence support the conclusion, or could another explanation fit?

10

## Teach online and with low bandwidth

Can preserve the learning goal across delivery formats.

**Explore** Online interaction, phone-readable resources, transcripts and offline alternatives.

**Practise** Convert one lesson into browser, audio-and-text and printable versions.

**Keep as evidence** A small multi-format lesson pack and an access test log.

**Quality check** Can someone complete the essential task without streaming a video?

11

## Use AI without surrendering judgement

Can inspect, correct or reject generated teaching material.

**Explore** Accuracy, level suitability, source checking, privacy and bias.

**Practise** Audit a generated resource; correct it; explain the checks; make a non-AI version.

**Keep as evidence** Original output, corrections, verified sources and a disclosure note.

**Quality check** Can the trainee defend the final choices without relying on the model’s confidence?

12

## Teach, reflect and demonstrate

Can plan a short course and explain professional decisions.

**Explore** Course coherence, evidence, collaboration, review and honest portfolio claims.

**Practise** Build a three-lesson sequence; teach the final observed lessons; defend revisions.

**Keep as evidence** A reviewed portfolio and a small classroom-investigation report.

**Quality check** Is competence demonstrated repeatedly, not inferred from attendance?

Practice thread: four supported 60-minute lessons, including final evidence across two learner levels.

<a id="p9"></a>

**Booklet page 9**

06 / TIME AND PRACTICE

# 200 hours: an activity budget

A planning estimate for the supported route—not a tutor-contact claim or a validated optimum.

**Study and demonstrations** 40 h

**Directed observation** 20 h

**Planning and materials** 60 h

**Teaching real learners** 12 h

**Feedback, revision and clinics** 40 h

**Portfolio and assessment** 28 h

**200** planned learner hours 

---

 **Flexible pace**

For example, 20 weeks at 10 hours per week, or 40 weeks at five.

Arithmetic examples, not completion guarantees. Pause and retry when needed.

## The 12-hour teaching pathway

MODULES 1–4

### 4 × 30 min

Short, heavily supported lessons.

**2 hours**

MODULES 5–8

### 8 × 45 min

Varied aims with decreasing support.

**6 hours**

MODULES 9–12

### 4 × 60 min

Independent planning and final evidence.

**4 hours**

**16 observed sessions in total.** Schedule experience across at least two learner levels. Teaching time means the trainee is actively teaching real learners with an identified human observer; AI simulations and peer rehearsals do not count.

**Avoid double-counting.** Log each activity once. The 12 teaching hours are already inside the 200-hour total. Observation means watching others teach; feedback and portfolio preparation have separate budgets.

Keep actual time logs. Reading difficulty, preparation demands, retries and mentor availability may increase the total. The open-learning route carries no automatic 200-hour completion claim.

<a id="p10"></a>

**Booklet page 10**

07 / ASSESSMENT

# Show what the teacher can do

Proposed pilot standards. An experienced teacher educator must calibrate the rubric before it is used for consequential decisions.

| Criterion | Evidence to inspect | What “demonstrated” looks like |
| --- | --- | --- |
| **1. Learner fit** | Needs record, plan and lesson choices. | Aims and support respond to this group’s needs. |
| **2. Language accuracy** | Explanation, models and responses to questions. | Language is accurate; uncertainty is checked, not concealed. |
| **3. Lesson design** | Stages, tasks, timing and changes during teaching. | Activities serve the aim and form a coherent sequence. |
| **4. Participation** | Observed instructions, interaction and access. | Learners can begin, participate and get suitable support. |
| **5. Evidence of learning** | Learner responses, work and feedback. | The teacher checks learning and responds to the results. |
| **6. Professional judgement** | Reflection, revisions, sources and privacy practice. | Decisions are justified, ethical and improved using evidence. |

**Not yet** Evidence absent or a significant problem remains.

**Developing** Some success, but inconsistent or heavily supported.

**Demonstrated** Appropriate independent performance with clear evidence.

## A transparent completion decision

Proposed rule: all six criteria must be demonstrated on at least two observed occasions, with the final evidence spanning two learner levels. A high average must not conceal a serious unresolved accuracy or learner-protection problem.

The portfolio includes lesson plans, language analysis, observation records, learner work where permitted, revisions and a short oral explanation. A second educator reviews final samples and borderline decisions.

**When evidence is insufficient:** identify the precise criterion, offer targeted practice and publish a reassessment route. A reviewer not responsible for the original decision handles a disputed outcome.

No competence award from quiz scores, AI ratings or attendance alone. Do not claim assessment reliability until it has actually been examined.

<a id="p11"></a>

**Booklet page 11**

08 / ONE COMPLETE PROTOTYPE

# “Help me understand you”

An original sample unit: teach adult learners to request repetition or spelling.

**LEARNERS** Example A2 adult group

**LESSON** 30 minutes

**OUTCOME** Use clarification language in three short exchanges

**Target language:** “Could you say that again?” and “How do you spell …?” Use fictional names and information, not learners’ private details.

| Time | Teacher and learner activity | Evidence to notice |
| --- | --- | --- |
| 0–3 | Create a situation where a listener misses a name. | How do learners currently respond? |
| 3–8 | Model a short exchange; establish meaning and purpose. | Can learners identify when each request is useful? |
| 8–13 | Clarify form and model clear, polite pronunciation. | Are the requests understandable? |
| 13–17 | Demonstrate the pair task and check the first step. | Can learners begin without repeated rescue? |
| 17–26 | Use information-gap cards; switch partners or roles. | Who uses a request independently? |
| 26–30 | Give focused feedback and try a new short exchange. | What changed from the opening attempt? |

### Before revision

“Work together and practise everything on the page.”

The task, roles and expected result are unclear.

### After revision

“A, say one name. B, ask for repetition or spelling. Write the answer. Then swap. Watch our example first.”

**What the trainee submits:** the plan, one instruction script, observation notes and a revision explaining what learner evidence prompted the change.

This is a designed example, not a tested lesson or a claim that all A2 learners need the same support. The mentor adapts text, pace and support to the actual group.

<a id="p12"></a>

**Booklet page 12**

09 / THE WEBSITE

# One clear home for the course

A proposed wireframe for your website—not a screenshot, live build or deployed service.

Proposed section: /open-teacher-training/

**OPEN TEACHER TRAINING** Start · Modules · Resources · About

START WITH ONE USEFUL LESSON

## Learn. Teach. Improve.

A free learning library with a separate supported practice route.

Start here

See the curriculum

**1. Understand learners**

Profile + learning goal

**2. Plan a first lesson**

Plan + rehearsal

**3. Explain language**

Analysis + teaching task

Text · Video with captions · Audio · Printable pack

## Every lesson page follows the same order

Goal → Demonstration → Explanation → Task   
 Example answer → Self-check → Next lesson

### Public by design

Lessons, original templates, source notes, version history, correction form and course scope.

### Private by default

Participant details, submitted work, assessment discussions and identifiable classroom records.

**First release:** use a small set of public pages and downloadable resources. Do not delay a pilot to build a custom learning platform, AI dashboard or certificate engine.

Test navigation on a phone and with keyboard-only use. Publish captions and transcripts, readable contrast and a low-bandwidth alternative. These are design requirements to verify, not accessibility claims already achieved.

<a id="p13"></a>

**Booklet page 13**

10 / PUBLISHING

# One lesson becomes a small campaign

Produce one reviewed master lesson. Adapt it for each channel instead of inventing unrelated daily content.

**MASTER LESSON**   
Outcome + script + demonstration + task + answer guidance + sources

↙ One source of truth; one version number ↘

WEBSITE

### 1 complete lesson

Full text, editable template, task and next step.

YOUTUBE

### 1 demonstration

A proposed 6–10-minute focused video, captions and transcript.

LINKEDIN

### 3 posts

A problem, a worked example and a practice invitation.

## A proposed four-week launch series

| Week | One learning unit | Example LinkedIn angle |
| --- | --- | --- |
| 1 | Give instructions people can follow. | “Did they understand the words—or know what to do?” |
| 2 | Turn a learner need into a lesson goal. | A broad wish versus an observable outcome. |
| 3 | Check understanding without guessing. | Replace “Do you understand?” with a useful task. |
| 4 | Give feedback that changes the next attempt. | Show one before-and-after revision. |

**Editorial rhythm:** Monday problem; Wednesday demonstration and full lesson; Friday challenge. This is a workflow proposal, not an algorithm or reach guarantee.

**Release gate:** verify language, inspect the activity, confirm rights, test downloads, check captions, remove private information and obtain human approval. Correct all channel versions when the master changes.

AI may assist with drafting, caption cleanup and repurposing. Do not use it to invent learner testimonials, classroom results or research support. No posts or pages have been published by creating this booklet.

<a id="p14"></a>

**Booklet page 14**

11 / PILOT AND EVALUATION

# Define “better” before measuring it

Run a small feasibility pilot first. Do not call it proof of superiority to CELTA.

**6** proposed trainees

**4** weeks of learning units

**2** observed 30-minute samples each

Baseline  
 before instruction

→

4 units  
 practice + support

→

New task  
 after instruction

This pilot tests a small part of the pathway, not the full 200 hours. It provides one observed teaching hour per trainee. Use comparable tasks and learner levels; secure consent and supervision before either sample.

| Question | Collect | Important limitation |
| --- | --- | --- |
| Can people access it? | Phone and print task completion; access barriers; actual learner costs. | A participant with good access does not represent everyone. |
| Does teaching improve? | Before-and-after rubric records, learner work and revisions. | Prior skill, motivation and mentor input may explain changes. |
| Is feedback useful? | Whether the trainee can act on it in the next attempt. | Satisfaction alone is not evidence of learning. |
| Is it sustainable? | Actual mentor time, preparation, withdrawals and completion. | Volunteer effort is a resource cost, even without payment. |

**Reduce avoidable bias:** ask a second educator to review samples; conceal sample order where practical; record disagreements. Report the number enrolled, the number completing and missing evidence—not only successes.

**PROCEED** Evidence is usable and delivery is manageable.

**REVISE** Instruction, access or workload repeatedly fails.

**PAUSE** No mentor, unsafe practice or unresolved privacy issue.

Agree decision criteria before recruitment. A credible comparative claim needs a stronger design with an appropriate comparison group and relevant outcomes. None has been conducted.

<a id="p15"></a>

**Booklet page 15**

12 / PEOPLE AND CAPACITY

# The scarce resource is feedback

A free-to-learner course still needs time, expertise and a realistic funding or volunteer plan.

### Founder / editor

Sets scope, creates original materials, coordinates production and maintains the correction log.

### Teacher educator / mentor

Checks pedagogy, supervises practice and gives evidence-based feedback.

### Independent reviewer

Reviews final samples, calibrates standards and handles disputed decisions.

### Practice partner

Helps organise appropriate adult learner groups and consented learning activities.

## Example capacity budget: six full-route trainees

| Human work | Explicit assumption | Hours |
| --- | --- | --- |
| Primary observation | 6 trainees × 12 teaching hours | **72** |
| Individual feedback | 6 × 16 sessions × 30 minutes | **48** |
| Portfolio review | 6 × 1 hour | **6** |
| Second-reviewer sampling | 6 × two 1-hour lesson samples | **12** |
| Illustrative combined staff-time subtotal | | **138** |

**Not a full operating budget.** This excludes course writing, recruitment, group clinics, administration, extra reassessments and technical support. It also assumes one hour is enough for each portfolio review; the pilot may disprove that assumption.

Cash budget = paid staff hours × agreed rates  
+ hosting, access support and other actual costs

Secure mentor commitments before opening supported places. Seek partner institutions, grants or donations without promising they will materialise. Keep the open library available even when a cohort is full.

The small four-week pilot has a separate staffing plan; it does not require the full-route 138-hour estimate. Founder workload and publication frequency must fit available capacity.

<a id="p16"></a>

**Booklet page 16**

13 / THE BUILD SEQUENCE

# Build → test → expand

Use completion gates, not a calendar promise. The four-week pilot starts only after preparation is ready.

1

SOURCE AND STANDARDS

### Audit the material you actually have.

**Owner:** founder + educator. Inventory permitted resources; map outcomes; draft the rubric and scope.

**Gate:** every prototype outcome has an activity, evidence requirement and source or design rationale.

2

ONE COMPLETE PROTOTYPE

### Finish one usable learning unit.

**Owner:** founder + reviewer. Build the lesson page, video, transcript, printable pack and assessment task.

**Gate:** a new user can follow it; the educator approves it; the downloads and privacy workflow work.

3

FOUR-WEEK PILOT

### Run four units with a small cohort.

**Owner:** mentor + founder. Collect baseline and final samples, time logs, barriers and revisions.

**Gate:** review evidence, withdrawals, costs and reviewer disagreement; decide proceed, revise or pause.

4

VERSION 1.0

### Expand only what survives testing.

**Owner:** editorial and review team. Revise the format, then build the remaining curriculum.

**Gate:** assessment and mentoring can scale without diluting the advertised support.

Small first release: 4 learning units · 4 videos · 12 LinkedIn posts

**Not first:** hundreds of lessons, custom automation, a badge marketplace, multiple age-group branches or a claim to replace an established qualification.

Immediate deliverable: approve the first prototype’s learner, outcome, mentor and evidence task. A publishing schedule comes after those decisions, not before them.

<a id="p17"></a>

**Booklet page 17**

14 / OPENNESS AND GOVERNANCE

# Open materials. Protected people.

Use an independent public identity. Keep the working title inside the development process until naming is resolved.

### Open layer

Original lessons, editable source files, assessment descriptors, sample answers, sources and correction history.

**Proposed licence:** CC BY-SA 4.0 for original materials the project has rights to license. It allows sharing and adaptation, including commercial reuse, with attribution and ShareAlike conditions. [[R5]](#sources)

### Protected layer

Identifiable learner records, private feedback, contact details and recordings without publication permission.

Do not apply an open-content licence to private submissions or third-party work merely because it appears in the course. [[R5]](#sources)

## Publication decisions

**Name:** a candidate public identity is *Open Teacher Training* or *ELT365 — Open Teacher Training*, subject to name checks. Do not use Cambridge or Oxford logos or imply endorsement.

**Resources:** write original explanations. Link to useful external materials and check permissions before reproducing them. British Council TeachingEnglish already offers free teacher-development resources; this project should add coherent practice and feedback rather than claim to invent free training. [[R4]](#sources)

**Quality:** publish who reviewed a unit, the version reviewed, unresolved limitations and a correction route. Describe review as completed only after it happens.

**Privacy:** minimise data, agree retention and access, separate assessment consent from permission to publish, and offer observation without public recording. Use anonymised examples in AI tools.

**The operating rule:** Draft → human review → permission check → publish → collect evidence → revise. No model can approve its own assessment or waive a learner’s privacy choices.

The licence is a recommendation for a future publishing decision, not a claim that all sources in this booklet are openly licensed. Name and rights questions require checking before launch.

<a id="p18"></a>

**Booklet page 18**

15 / THE ATTACHMENT AS A WORKING TOOL

# One claim. One test. One decision.

Adapted from the uploaded evidence register, findings register and action register. [[R1]](#sources)

WORKED CLAIM CARD / H01

## “This unit improves instruction-giving.”

**Type** Causal claim about a specific unit and participant group.

**Supporting evidence** None from this course yet. A plausible lesson design is not an outcome result.

**Alternative** Change might come from mentoring, repeated practice, prior skill or a more cooperative class.

**Test** Compare observed attempts on similar tasks; inspect learner starts, teacher rescue and an independent review.

**Finding now**  **UNPROVEN.** High confidence that no pilot evidence has been supplied; effect size and direction remain unknown.

**Action** Pilot the unit; make no improvement claim until the evidence is reviewed.

## Copy this compact review card

**Claim and scope:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Inspected source or observation:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Strongest counterevidence / alternative:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Finding + confidence + reason:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**What would change the finding?** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Next action / owner / stop condition:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Use the attachment’s labels:** supported; contradicted; mixed or overstated; unproven; not assessable. Do not mistake “unproven” for “false”, or multiple AI answers for independent corroboration.

An anonymised classroom observation supports a narrow claim about that event. It does not automatically prove that the whole programme works better for everyone.

<a id="p19"></a>

**Booklet page 19**

16 / FOUNDER’S DECISION SHEET

# What must be decided next?

Complete this page before expanding the course. Blank fields mean unresolved decisions, not completed work.

**Public project name:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**First learner group and context:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**First unit and observable outcome:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Named educator / mentor:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Independent reviewer:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

**Available time and funding:** \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## The launch gate

□ Original or permitted source material is recorded.

□ The prototype, answer guidance and rubric have been reviewed.

□ Adult learner groups and a mentor are available.

□ Privacy, recording choices and access arrangements are agreed.

□ The website lesson, captions, transcript and print pack work.

□ Baseline, final task and pilot decision criteria are documented.

□ Staff time and free-place limits are explicit.

## Keep a correction log

| Earlier idea | More accurate position in this booklet |
| --- | --- |
| New technology makes a course better. | Access, pedagogy, feedback and outcomes must each be tested. |
| Make supported practice freely unlimited. | Publish materials freely; cap practice places to actual mentor capacity. |
| The uploaded archive contains course evidence. | It contains an analysis protocol; original course documents still need a separate audit. |

**Next source audit:** keep originals unchanged. For each document record title, page, rights, learning outcome, assessment link and the decision: retain, explain better, redesign, extend or replace.

Status: blueprint created. Course delivery, external review, piloting and publication remain to be done.

<a id="p20"></a>

**Booklet page 20**

<a id="sources"></a>

17 / SOURCES AND STATUS

# What this blueprint rests on

Source notes, inspection boundaries and the status of the recommendations.

**R1 · User attachment: rigorous-analysis.zip**

Read in full: `rigorous-analysis/SKILL.md` , `COMPACT_PROMPT.md` and `TEMPLATES.md` . Used for evidence classification, competing explanations, claim confidence, action gates and correction logs. The agent YAML and icon were listed, not used as substantive sources.

Relevant sections: evidence register; testable claims; competing explanations; findings; proportionate actions; final adversarial check. Archive SHA-256 begins: `32c68a31b871da02` . The hash identifies this copy; it does not authenticate authorship.

**R2 · Cambridge English — [What’s in the CELTA course?](https://www.cambridgeenglish.org/educators-organisations/professional-development/teaching-qualifications/celta/about/)** 

Read the official course-format, detailed-workload and assessment sections. Supports the current benchmark on page 3. The page links to AI guidance; this booklet does not evaluate that guidance.

**R3 · Cambridge English — [CELTA syllabus and assessment guidelines, July 2024](https://www.cambridgeenglish.org/Images/21816-celta-syllabus.pdf)** 

Selected review, including visual inspection of printed pages 2–5: overview, assessment framework, course programme and syllabus outline. It includes online contexts and technology-based resources. This is not a full criterion-by-criterion curriculum audit.

**R4 · British Council — [Professional development for teachers](https://www.teachingenglish.org.uk/professional-development/teachers)** 

Reviewed the overview and resource categories. Supports the existence of free teacher-development resources, not the effectiveness of this proposed programme.

**R5 · Creative Commons — [CC BY-SA 4.0 deed](https://creativecommons.org/licenses/by-sa/4.0/deed.en)** 

Reviewed permissions and conditions. Supports the proposed open-content licence summary. Other rights and permissions still require checking.

**R6 · Previous conversation blueprint 0.1**

Used as a design draft, not independent evidence. The earlier referenced ELT365 file was not reopened or inspected for this booklet, so no file-specific claims rely on it.

**Version 0.2 · 13 September 2026**

External sources checked on this date. All hours, staffing assumptions, assessment rules and publishing plans are proposals. No superiority study, accreditation, external peer review or live deployment has occurred.

Reading order is sequential. For a folded A5 booklet, use your PDF printer’s booklet setting on A4 paper and check duplex orientation in preview. The PDF has 20 pages, a multiple of four. Use ordinary full-page printing for larger text.

## Archive integrity note

SHA-256 of the inspected `rigorous-analysis.zip` copy:

`32c68a31b871da02b1c36998e9a86e955b9950607e3410c52d5565a794b944f2`

A hash identifies this local copy and does not authenticate its author or historical origin.
