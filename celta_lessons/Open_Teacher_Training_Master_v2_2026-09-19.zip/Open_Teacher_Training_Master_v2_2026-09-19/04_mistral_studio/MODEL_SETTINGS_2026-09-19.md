# Mistral model settings

Checked: 19 September 2026

## Drafting default
Model: `mistral-small-2603`
Alias: `mistral-small-latest`
Role: unit drafting
Reasoning: test defaults first
Temperature: start near `0.4`

## Review default
Model: `mistral-large-2512`
Role: separate review
Temperature: start near `0.2`

## Escalation option
Model: `mistral-medium-3-5`
Role: difficult review cases
Use only when needed.

## Small-model option
Model: `ministral-3b-latest`
Role: staged drafting tests
Use strict scaffolding.

## Current status notes
Mistral Small 4 remains current.
Medium 3.5 remains current.
Large 3 remains listed.
Magistral Small 2509 is deprecated.

## Pricing snapshot
Prices may change.
Check Mistral before spending.

Small 4:
- input: $0.15/M
- output: $0.60/M

Large 3:
- input: $0.50/M
- output: $1.50/M

Medium 3.5:
- input: $1.50/M
- output: $7.50/M

## Timing note
Temperature is not latency.
`0.8` has no seconds.

Sub-second completion varies.
Never promise it blindly.

## Sources
- https://docs.mistral.ai/models
- https://docs.mistral.ai/models/mistral-small-4-0-26-03
- https://docs.mistral.ai/models/mistral-medium-3-5-26-04
- https://docs.mistral.ai/inference/pricing
