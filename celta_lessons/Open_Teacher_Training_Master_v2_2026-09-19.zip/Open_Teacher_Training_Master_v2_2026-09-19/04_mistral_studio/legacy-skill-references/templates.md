# [Unit ID] — [Title]
Version: [version] · Status: draft · Module: [ID]
Audience: [trainee teacher / English learner]
Trainee prerequisites: [when relevant]
Example classroom: [age, provisional level, group, context]
Training time: [minutes] · Example classroom task: [minutes, separate]
Assumptions: [explicit; no invented learner diagnosis]

## Outcome and evidence
By the end, participants will be able to [observable action].
Evidence: [product/performance].
Success criteria: [what a reviewer can observe].
Evidence limitation: [simulation, self-study or real classroom observation].

## See an example
[Supply the actual original example, not a request to find one later.]

## Understand the decision
[Main method, why it fits, alternative and trade-off.]

## Inspect a weak example
[Original illustrative attempt, precise problem, improved version.]

## Do the task
[Inputs, directions, grouping, timing, participant product.]

## Teaching sequence
| Stage | Minutes | Teacher/trainer action | Learner/trainee action | Evidence/feedback |
|---|---:|---|---|---|

## Compare and improve
[Key or criteria, acceptable variations, model response, revision task.]

## Access and adaptation
[Text/print route; support; extension preserving the aim.]

## Keep the evidence
[What to keep privately; what it does and does not show.]

## Return later
[Small transfer/retrieval task; timing separate from core session.]

## Resources and provenance
[Actual files, sources, asset rights, version and unresolved checks.]

## Review record
[Checks really performed; named human reviewer only after actual review.]


# Classroom pack — [Unit ID / version]

## Learner sheet — separate file
Title and real-world purpose:
Level/context (provisional when not assessed):
What to do, with whom, and how long:
Supplied text/dialogue/cards/data:
One example:
Tasks with stable IDs (T01, T02...):
Space or format for the response:
Self-check:
Support and extension:

Do not include the teacher's answer key on the student-facing page. Do not write placeholders such as “insert a suitable text” in a completed pack.

## Teacher guide — separate file
Outcome, prerequisites and materials:
Language analysis where relevant: meaning, form, pronunciation, use:
Stage timings and grouping:
Exact demonstration/instructions where useful:
Likely difficulty and response:
Task keys with matching IDs:
Acceptable variants and reasons:
Open-response criteria and illustrative answer:
Feedback and second attempt:
Offline and access adaptations:
Source/rights notes:

## Assessment and reflection
Observable criterion:
Evidence to collect (anonymised as appropriate):
What would not justify a claim of progress:
One useful feedback statement:
Revision to try:
Private record / public illustrative example distinction:
