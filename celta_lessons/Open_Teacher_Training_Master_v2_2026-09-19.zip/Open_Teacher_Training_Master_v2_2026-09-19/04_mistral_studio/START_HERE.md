# Start here — Mistral Teaching Studio Pack
Companion to the illustrated PDF. No changes have been made to your Mistral account or website.

## Build now
1. Prompts: create `ott-build-teaching-unit` using 02_UNIT_REQUEST_TEMPLATE.txt. Its angle-bracket placeholders are manual editing cues, not a claim of automatic interpolation.
2. Skills: create `teaching-materials-methods`. Description: Use when creating, adapting or reviewing English-teaching materials, teacher-training units, method cards, learner worksheets, answer keys or assessment rubrics. Paste 05_SKILL_INSTRUCTIONS.txt into its instructions field.
3. Unzip this kit. Attach the four Markdown files under skill/references and skill/examples individually when supported. Do not upload this entire ZIP into a field whose archive support has not been verified. Keep it private during testing. Studio sharing and Vibe availability are separate controls [S02].
4. Playground: select an available model using MODEL_SETTINGS.md. Paste 01_AGENT_INSTRUCTIONS.txt into the system/instructions field. This makes the procedure explicit without assuming a native skill attachment. Create a NEW agent named OTT Materials Studio.
5. Send 04_FIRST_TEST.txt. Save the returned draft yourself unless an actual save tool returns success. In a fresh checking conversation provide the same brief, exact draft and 03_REVIEW_REQUEST.txt.

## Do not add yet
Custom functions, website write access and durable workers are optional later stages. The first useful teaching-unit test does not need them. Read the PDF's function and workflow sections before connecting anything.

## Four attachment files
- skill/references/methods.md
- skill/references/templates.md
- skill/references/quality.md
- skill/examples/M02-U01.md
The example consolidates the earlier kit's separate materials. It remains an illustration, not a classroom study. Method selection rules are proposed design judgements, not universal findings.

See SOURCES.md for current documentation, provenance and boundaries. See VALIDATION.md for checks actually completed.
