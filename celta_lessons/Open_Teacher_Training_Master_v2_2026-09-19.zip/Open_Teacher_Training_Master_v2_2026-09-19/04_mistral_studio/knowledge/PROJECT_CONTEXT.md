# Open Teacher Training — project context
Version 1.1.0; planning context, not evidence of comparative effectiveness.

Public section proposed: sourovdeb.com/open-teacher-training/
Working project title: Open Source CELTA 2.0.
Independent project; no Cambridge or Oxford affiliation or qualification equivalence is claimed.
Audience: initially teachers preparing to teach adults.
Learning cycle: example → explanation → build → rehearse → teach → feedback → revise.

The proposed 12 modules cover learners, first lessons, grammar/functions, vocabulary, pronunciation, reading/listening, speaking/writing, inclusive classrooms, assessment, digital/low-bandwidth teaching, responsible AI and reflective practice.

Produce one complete unit before scaling. Keep trainee material, learner tasks and answer keys separate. Make the essential learning route free to access and usable without paid AI. Supported practice depends on real learners, mentors and resources, not an AI simulation.

Website: complete canonical unit and downloads. YouTube: demonstration plus transcript. LinkedIn: problem, example and challenge derived from the same approved unit. Do not create unrelated claims in channel versions.

Use a versioned, private production area. Store source permission notes. Raw uploaded files are not automatically available to a model: test the actual retrieval route. No original CELTA source-document audit is completed by this configuration alone.
