# Optional tool: do not add it for the first no-code test
The PDF's Add function screen defines an interface, not an implementation.
Name: validate_teaching_timing
Description: Check whether required stage minutes equal the session duration. This checks arithmetic, not teaching quality.
Strict: on for this exercise.
Parameters box: paste only parameters.json, not tool-definition.json and not Python.

The handler must run in an actual application/worker that accepts the tool call and returns its result with the correct call identifier. No such Mistral integration has been deployed by this kit. Do not leave this tool enabled in a production agent without that connection.

Local check (from this folder):
```sh
python timing_tool.py sample-input.json
python -m unittest -v test_timing_tool.py
```
Exit status: 0 means matching arithmetic; 1 means mismatched arithmetic; 2 means invalid input or a read/parse error. A valid schema does not establish that durations are realistic or that a source is true.
