"""Local arithmetic helper. Not connected to Mistral or to a website."""
from __future__ import annotations
import json
import math
import sys
from pathlib import Path
from typing import Any


def _number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number, not text or boolean")
    try:
        result = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result) or result <= 0:
        raise ValueError(f"{name} must be finite and greater than zero")
    return result


def validate_teaching_timing(target_minutes: float, stage_minutes: list[float]) -> dict[str, Any]:
    target = _number(target_minutes, "target_minutes")
    if not isinstance(stage_minutes, list) or not stage_minutes:
        raise ValueError("stage_minutes must be a non-empty list")
    if len(stage_minutes) > 200:
        raise ValueError("Use at most 200 stages per check")
    values = [_number(value, f"stage_minutes[{i}]") for i, value in enumerate(stage_minutes)]
    try:
        total = math.fsum(values)
    except OverflowError as exc:
        raise ValueError("Total duration is too large") from exc
    if not math.isfinite(total):
        raise ValueError("Total duration must be finite")
    return {
        "scope": "arithmetic_only",
        "target_minutes": target,
        "total_minutes": total,
        "difference_minutes": total - target,
        "matches_total": math.isclose(total, target, rel_tol=1e-9, abs_tol=1e-9),
        "human_review_required": True,
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python timing_tool.py sample-input.json", file=sys.stderr)
        return 2
    try:
        raw = Path(sys.argv[1]).read_text(encoding="utf-8")
        payload = json.loads(raw)
        if not isinstance(payload, dict) or set(payload) != {"target_minutes", "stage_minutes"}:
            raise ValueError("Expected exactly target_minutes and stage_minutes")
        result = validate_teaching_timing(**payload)
    except (OSError, ValueError, TypeError) as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0 if result["matches_total"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
