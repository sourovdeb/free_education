import unittest
from timing_tool import validate_teaching_timing

class TimingTests(unittest.TestCase):
    def test_equal(self):
        self.assertTrue(validate_teaching_timing(30, [3,4,3,5,4,6,3,2])["matches_total"])
    def test_mismatch(self):
        self.assertFalse(validate_teaching_timing(30, [10,10,15])["matches_total"])
    def test_fraction(self):
        self.assertTrue(validate_teaching_timing(0.3, [0.1,0.2])["matches_total"])
    def test_empty(self):
        with self.assertRaises(ValueError): validate_teaching_timing(30, [])
    def test_negative(self):
        with self.assertRaises(ValueError): validate_teaching_timing(30, [-5,35])
    def test_boolean(self):
        with self.assertRaises(ValueError): validate_teaching_timing(True, [1])
    def test_nonfinite(self):
        with self.assertRaises(ValueError): validate_teaching_timing(30, [float('nan')])
    def test_text(self):
        with self.assertRaises(ValueError): validate_teaching_timing(30, ['30'])
    def test_zero(self):
        with self.assertRaises(ValueError): validate_teaching_timing(30, [0,30])
    def test_no_tuple(self):
        with self.assertRaises(ValueError): validate_teaching_timing(30, (10,20))

if __name__ == '__main__': unittest.main()
