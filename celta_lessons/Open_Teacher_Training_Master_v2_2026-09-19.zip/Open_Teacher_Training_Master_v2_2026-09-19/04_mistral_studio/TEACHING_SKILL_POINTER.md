# Canonical teaching skill

Use one shared skill.
Avoid duplicate skill copies.

Canonical path:
`../03_skills/teaching-materials-methods/SKILL.md`

Mistral uses an adapter.
The core rules remain shared.
