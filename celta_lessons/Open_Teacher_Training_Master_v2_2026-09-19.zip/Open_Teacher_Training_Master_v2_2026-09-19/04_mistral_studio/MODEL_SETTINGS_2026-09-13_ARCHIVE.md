# Model configuration — initial design, not a benchmark
Checked against official Mistral documentation on 13 September 2026. Confirm account availability in the model selector before use. Log the returned model identifier; aliases ending in latest can change.

| Proposed role | Candidate ID | Initial settings where supported |
|---|---|---|
| Draft and format one unit | mistral-small-2603 | Temperature 0.4; reasoning none/default; output budget 4,096 tokens for a compact pack |
| Separate review or hard language question | mistral-large-2512 | Temperature 0.2; model-default reasoning; output budget 2,000 tokens |
| Escalation experiment | mistral-medium-3-5 | Model defaults first; compare on the same test set before paying more |

Do not force an unsupported temperature or reasoning option. Defaults depend on the model. Increase the output budget or split a truncated unit; do not remove essential checks just to fit. The proposed settings are experiments, not proven optimum values. A low temperature is not an accuracy guarantee.

Standard prices, USD per one million tokens [S09]: Small 4 input 0.15 / output 0.60; Large 3 input 0.50 / output 1.50; Medium 3.5 input 1.50 / output 7.50. Token-only hypothetical cost for 10,000 input and 5,000 output tokens: 0.0045 / 0.0125 / 0.0525 USD respectively. Excludes tools, retrieval, hosting, retries and any applicable charges. Free course access does not imply an unlimited free production backend.

The English teacher agent in the screenshot uses magistral-small-2509. The current catalogue puts that older model in its deprecated/retired section [S05]. Create a new test agent rather than overwrite it. This is not proof that the old entry cannot run in your account.

0.8 seconds is an elapsed-time target or timeout. Temperature 0.8 is a sampling choice with no time unit. Neither screenshots nor this kit establish a measured end-to-end latency.
