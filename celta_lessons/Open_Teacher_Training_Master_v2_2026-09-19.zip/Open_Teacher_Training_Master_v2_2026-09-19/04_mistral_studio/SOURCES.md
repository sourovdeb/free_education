# Sources and provenance

Checked 13 September 2026. These are documentation checks, not account tests.

## [S01] Mistral: reusable Prompts
https://docs.mistral.ai/en/getting-started/quickstarts/studio/create-reusable-prompt

Prompt creation, versions and visibility.

## [S02] Mistral: create a Skill in Studio
https://docs.mistral.ai/getting-started/quickstarts/studio/create-skill

Skill fields, supporting files, sharing and availability in Vibe.

## [S03] Mistral: test a model in Playground
https://docs.mistral.ai/getting-started/quickstarts/studio/test-model-playground

Model selection, interactive tests and generation settings.

## [S04] Mistral: Chat API reference
https://docs.mistral.ai/api

Temperature, max_tokens, streaming, available models and JSON schemas.

## [S05] Mistral: Models overview
https://docs.mistral.ai/models

Current model catalogue and deprecated/retired section.

## [S06] Mistral Small 4 model card
https://docs.mistral.ai/models/mistral-small-4-0-26-03

Model ID, capabilities and context.

## [S07] Mistral Large 3 model card
https://docs.mistral.ai/models/mistral-large-3-25-12

Model ID and capabilities.

## [S08] Mistral Medium 3.5 model card
https://docs.mistral.ai/models/mistral-medium-3-5-26-04

Model ID and capabilities.

## [S09] Mistral: inference pricing
https://docs.mistral.ai/inference/pricing

Standard USD input/output prices, checked 13 September 2026.

## [S10] Mistral: Libraries
https://docs.mistral.ai/studio/search/libraries

Persistent retrieval collections, upload, processing and access.

## [S11] Mistral: build an agent with tools
https://docs.mistral.ai/getting-started/quickstarts/developer/build-an-agent

Tool declaration, execution by an application and return of results.

## [S12] Mistral: Function Calling
https://docs.mistral.ai/studio/conversations/function-calling

The model requests tool calls; application code executes them.

## [S13] Mistral: Workflows overview
https://docs.mistral.ai/studio/workflows/getting-started/overview

Public-preview, code-first workflows; hosted orchestration and user-run workers.

## [S14] Mistral: your first workflow
https://docs.mistral.ai/studio/workflows/getting-started/your_first_workflow

Python/uv prerequisites, project scaffold and worker startup.

## [S15] Mistral: Workflows cookbook examples
https://docs.mistral.ai/studio/workflows/getting-started/cookbook_examples

Examples of human input, retries, structured output and sub-workflows.

## [S16] Mistral: Agents and Conversations
https://docs.mistral.ai/studio/agents/agents-api

Agent configuration, instructions and tool use.

## Project sources supplied in this conversation
- Six Screenshot_20260913_*_Chrome.jpg screenshots: actual UI crops in the PDF, with added numbered arrows.
- teaching-materials-methods.zip: previous method-selection, quality, templates and illustrative lesson; adapted below.
- rigorous-analysis.zip: claim/evidence/alternative/correction procedure.
- Open_Source_CELTA_2_0_Blueprint_Editable.md and Open_Teacher_Training_Website_Section.md: project scope and proposed publishing section.

Original CELTA course handouts were not supplied in this attachment set. No new document-by-document CELTA audit or comparative outcome study is claimed.
