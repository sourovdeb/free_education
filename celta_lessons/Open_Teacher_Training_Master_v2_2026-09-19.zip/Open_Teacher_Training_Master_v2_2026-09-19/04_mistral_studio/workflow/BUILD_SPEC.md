# Implementation demand — OTT one-unit pipeline
Status: design specification. It is not a deployed or account-tested workflow.

## First usable version
One Studio drafting agent + a reusable request + a structured skill + manual review. No website credentials, custom function or worker is needed to test content generation. Use the copied agent instructions as the explicit procedure; do not assume a saved Skill/Prompt is automatically attached to every agent.

## Later automation
Choose ONE owner for job state/retries: the existing n8n system OR Mistral Workflows. Do not build both as competing supervisors. This guide describes Mistral Workflows because the user supplied its documentation; it is not compulsory for the teaching skill.

Mistral Workflows is documented as public-preview and code-first, with a hosted orchestrator and user-run workers [S13]. A Workflows menu item is not a no-code visual workflow authoring canvas. The official scaffold requires Python 3.12+ and uv/uvx [S14]. In an appropriate terminal, start the documented setup command `uvx mistralai-workflows-cli@latest setup`; inspect the generated project. `make start-worker` runs its worker. These are setup instructions, not commands run on the user's computer by this kit. Keep the worker available for jobs to execute. A sleeping development laptop is not always-on production.

## Required input
unit_id, version, topic, audience, mode, learner_context, training_minutes, example_minutes, example_embedded, group_size, delivery_mode, access_constraints, source_refs, output_formats, approved_budget.
Unknown non-critical values may be labelled assumptions. Block missing rights/privacy/required-input issues only when they materially affect the task. No API keys inside learner-facing files.

## State sequence
NEW → BRIEF_READY → SOURCES_READY → DRAFTED → CHECKED → REVISED → READY_FOR_REVIEW.
A reviewer can request REVISION or approve a specific content hash/version. APPROVED → EXPORT_READY. PUBLISHED is separate and requires an actual publishing receipt. No content change inherits an earlier approval automatically.

## Activities
1. Validate the brief and find an existing same unit/version before starting.
2. Retrieve only relevant source passages through an actual connected library, or read supplied excerpts. Record actual source locations. Do not equate upload with successful retrieval.
3. Generate one unit using the agreed model, procedure version and output template.
4. Check required fields, answer references and timing with deterministic code where possible. Then perform a separate content review.
5. Repair only failing sections, at most twice. Stop with a useful defect report after that.
6. Persist versioned draft outputs and checks; return an accurate receipt or a save failure.
7. Present one human review decision for the entire pack, not a prompt at every drafting step.
8. On genuine approval, derive website, video-script and social drafts from that exact master. Publishing remains separately authorised.

## Failure handling and cost
A proposal for the pilot: allow up to 120 seconds for one generation activity and 10 minutes of active processing per job; exclude time waiting for a reviewer. These are configurable starting limits, not measured performance or provider guarantees. Enforce limits in code, not by asking the model to watch a clock.
Transient rate/server errors: honour server retry guidance, back off, and allow two retries. Input/permission errors: do not retry unchanged. Before re-running any write after a timeout, check whether it already succeeded. Avoid nested retry loops in the SDK and orchestrator. Enforce the approved per-job and daily budget; stop rather than silently increase it.

## Records and quality
Store run_id, unit_id/version, model_id, procedure_version, source_refs, timestamps, token usage, status, checks, unresolved issues, output references and review receipt. Do not log secrets or identifiable learner records in public traces. Compare the generated teaching pack to the supplied example and the quality checklist. A schema-valid pack is not proof of educational effectiveness.

## Handoff acceptance
Produce a repeatable first unit; demonstrate source retrieval when configured; deliberately introduce an answer/timing fault and catch it; simulate an interruption without duplicate writes; prove a draft cannot become published through model text alone. Supply logs from actual tests, not model claims that testing happened.
