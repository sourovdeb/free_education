# Optional working templates

Use only the fields useful to the task. These are proposed analytical structures, not legal requirements.

## Evidence register

| ID | Item and source location | Author/custodian | Event date / document date | Original, copy, report, inference | Actually inspected | Dependencies / limits |
|---|---|---|---|---|---|---|

## Findings register

| Claim ID | Exact proposition | Supporting source and location | Contrary evidence | Rule or decision criterion | Finding | Confidence and reason | What would change it | Material consequence |
|---|---|---|---|---|---|---|---|---|

## Action register

| Priority | Owner / recipient | Exact action or request | Evidence required | Verified deadline / working target | Desired result | Failure or escalation condition |
|---|---|---|---|---|---|---|

## Correction log

| Prior statement | New evidence | Corrected conclusion | Documents or actions affected |
|---|---|---|---|

## Bounded handoff

```text
Decision being addressed:
Scope actually reviewed:
Decisive evidence IDs:
Supported findings:
Contradicted claims:
Unresolved material questions:
Urgent dates and basis:
Next action:
External actions actually performed:
```
