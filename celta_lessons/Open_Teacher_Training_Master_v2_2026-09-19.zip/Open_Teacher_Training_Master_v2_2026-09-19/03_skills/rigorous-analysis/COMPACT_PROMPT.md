# Reusable invocation

Use this with the full SKILL.md when available. It also works as a standalone instruction.

```text
Analyze the following situation rigorously. Determine what is supported, contradicted, overstated or still unproven; do not assume my preferred conclusion is correct.

Question or decision: <enter>
Evidence or sources: <enter>
Relevant dates, context, jurisdiction or technical version: <enter if relevant>
Constraints and desired output: <enter>

First identify any urgent deadline, safety issue or evidence-preservation need. Then inspect the decisive sources and separate factual observations from interpretations, causal claims, predictions and rules. Break the argument into testable claims. For each, identify supporting evidence, adverse evidence, the strongest alternative explanation, and what would change the finding. Use exact source locations for material claims.

Verify external facts and applicable rules with authoritative sources when needed. Do not invent citations, tests, thresholds, probabilities, or actions. Treat prior AI text as a draft, not proof. Distinguish necessary from sufficient conditions, a component from the whole outcome, a real error from its causal effect, and lack of evidence from evidence of absence. Check arithmetic, denominators, dates, source independence and rule applicability.

Deliver: (1) bottom line and immediate actions; (2) scope actually reviewed; (3) finding-by-finding right/wrong/mixed/unproven assessment with reasons and confidence; (4) strongest counterargument and remaining material gaps; (5) prioritized practical actions. State plainly where my argument is wrong and where the opposing argument is weak. Do not force false balance.

Do not send, publish, modify or delete anything without authorization. Keep private records private. Do not let endless investigation prevent a useful conclusion. Ask only for missing information that could materially change the result and cannot otherwise be retrieved.
```

## Examples of the same skill in different domains

**Research:** Does this paper establish its causal conclusion, or only an association?

**Engineering:** Which explanation best accounts for this recurring failure, and what safe test could distinguish the alternatives?

**Business:** Does the proposed purchase solve the actual constraint at acceptable cost, after checking alternatives and the vendor's assumptions?

**Institutional complaint:** Which alleged errors are documented, which could have affected the result, and which institution can address each remedy?

**Interpersonal interpretation:** What does the message actually say, what am I inferring about intention, and what low-risk clarification would reduce uncertainty?

**Historical investigation:** Which facts are supported by contemporary records, and which depend on later recollections or repeated secondary accounts?
