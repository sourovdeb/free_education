# Optional channel derivatives — M02-U01 / 0.1.0
Status: draft; no video or posts have been produced or published.

## Website summary
Practise giving a classroom instruction that learners can act on. Compare two examples, rehearse a short paired task and revise your instruction using observation notes. Text-first; no paid AI required.

## Short demonstration script
On screen: “What should the learner do next?”

Presenter: “Listen to this instruction. Can you tell me who works together, what they produce and how much time they have?”
Read the less-clear instruction from the master unit. Pause.

Presenter: “Now compare this: Work with a partner. Read the three cards. Choose one activity together. Say why. You have three minutes.”
On screen: “Partner → one choice → one reason → three minutes.”

Demonstrate the short exchange from the master unit.
Presenter: “The test is not whether the instruction sounds impressive. In this activity, we want learners to begin the intended task. Try it with a peer, record any uncertainty, revise one part and try again. A rehearsal is practice—not proof of classroom competence.”

Production note: This is a script, not an audio/video file. Add reviewed captions and the complete transcript after recording; measure the real duration then.

## LinkedIn draft 1 — the problem
A classroom instruction can be grammatically correct and still leave people unsure what to do. For your next activity, check four things: grouping, action, result and time. Then watch how learners start. This is the first practice question in our developing Open Teacher Training pathway.

## LinkedIn draft 2 — the example
“Consider these possibilities together” leaves a lot unsaid. For one paired-choice task, I would try: “Work with a partner. Read the three cards. Choose one activity together. Say why. You have three minutes.” Then demonstrate one response. The better wording depends on the actual task, not on a universal script.

## LinkedIn draft 3 — the challenge
Take an instruction from a lesson you are planning. Ask a peer to begin the activity using only that instruction. Note the first uncertainty, revise one part and try a different task later. Keep the evidence small and specific. We are building free teacher-training units around this kind of practice and revision.

Before release: add a real published course URL; verify the master version and approval. Do not insert a fake link or imply that a supported cohort is already open.
