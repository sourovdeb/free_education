# Choose our Saturday English-club activity
Illustrative adult A2 classroom task · M02-U01 · Version 0.1.0

## Your task
Work with a partner. Read the three cards. Choose one activity together. Say why. You have three minutes.

### Card A — Story club
Read a short story. Talk about the people in the story. Listen to another person's idea.

### Card B — Conversation club
Talk about everyday life. Ask your partner questions. Learn something new about your partner.

### Card C — Photo discussion
Look at three pictures. Choose an interesting picture. Talk about what you can see.

## Useful language
“I choose the ___ because ___.”
“Which activity do you choose?”
“Let's choose ___.”
“We choose the ___ because ___.”

## Your answer
We choose __________________________________________.
Our reason is _______________________________________.

## Check
Did you choose one activity together? Can both partners explain your reason?

All three choices can be reasonable. The aim is to agree and give a reason, not to guess the teacher's favourite activity.

Original illustrative material for this kit. No real learner data is included.
