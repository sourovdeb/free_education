# Teacher/trainer guide — M02-U01
Version 0.1.0 · Draft, not classroom-tested

## Two audiences
The 30-minute unit trains teachers in instruction-giving. Its embedded three-minute classroom task is designed provisionally for adults around A2. Confirm learners can understand the card vocabulary and give a simple reason before using it. The A2 label is a design estimate, not an assessment result.

## Preparation
Provide the master unit, learner sheet and an observation space. No media, paid AI or software is required. Decide who instructs, who acts as a learner and who observes. In a pair, alternate the observer role; solo study is a different evidence category.

## Classroom demonstration
Use the directions on the learner sheet. Model choosing together, not simply giving two separate answers. A meaning-focused discussion about preferences is the learner task; the trainee's assessed practice target is the instruction and revision.

## Checking and language support
“One activity or three?” checks the procedure. It does not assess the meaning of “because”. Model a reason separately when needed. Accept clear, intelligible alternatives to the sample wording. Do not make accent imitation part of this task's success criterion.

## Answer guidance
T01: The vague instruction can obscure partner grouping, one shared choice, a spoken reason and the time limit. Credit evidence-based alternative observations.
T02: The trainee's instruction needs the task-relevant information and a short demonstration. Exact copying is unnecessary.
T03: Record an observable event and a justified revision. For example, a fictional illustrative note could be: “The peer selected two activities, so I added ‘one activity together’ and demonstrated agreement.” This example is not data from a trial.

Learner-task answers: Story club, conversation club or photo discussion are all acceptable when both partners choose together and give a relevant reason. “We choose the story club because we like stories” is an illustration, not the only answer.

## Observation sheet
Task/version:
Grouping understood:
First action actually observed:
Question or point of hesitation:
Evidence that the required output was understood:
Exact revision:
What happened on the next attempt:
Alternative explanation, including task familiarity:
Next task to test transfer:

## Useful feedback
Describe the event, relate it to the criterion, suggest one change and allow another attempt. Do not replace evidence with “natural teacher”, “weak student” or a generic rating.

## Limitations and release
This is an original model pack. No real learners, recordings or scores were collected. Human editorial review, rights/licensing decisions and any live-course deployment remain separate. Keep real participant notes private in an appropriately controlled location.
