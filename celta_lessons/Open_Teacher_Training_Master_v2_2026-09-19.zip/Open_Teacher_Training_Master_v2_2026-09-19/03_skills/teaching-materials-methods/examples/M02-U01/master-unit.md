# M02-U01 — Give instructions people can act on
Version 0.1.0 · Draft illustration · Module 2
Audience: trainee teachers preparing to teach adults.
Example class: adult English learners, provisionally A2; no real group has been assessed.
Training session: 30 minutes. Embedded classroom task: 3 minutes, not additional to the rehearsal budget. Optional later practice is outside the 30 minutes.

## Outcome and evidence
By the end, the trainee can give a short instruction for a paired choice task, demonstrate the intended response and revise the instruction after a peer rehearsal.

Evidence: a written instruction, a demonstration, an observation note and a revised version. Peer rehearsal shows preparation, not assessed classroom competence. A later real-classroom observation requires the supported-practice arrangements.

## The classroom task
Two learners choose one Saturday English-club activity together and give one reason. They can choose a story club, a conversation club or a photo discussion. The exact learner sheet is supplied separately.

## Compare two original illustrative instructions
**Less clear:** “So, what I thought we could perhaps do now, after you have had a look through these possibilities, is consider them together and see whether you can come to some kind of decision and then, once that is done, explain it.”

**Clearer for this task:** “Work with a partner. Read the three cards. Choose one activity together. Say why. You have three minutes.”

The first version leaves the grouping, number of choices, output and time unclear. The second states them. This is a task-specific design judgement, not a tested claim that shorter language is always better.

## Demonstrate rather than only describe
Trainer: “I choose the story club because I like stories. Which activity do you choose?”
Peer: “I choose the photo discussion.”
Trainer: “We need one choice together. Let's choose the photo discussion.”

Use a brief check only where needed: “One activity or three?” Expected answer: “One.” With a group still unsure about grouping, ask or demonstrate who works together. Avoid a ritual series of checks after the action is already clear.

## Thirty-minute sequence
| Stage | Minutes | What happens |
|---|---:|---|
| Notice the problem | 3 | Identify the information missing from the less-clear instruction. |
| Compare models | 4 | Mark grouping, action, output and time in the clearer version. |
| Inspect a demonstration | 3 | Explain what the sample exchange makes visible. |
| Write your version | 5 | Create an instruction for the supplied task and one justified check. |
| Rehearse once | 4 | One trainee instructs; a peer begins; an observer notes action and questions. |
| Revise and retry | 6 | Change one source of confusion; repeat; compare notes cautiously. |
| Self-check | 3 | Use the four criteria below and identify one unresolved issue. |
| Transfer plan | 2 | Name a different task and what its instruction would need. |
| Total | 30 | Optional later classroom use is separate. |

## Tasks and answer guidance
**T01:** Underline what is missing or ambiguous in the less-clear version. Reasonable answers include the exact grouping, required choice, final response and time. Do not penalise another valid observation.

**T02:** Write the instruction and a short demonstration. A possible answer is the clearer instruction above plus the sample exchange. Other concise, accurate versions are acceptable.

**T03:** Rehearse, record a specific moment of uncertainty and revise. A good answer includes an observable event and a change linked to it. “It was good” is not sufficient evidence. Do not invent a learner response when no rehearsal occurred.

## Observation criteria
Can the participant identify the grouping? Can they begin the intended action? Is the required result clear? Does the revision respond to a recorded issue? Record what happened, not a personality judgement.

A peer's success may reflect familiarity with the task. A second attempt may improve through repetition rather than wording alone. Treat these as alternative explanations; use a new task later before generalising.

## Access and adaptation
The full task works with text, paper and speech. No video or AI is required. For a solo trainee: read both instruction versions, write a script and mark hypothetical difficulties; label this self-rehearsal, not observed learner evidence. For learners needing more support, model one complete exchange and supply “We choose ___ because ___.” For a more demanding variant, require the pair to agree between two different initial preferences without increasing the number of cards.

## Return later
In a later session, write and rehearse instructions for a different activity, such as matching headings to short texts. Transfer the principles rather than copying the sentence sequence mechanically.

## Files and review
`learner-sheet.md`, `teacher-guide.md` and `unit.json` accompany this example. All dialogues, cards and answer illustrations were written for this kit. The lesson is not a reported classroom trial. No external teacher educator has approved it. The optional open licence remains an owner decision.
