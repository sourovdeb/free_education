# Install and use the skill

Copy the complete `teaching-materials-methods` folder into the skills directory of the Hermes profile you actually run. For the default installation, the resulting file is:

```text
~/.hermes/skills/teaching-materials-methods/SKILL.md
```

Keep references, templates, examples and scripts beside SKILL.md. Do not copy only the main file. For a named profile or custom HERMES_HOME, use that profile's actual skills directory. Do not overwrite another skill without comparing and backing it up.

Open a fresh Hermes session and ask it to list/load `teaching-materials-methods`. Hermes documents installed skills as slash commands. See references/sources.md, S10–S11.

```text
/teaching-materials-methods Build M02-U01 for Open Teacher Training.
Use the included example as a starting point, not proof of a classroom trial.
Create the master training unit, learner sheet, teacher guide, answers,
assessment, access alternatives and source notes. Keep it as a draft.
```

No additional Python packages are required for the optional validator. From this skill folder, with a working Python 3.10+ interpreter, run:

```sh
python scripts/validate_unit.py examples/M02-U01/unit.json
python -m unittest discover -s scripts -p 'test_*.py'
```

Use the Python executable available in the actual environment, such as `python3` where appropriate. The template manifest is intentionally incomplete and should fail validation until filled. Structural success is not pedagogical approval and does not authorize publication.

This package was not installed or executed inside the user's Hermes runtime. Text instructions can be adapted to another compatible agent, but no cross-agent integration has been tested.
