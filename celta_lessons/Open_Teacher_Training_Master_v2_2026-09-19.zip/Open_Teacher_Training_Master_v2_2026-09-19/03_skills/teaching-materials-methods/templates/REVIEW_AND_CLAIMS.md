# Review and claims — [Unit ID / version]

| Gate | Pass / revise / block | Actual evidence | Correction |
|---|---|---|---|
| Outcome-task-assessment alignment | | | |
| Language and answer guidance | | | |
| Complete usable materials | | | |
| Timing | | | |
| Access alternatives | | | |
| Sources and claims | | | |
| Rights and privacy | | | |
| Honest assessment/release status | | | |

## Material claim card
Proposition and scope:
Source actually inspected and location:
Alternative/counterevidence:
Finding and confidence:
Consequence:

## Release record
Structural checks actually run:
Human reviewer and date (leave pending until real):
Unresolved blockers:
Approved content version/hash (only after actual approval):
Public receipt (only after actual publication):
