"""Local regression tests. These do not test teaching effectiveness or WordPress."""
import copy
import json
from pathlib import Path
import unittest
from validate_unit import validate

EXAMPLE = Path(__file__).resolve().parents[1] / 'examples' / 'M02-U01'

class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((EXAMPLE / 'unit.json').read_text())

    def test_complete_example(self):
        self.assertEqual(validate(self.data, EXAMPLE), [])

    def test_timing_mismatch(self):
        self.data['expected_minutes'] = 31
        self.assertTrue(any('Timing mismatch' in e for e in validate(self.data)))

    def test_unknown_objective(self):
        self.data['tasks'][0]['objective_ids'] = ['O404']
        self.assertTrue(any('unknown reference' in e for e in validate(self.data)))

    def test_unknown_task(self):
        self.data['assessments'][0]['task_ids'] = ['T404']
        self.assertTrue(any('unknown reference' in e for e in validate(self.data)))

    def test_missing_key(self):
        self.data['tasks'][0]['answer_guidance'] = ''
        self.assertTrue(any('answer_guidance' in e for e in validate(self.data)))

    def test_duplicate_id(self):
        self.data['tasks'].append(copy.deepcopy(self.data['tasks'][0]))
        self.assertTrue(any('duplicate ID' in e for e in validate(self.data)))

    def test_unresolved_placeholder(self):
        self.data['audience']['primary'] = '<replace me>'
        self.assertTrue(any('placeholders' in e for e in validate(self.data)))

    def test_missing_file(self):
        self.data['resources'][0]['path'] = 'missing-file.md'
        self.assertTrue(any('file missing' in e for e in validate(self.data, EXAMPLE)))

    def test_path_escape(self):
        self.data['resources'][0]['path'] = '../private.md'
        self.assertTrue(any('within the pack' in e for e in validate(self.data, EXAMPLE)))

    def test_boolean_is_not_duration(self):
        self.data['stages'][0]['minutes'] = True
        self.assertTrue(any('stage.minutes' in e for e in validate(self.data)))

    def test_wrong_root_type(self):
        self.assertTrue(validate([]))

    def test_false_approval(self):
        self.data['status'] = 'approved'
        self.assertTrue(any('human_reviewer' in e for e in validate(self.data)))

if __name__ == '__main__':
    unittest.main()
