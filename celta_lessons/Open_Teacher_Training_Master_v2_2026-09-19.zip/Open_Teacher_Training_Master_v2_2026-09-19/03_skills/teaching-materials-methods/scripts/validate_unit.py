#!/usr/bin/env python3
"""Validate an ELT unit manifest. Structural checks only; never authorize publication."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import re
from typing import Any


def validate(data: Any, base_dir: Path | None = None) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return ['Manifest must be a JSON object.']

    def text(value: Any, label: str) -> bool:
        ok = isinstance(value, str) and bool(value.strip())
        if not ok:
            errors.append(f'{label}: non-empty text required.')
        return ok

    def mapping(value: Any, label: str) -> dict[str, Any]:
        if not isinstance(value, dict):
            errors.append(f'{label}: object required.')
            return {}
        return value

    def records(key: str) -> list[dict[str, Any]]:
        values = data.get(key)
        if not isinstance(values, list) or not values:
            errors.append(f'{key}: non-empty list required.')
            return []
        result = []
        for index, value in enumerate(values):
            if not isinstance(value, dict):
                errors.append(f'{key}[{index}]: object required.')
            else:
                result.append(value)
        return result

    def ids(items: list[dict[str, Any]], label: str) -> set[str]:
        result: set[str] = set()
        for item in items:
            item_id = item.get('id')
            if text(item_id, f'{label}.id'):
                if item_id in result:
                    errors.append(f'{label}: duplicate ID {item_id}.')
                result.add(item_id)
        return result

    def refs(value: Any, allowed: set[str], label: str) -> set[str]:
        result: set[str] = set()
        if not isinstance(value, list) or not value:
            errors.append(f'{label}: non-empty reference list required.')
            return result
        for item in value:
            if not isinstance(item, str) or item not in allowed:
                errors.append(f'{label}: unknown reference {item!r}.')
            else:
                result.add(item)
        return result

    def number(value: Any, label: str, allow_zero: bool = False) -> bool:
        ok = (isinstance(value, (int, float)) and not isinstance(value, bool)
              and math.isfinite(value) and (value >= 0 if allow_zero else value > 0))
        if not ok:
            errors.append(f'{label}: finite {"non-negative" if allow_zero else "positive"} number required.')
        return ok

    for key in ('schema_version', 'unit_id', 'module_id', 'version', 'status', 'mode'):
        text(data.get(key), key)
    unit_id, module_id = data.get('unit_id'), data.get('module_id')
    if not isinstance(unit_id, str) or not re.fullmatch(r'M\d{2}-U\d{2}', unit_id):
        errors.append('unit_id must look like M02-U01.')
    if not isinstance(module_id, str) or not re.fullmatch(r'M\d{2}', module_id):
        errors.append('module_id must look like M02.')
    elif isinstance(unit_id, str) and not unit_id.startswith(module_id + '-'):
        errors.append('module_id does not match unit_id.')
    if not isinstance(data.get('version'), str) or not re.fullmatch(r'\d+\.\d+\.\d+', data['version']):
        errors.append('version must look like 0.1.0.')
    if data.get('status') not in ('draft', 'ready_for_review', 'approved', 'published'):
        errors.append('Unknown review/publication status.')
    if data.get('mode') not in ('teacher_training', 'classroom_lesson', 'adaptation'):
        errors.append('Manifest is for a complete training/classroom/adaptation pack, not a method-only answer.')

    audience = mapping(data.get('audience'), 'audience')
    for key in ('primary', 'classroom', 'level_basis'):
        text(audience.get(key), f'audience.{key}')
    objectives = records('objectives')
    objective_ids = ids(objectives, 'objectives')
    for objective in objectives:
        text(objective.get('description'), 'objective.description')
    stages = records('stages')
    ids(stages, 'stages')
    minutes = []
    for stage in stages:
        text(stage.get('action'), 'stage.action')
        if number(stage.get('minutes'), 'stage.minutes'):
            minutes.append(stage['minutes'])
    expected_ok = number(data.get('expected_minutes'), 'expected_minutes')
    number(data.get('classroom_task_minutes'), 'classroom_task_minutes', allow_zero=True)
    if expected_ok and len(minutes) == len(stages) and stages:
        if not math.isclose(sum(minutes), data['expected_minutes'], abs_tol=0.01):
            errors.append(f'Timing mismatch: stages total {sum(minutes)}, expected {data["expected_minutes"]}.')

    tasks = records('tasks')
    task_ids = ids(tasks, 'tasks')
    practised: set[str] = set()
    task_objectives: dict[str, set[str]] = {}
    for task in tasks:
        linked = refs(task.get('objective_ids'), objective_ids, 'task.objective_ids')
        practised.update(linked)
        if isinstance(task.get('id'), str):
            task_objectives[task['id']] = linked
        for key in ('instruction', 'input', 'answer_guidance'):
            text(task.get(key), f'task.{key}')
    assessed: set[str] = set()
    assessments = records('assessments')
    ids(assessments, 'assessments')
    for assessment in assessments:
        obj_refs = refs(assessment.get('objective_ids'), objective_ids, 'assessment.objective_ids')
        task_refs = refs(assessment.get('task_ids'), task_ids, 'assessment.task_ids')
        covered_by_tasks: set[str] = set()
        for task_id in task_refs:
            covered_by_tasks.update(task_objectives.get(task_id, set()))
        if obj_refs - covered_by_tasks:
            errors.append('Assessment refers to objectives not practised by its linked tasks.')
        assessed.update(obj_refs)
        criteria = assessment.get('criteria')
        if not isinstance(criteria, list) or not criteria:
            errors.append('assessment.criteria: non-empty list required.')
        else:
            for criterion in criteria:
                text(criterion, 'assessment.criterion')
    for oid in sorted(objective_ids - practised):
        errors.append(f'Objective {oid} has no task.')
    for oid in sorted(objective_ids - assessed):
        errors.append(f'Objective {oid} has no assessment.')

    access = mapping(data.get('accessibility'), 'accessibility')
    for key in ('no_paid_ai', 'low_bandwidth', 'printable'):
        text(access.get(key), f'accessibility.{key}')
    for resource in records('resources'):
        resource_path = resource.get('path')
        path_ok = text(resource_path, 'resource.path')
        text(resource.get('rights'), 'resource.rights')
        if path_ok:
            candidate = Path(resource_path)
            if candidate.is_absolute() or '..' in candidate.parts:
                errors.append(f'Resource path must stay within the pack: {resource_path}.')
            elif base_dir is not None:
                root = base_dir.resolve()
                target = (root / candidate).resolve()
                try:
                    target.relative_to(root)
                except ValueError:
                    errors.append(f'Resource resolves outside the pack: {resource_path}.')
                else:
                    if not target.is_file():
                        errors.append(f'Resource file missing: {resource_path}.')
    for source in records('sources'):
        for key in ('id', 'type', 'location', 'supports'):
            text(source.get(key), f'source.{key}')
    review = mapping(data.get('review'), 'review')
    if data.get('status') in ('approved', 'published'):
        text(review.get('human_reviewer'), 'review.human_reviewer')
        text(review.get('reviewed_at'), 'review.reviewed_at')
    if not isinstance(data.get('public_release_authorized'), bool):
        errors.append('public_release_authorized: boolean required.')
    if data.get('status') == 'published' and data.get('public_release_authorized') is not True:
        errors.append('Published status without a declared release authorization.')
    if not isinstance(data.get('limitations'), list) or not data['limitations']:
        errors.append('limitations: state at least one actual limit or verification boundary.')

    def placeholders(value: Any) -> bool:
        if isinstance(value, str):
            return bool(re.search(r'<[^>]+>|\bTODO\b|\bTBD\b', value))
        if isinstance(value, dict):
            return any(placeholders(v) for v in value.values())
        if isinstance(value, list):
            return any(placeholders(v) for v in value)
        return False
    if placeholders(data):
        errors.append('Manifest contains unresolved placeholders.')
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.manifest.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(json.dumps({'structural_pass': False, 'errors': [str(exc)]}, indent=2))
        return 2
    errors = validate(data, args.manifest.parent)
    print(json.dumps({
        'structural_pass': not errors,
        'errors': errors,
        'boundary': 'Structure, IDs, file presence and arithmetic only. No semantic, factual, rights, privacy, pedagogical, approval-authenticity or classroom-outcome validation. No publication is authorized.'
    }, indent=2))
    return 1 if errors else 0

if __name__ == '__main__':
    raise SystemExit(main())
