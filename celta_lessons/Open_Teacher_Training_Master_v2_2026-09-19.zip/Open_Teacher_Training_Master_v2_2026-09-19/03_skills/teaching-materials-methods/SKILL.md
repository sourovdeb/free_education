---
name: teaching-materials-methods
description: Design, adapt, review, and package ELT materials or teacher-training units.
version: 2.0.0
metadata:
  project: open-teacher-training
  status: candidate
  tags: [education, elt, teaching, materials, curriculum]
---

# Teaching Materials And Methods

## Purpose
Build one useful unit.
Keep claims traceable.
Keep access free.
Separate training from teaching.
Never imply accreditation.
Never publish from here.

## Use this skill
Use for these tasks:
- teacher-training units
- classroom lesson packs
- method comparisons
- worksheet creation
- answer-key creation
- pronunciation practice
- reading tasks
- listening scripts
- speaking tasks
- writing tasks
- assessment rubrics
- accessibility adaptations
- material audits
- channel draft preparation

## Do not use
Avoid these tasks:
- live publishing
- account changes
- teacher certification
- learner surveillance
- high-stakes grading
- hidden data collection
- credential handling

Use separate workflows instead.

## Required inputs
Recover these first:
- task mode
- target audience
- learner context
- learning outcome
- time budget
- delivery mode
- access constraints
- requested artefacts

Use supplied sources first.
Mark missing facts clearly.

## Optional inputs
Use when supplied:
- existing lesson
- learner samples
- course module
- house style
- source list
- website target
- video target
- social target

## Output contract
Small tasks stay small.
Full packs contain:
1. brief
2. assumptions
3. observable outcome
4. method choice
5. alternative method
6. master unit
7. learner sheet
8. teacher guide
9. answer guidance
10. assessment criteria
11. revision task
12. source notes
13. access route
14. review status

Status stays explicit:
`draft`
`ready_for_review`
`approved`
`published`

Never skip states.

## Preflight
Read supplied files first.
Check actual file access.
Check available tools.
Check runtime versions when needed.
Check user permissions.
Check source rights.
Check privacy limits.
Check external costs when needed.

Then choose routing.

```text
Full unit needed?
  YES -> build pack
  NO  -> build request

Important claim disputed?
  YES -> evidence review
  NO  -> normal check

Publishing requested?
  YES -> prepare handoff
  NO  -> stop locally
```

## Reuse policy
Reuse working material first.
Inspect the body first.
Do not trust titles.
Do not clone blindly.

Prefer existing templates.
Prefer existing validators.
Revalidate reused material.
Avoid new dependencies.

New dependencies need reasons.
Ask permission before installs.
Provide no-install fallbacks.

## Procedure

### 1. Recover context
Identify task mode.
Separate both audiences.

Teacher trainees differ.
English learners differ.

Record both levels separately.
Record both timings separately.

Allowed modes:
- `teacher_training`
- `classroom_lesson`
- `adaptation`
- `audit`
- `method_comparison`

Default project context:
- adult teaching focus
- text-first materials
- optional AI use
- draft-only output

Assumptions need labels.

### 2. Define evidence
Choose one outcome.
Make it observable.
Define success evidence.

Watching proves attendance only.
Role-play proves rehearsal only.
Observation requires real teaching.

Teacher-training mode needs:
- trainee outcome
- learner task
- evidence criterion

### 3. Choose method
Read method guidance.
Match method to context.
Give one reason.
Give one alternative.
Name its trade-off.

Avoid universal claims.
Avoid method worship.
Avoid forced PPP use.
Avoid forced AI use.

### 4. Build materials
Provide actual materials.
Avoid empty placeholders.

Each activity needs:
- instructions
- input
- grouping
- timing
- learner product
- feedback route

Add examples when useful.
Label invented examples.

Language work may inspect:
- meaning
- form
- pronunciation
- use
- register
- variation

Reading needs exact input.
Listening needs supplied script.
Speaking needs communicative purpose.
Writing needs revision.
Pronunciation targets intelligibility.

### 5. Add feedback
Match answers exactly.
Explain open-answer criteria.
Link feedback to evidence.
Include another attempt.
Add later transfer practice.

Keep answers separate.
Check total timing.

### 6. Check access
Provide text alternatives.
Avoid paid-AI dependency.
Avoid streaming dependency.
Avoid colour-only cues.

Media plans need transcripts.
Scripts are not media.

### 7. Check evidence
Use source discipline.
Separate these categories:
- verified evidence
- user information
- inference
- project choice
- illustration
- unknown information

Changing facts need dates.
Versioned interfaces need checks.

Important disputes use:
- proposition
- supporting evidence
- strongest alternative
- finding
- change condition
- design consequence

Use rigorous analysis selectively.
Do not duplicate research.

### 8. Check rights
Prefer original content.
Check reuse permission.
Protect learner privacy.
Never fabricate consent.
Never fabricate review.
Never fabricate citations.

### 9. Validate structure
Use the quality gates.
Check these areas:
- alignment
- language
- completeness
- timing
- access
- evidence
- rights
- privacy
- assessment integrity
- release integrity

Full packs use manifests.
Run validator when available.

Validator success means structure.
It proves nothing else.

### 10. Repair
Use targeted repairs.
Allow two repair passes.
Record stale dependencies.
Then report blockers.

Do not loop endlessly.

### 11. Return output
Return artefacts first.
Then show checks.
Then show gaps.
Then show next action.

Never claim unseen results.
Never claim unsaved files.
Never claim publication receipts.

## Failure handling

### Missing input
Name the missing input.
Use safe assumptions only.
Otherwise stop that branch.

### Contradictory sources
Show both sources.
State the conflict.
Avoid forced certainty.

### Tool unavailable
Use manual fallback.
Do not invent tools.

### Empty tool output
Check expected postcondition.
Treat emptiness as failure.

### Rights uncertainty
Block public release.
Keep private draft only.

### Privacy uncertainty
Remove personal data.
Otherwise stop publication.

### Context limit
Chunk by unit.
Checkpoint completed work.
Continue from state.

## Small-model route
Use linear execution.
One stage per turn.
One artefact per stage.

Sequence:
`brief → outcome → method → material → key → checks`

Reload identifiers often.
Checkpoint completed stages.
Avoid whole-course generation.
Escalate one question only.

## Model realism
No prompt guarantees quality.
No model guarantees accuracy.
Host behavior needs testing.
Use separate review cases.

Model adapters stay small.
Do not fork skills.

## Publishing handoff
Publishing stays separate.
Use one master version.
Avoid duplicate packages.

Handoff should include:
- unit ID
- version
- content hash
- approval reference
- desired action
- destination IDs

Never include secrets.
Keep credentials outside prompts.

Retry public actions carefully.
Check destination first.
Avoid duplicate publication.

## Stop conditions
Stop when one applies:
- requested artefact completed
- blocker prevents correctness
- rights remain unresolved
- privacy remains unresolved
- repair budget exhausted
- authorization boundary reached

## Acceptance criteria
A complete pack needs:
- explicit audience
- observable outcome
- aligned evidence
- complete materials
- usable answers
- realistic timing
- access route
- source notes
- rights notes
- honest status

## Supporting files
Read only needed files.

- `references/course-context.md`
- `references/method-selection.md`
- `references/evidence-and-quality.md`
- `references/publishing-handoff.md`
- `references/sources.md`
- `templates/MASTER_UNIT.md`
- `templates/CLASSROOM_PACK.md`
- `templates/REVIEW_AND_CLAIMS.md`
- `templates/unit-manifest.json`
- `examples/M02-U01/`
- `scripts/validate_unit.py`
- `scripts/test_validate_unit.py`
