# Install

Keep this folder intact.
Place it under skills.
Use your host path.
Do not guess paths.

Canonical file:
`SKILL.md`

Supporting folders:
- `references/`
- `templates/`
- `examples/`
- `scripts/`

Run local tests first:

```bash
python scripts/test_validate_unit.py
```

Expected result:
`12 tests` and `OK`

This checks structure only.
Host behavior remains separate.
