# Source register and evidence boundary
Access/review date: 13 September 2026. URLs identify sources, not permissions to reproduce their contents. Recommendations in this kit are project design decisions unless attributed. No source supplies proof that this programme is superior to CELTA.

## Project inputs
**P1.** `Open_Source_CELTA_2_0_Blueprint_Editable.md`, version 0.2, supplied in this conversation. Used for the 12-module map, proposed 200-hour pathway, two routes and publishing architecture. The accompanying PDF was not re-analysed for this website task.
**P2.** Uploaded `rigorous-analysis.zip`, particularly its SKILL.md and templates. Used for source coverage, testable claims, competing explanations, bounded findings and correction records. This archive is an analysis framework, not the original CELTA course handouts.

## Public site — limited sample, not a full audit
**S1. Sourov Deb homepage.** `https://sourovdeb.com/` — inspected navigation, title index and listed teaching categories. Supports the existence of ELT365 and other teaching content; does not establish the quality or uniqueness of every article.
**S2. ELT Masterclass index.** `https://sourovdeb.com/elt-masterclass/` — inspected course description, sample early entries and later “Coming soon” labels. Supports preserving an existing course index rather than pretending the site has no course section.
**S3. Sample lesson-planning post.** `https://sourovdeb.com/5-min-pro-%C2%B7-how-to-plan-a-45-minute-lesson-from-scratch/` — inspected the short explanation and practice prompt. Treated as a candidate reading, not evidence that the entire archive has the same depth.

## Technical sources
**S4. WordPress, Create pages.** `https://wordpress.org/documentation/article/create-pages/` — supports Pages, parent/child hierarchy, draft settings and hierarchical addresses. Admin paths depend on the actual installed editor/theme.
**S5. WordPress, Block Patterns.** `https://wordpress.org/documentation/article/block-pattern/` — supports reusable block layouts and pattern editing.
**S6. WordPress, Synced Patterns (Reusable blocks).** `https://wordpress.org/documentation/article/reusable-blocks/` — supports the warning that deliberately synced content is shared across uses.
**S7. WordPress Importer, official directory and source.** `https://wordpress.org/plugins/wordpress-importer/` and `https://raw.githubusercontent.com/WordPress/wordpress-importer/master/src/class-wp-import.php` — supports WXR content import, author mapping and parent handling. The directory page displayed a warning about testing against recent major WordPress versions; that is not proof of an exploit or failure, but compatibility must be checked on staging. Source-code inspection is not a live import test. Do not install a development build merely to bypass a compatibility warning.
**S8. W3C WAI, Page Structure Tutorial.** `https://www.w3.org/WAI/tutorials/page-structure/` — informs semantic structure and navigation checks. This kit does not claim audited WCAG conformance.
**S9. W3C WAI, Captions/Subtitles.** `https://www.w3.org/WAI/media/av/captions/` — informs caption requirements and manual review of generated captions.
**S10. Hermes, Skills System.** `https://hermes-agent.nousresearch.com/docs/user-guide/features/skills` — supports default skill storage in `~/.hermes/skills/`, on-demand reference loading and slash-command access. Named profiles/custom HERMES_HOME locations must be checked in the actual installation.
**S11. Hermes, Creating Skills.** `https://hermes-agent.nousresearch.com/docs/developer-guide/creating-skills` — supports SKILL.md frontmatter plus references/templates/scripts organisation. This kit does not claim a tested installation in the user's runtime.

## Pedagogical source
**S12. British Council TeachingEnglish, Richard Frost, A task-based approach.** `https://www.teachingenglish.org.uk/professional-development/teachers/knowing-subject/task-based-approach` — inspected the article's descriptions of PPP and the task-based sequence. Professional guidance, not a controlled effectiveness comparison. Method-selection rules and original examples in this kit are design proposals; wider claims require further evidence.

## Deliberate gaps
No authenticated WordPress inspection; no full-site inventory; no private course-document audit; no formal qualification comparison; no independent educator review; no classroom trial; no live n8n/Hermes/WordPress integration. Generated page content, scripts and local checks must not be described as those activities.
