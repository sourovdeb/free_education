# Method selection: choose for the goal, not the label
These are the project's proposed design rules, not a meta-analysis or proof that one method outperforms another. An approach describes broader teaching principles; a lesson sequence organises stages; a technique is a particular classroom move.

| Main need | Candidate design | What to check | Useful alternative / caution |
|---|---|---|---|
| Introduce unfamiliar, tightly scoped language | Clear contextual explanation, supported practice, meaningful use | Accurate model; manageable demands; evidence beyond copying | Guided noticing may suit learners who can analyse examples; do not turn guessing into a test of prior knowledge. |
| Learners may already know some target language | Diagnostic task, focused teaching, comparable retry | Diagnose from actual performance rather than confidence | Begin with a brief model when the diagnostic task would be inaccessible. |
| Achieve a meaningful communicative outcome | Supported task cycle: prepare, perform, report, inspect language, retry | Real outcome, necessary language support, participation, time for feedback | A controlled rehearsal can precede the task; an activity is not meaningful merely because it is called a game. |
| Develop comprehension | Purposeful input, a suitable first task, closer inspection of difficulty, transfer | Exact text, useful strategy support, defensible answers | Adapt task demands or shorten input; not every reading needs a compulsory gist stage. |
| Improve writing | Audience/purpose, model analysis, planning, drafting, focused feedback, revision | The new draft responds to feedback without erasing the writer's meaning | A brief model-first sequence can serve a small transactional writing task. |
| Improve speaking | Reason to exchange information, preparation, interaction, feedback, repeat with a change | Learners have information or choices to communicate, not only lines to recite | Supported dialogue rehearsal can help before an information-gap task. |
| Develop vocabulary/chunks | Context, useful examples, noticing, retrieval/use and a later return | Natural collocations, appropriate register, manageable target set | A short explicit explanation may be more useful than a prolonged guessing game. |
| Develop pronunciation | Listen/notice, establish intended meaning, supported production, communicative use | Intelligibility, stress/context, variation; verified phonetic details | Do not demand one prestige accent or assume all learners need the same sound practice. |
| Develop a trainee's teaching judgement | Compare examples, rehearse, observe evidence, revise | Trainee performance and learner response are separately described | Add a worked demonstration when the trainee lacks a usable model. |

## Method card template
**Name and type:** approach / sequence / technique.
**Purpose:** the learner or teacher action it supports.
**Use when:** concrete context and prerequisites.
**Avoid or adapt when:** predictable mismatch.
**Procedure:** observable actions rather than slogans.
**Worked example:** original and clearly labelled.
**Materials:** exactly what the participants receive.
**Assessment:** evidence and its limitations.
**Alternative:** one credible option with a trade-off.
**Evidence:** what was actually inspected; guidance versus outcome research.

## Two distinctions to preserve
**Meaning checks:** establish whether a language meaning is understood; expected answers must follow from the example and not rely on more difficult wording than the target.
**Instruction checks:** establish what participants should do, with whom, and what result is required; ask only where the action is genuinely ambiguous. A quick demonstration or learner paraphrase may serve the purpose better than another question.

## Source anchor and limitation
British Council TeachingEnglish, Richard Frost, “A task-based approach”, inspected 13 September 2026: describes PPP and a task-based sequence involving preparation, a task, planning/reporting and language work. It is a professional-practice article, not a controlled comparison establishing universal superiority. The decision rules above are our project synthesis, not a reproduction of that article. Its URL is in `sources.md`.

Before claiming a measurable effect or a consensus, inspect suitable research and its population, comparison, outcome and limitations. A teaching tradition and a research finding are not interchangeable.
