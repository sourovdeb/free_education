# Project context
The independent programme uses the public-facing working identity Open Teacher Training / ELT365. “Open Source CELTA 2.0” remains an internal project title, not an awarded credential.

The previous booklet proposes 12 modules and 200 planned learning hours. This is a design allocation to test, not a completed course, accredited contact-hour claim or evidence of superiority. Preserve its open-study and separately supported-practice routes.

| ID | Module | Typical evidence |
|---|---|---|
| M01 | Understand the learner | Anonymised learner profile and achievable objective |
| M02 | Plan and teach a first lesson | Plan, rehearsal, observation and revision |
| M03 | Teach grammar and functions | Language analysis and teaching sequence |
| M04 | Teach vocabulary and expressions | Contextualised vocabulary task and return practice |
| M05 | Teach pronunciation for communication | Annotated model and intelligibility-focused practice |
| M06 | Teach reading and listening | Exact input, tasks, answers and strategy support |
| M07 | Teach speaking and writing | Communicative task, feedback and second attempt |
| M08 | Run an inclusive classroom | Two adaptations preserving the objective |
| M09 | Assess learning and give feedback | Assessment evidence and revised next step |
| M10 | Teach online and with low bandwidth | Browser, text/audio and printable routes |
| M11 | Use AI without surrendering judgement | Audited output, corrections and non-AI route |
| M12 | Teach, reflect and demonstrate | Three-lesson sequence and reviewed portfolio |

The pilot samples M02-U01, M01-U01, M03-U01 and M09-U01. It is not the full course order. Supported teaching means human observation of real learners; peer or AI rehearsal must never be counted as that practice.

Website section: `/open-teacher-training/`. Existing `/elt-masterclass/` and ELT365 articles are reuse candidates, not automatically reviewed course units. Preserve URLs and inspect actual bodies before reuse. No live-site change is authorized by this reference.

Default learner materials are designed for adult English classes. A supplied younger-learner brief requires age-appropriate language, tasks, consent and safeguarding arrangements. Do not infer a user's age or personal history as teaching content.
