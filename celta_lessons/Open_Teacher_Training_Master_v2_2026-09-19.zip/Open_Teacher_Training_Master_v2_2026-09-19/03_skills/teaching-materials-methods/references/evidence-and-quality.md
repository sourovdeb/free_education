# Evidence and quality gates
Use the uploaded rigorous-analysis framework's distinction between what was inspected, what follows from it and what remains unproven. This is an operational adaptation, not a claim of independent expert review.

## Source discipline
For each important claim, record source author/title, URL or file/page location, access date, exact scope supported and limits. A source may support terminology or procedure without demonstrating effectiveness. Do not cite a homepage for a specific research result. An inaccessible source remains unverified. A previous AI report is a lead, not independent corroboration.

## Small claim card
Claim and scope:
Type: factual / interpretive / causal / predictive / project choice
Supporting evidence inspected:
Contrary evidence or strongest alternative:
Finding: supported / contradicted / overstated / unproven / not assessable
Confidence and reason:
What would change the finding:
Design consequence:

Use a card for material contested claims, not every sentence of a simple worksheet. Evidence gathering stops when it no longer affects the unit's decision; report the unresolved issue instead of browsing indefinitely.

## Release gate
| Gate | Pass condition | Blocking example |
|---|---|---|
| Alignment | Outcome, task and assessment describe the same performance | Grammar objective assessed only through an unrelated vocabulary quiz |
| Language | Instructions, examples, meanings and keys are accurate | Incorrect rule, misleading answer or unverified phonetic assertion |
| Completeness | Inputs, directions, materials and answer/feedback guidance exist | “Use an audio clip” without audio or supplied script |
| Timing | Teaching stages fit the budget; optional work is separated | A 30-minute session with 50 minutes of required work |
| Access | Essential learning works in the stated low-resource route | Mandatory video or colour-only answer cue with no alternative |
| Evidence | Important claims are sourced or qualified | Invented research or unsupported guaranteed learning claim |
| Rights | Each asset has a documented usable basis | A downloaded paid workbook relabelled as original |
| Privacy | No identifiable learner information enters the public pack | A student name/recording shared without appropriate arrangements |
| Assessment integrity | Simulation, self-study and observation are distinguished | AI role-play counted as real teaching hours |
| Release integrity | The approved version is the version released | Revised content retains an old approval without review |

Any serious factual, rights, privacy or assessment-integrity failure blocks publication. Do not turn an arbitrary numerical score into an accredited standard. Use specific pass/revise/block findings and explain the correction.

## Review levels
**Structural check:** software verified field presence, IDs and arithmetic.
**Editorial/pedagogical review:** a named authorized human inspected the actual unit.
**Classroom trial:** a documented implementation with real learners under appropriate arrangements.
**Outcome evaluation:** measurements that support only the conclusions justified by their design.

Passing one level does not establish the next. “Ready for human review” is not “educator approved”. Do not impersonate a reviewer or invent trial outcomes.

## Correction log
Record unit ID/version, prior statement, new evidence, corrected content, affected downloads/channel drafts and actual release receipts. Preserve a reviewed original; create a new version for edits.
