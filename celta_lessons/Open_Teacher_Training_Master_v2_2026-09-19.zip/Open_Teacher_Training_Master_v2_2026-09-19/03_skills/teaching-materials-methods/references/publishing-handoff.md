# Publishing handoff — content only unless separately authorized
The master unit is the source of truth. Website, video and social posts must use the same unit ID/version and supported claims.

## Deliver when requested
Website: complete text lesson, descriptive title, short description, module/previous/next targets and real downloadable files.
YouTube: script, demonstration plan, onscreen text and caption/transcript draft. A script is not a produced video. Do not invent a video URL or measured runtime.
LinkedIn: three distinct drafts—a problem, a worked example, and a practice invitation—with a verified course link or an explicit unpublished-link placeholder kept out of public output.

## State and execution
`draft → ready_for_review → approved → published`
Approval must identify the human reviewer, scope and exact content version. Publication requires a receipt from the actual service. A failed or uncertain response is not proof of failure; inspect the destination before retrying to avoid duplicate public posts.

For later n8n integration, pass unit ID, version, content hash, desired action, approval reference and known destination IDs. Keep secrets out of manifests. Use the existing page ID for updates. n8n executes configured actions; Hermes diagnoses mismatches and revises the master.

No automation schedule, connected API, live upload or background task is installed by this skill. A configured draft-only batch can run without repeated approval within its authorized scope; public release must follow the actual permission record.
