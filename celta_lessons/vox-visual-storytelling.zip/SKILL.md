---
name: vox-visual-storytelling
description: Turn book chapters and long-form text into Vox-style documentary explainer videos using Manim (2D motion graphics) and Blender (3D shots), with reusable parameterized effect scripts instead of per-project rewrites. Use when the user asks to convert a chapter/article/book excerpt into visual storytelling, an explainer or documentary video, animated narration, or asks for Vox-style effects (text highlighting, word focus, map route animations, animated charts, quote cards, paper cutouts, 3D book reveals). Always starts by scanning local tools with scripts/check_tools.py.
---

# Vox-Style Visual Storytelling

Adapted from the workflow of "Create a VOX style Documentary" (opening scene,
map animations, text highlighting, animated chart, word focus), re-implemented
as reusable Manim/Blender scripts.

## Workflow

1. **Scan the environment first — always.**
   `python3 scripts/check_tools.py --install`
   This reports manim, ffmpeg, blender, fonts (incl. CJK), and install hints.
   If core tools are missing, install them or tell the user exactly what to
   install before writing any scene code.

2. **Storyboard the chapter.** Follow `references/storyboard_guide.md`:
   extract 5–12 beats, map each beat to an effect, produce one JSON config
   per shot. Get user sign-off on the shot list for anything longer than
   ~1 minute of final video.

3. **Reuse scripts — do not rewrite.** The effect library lives in
   `scripts/vox_manim_effects.py` (TitleCard, HighlightText, WordFocus,
   MapRoute, AnimatedChart, QuoteCard, PaperCutout). Copy it into the project
   folder and drive it with config JSON:

   ```bash
   cp scripts/vox_manim_effects.py .
   VOX_CFG=shot01.json manim -qh vox_manim_effects.py HighlightText
   ```

   Use `-ql` while iterating. Blender 3D chapter openers:
   `blender -b -P scripts/blender_book_reveal.py -- '{"text":"Chapter 3","out":"book.mp4"}'`
   (only if check_tools.py reports blender OK).

4. **Assemble.** `python3 scripts/assemble_video.py manifest.json -o final.mp4`
   handles clip concat plus optional narration/music ducking.

## Reuse contract

- `scripts/` files are the master library. Copy, configure via JSON, never fork
  for a single project. When a new effect is genuinely needed, add it to the
  master script (with JSON params) so all future projects inherit it.
- Per-project artifacts (shot JSONs, manifests, media/) stay in the project
  folder, not in the skill.

## Notes

- Chinese text requires a CJK font (check_tools.py verifies); set
  `"font": "Noto Sans SC"` in params.
- LaTeX is optional; all bundled scenes use `Text()`, not `MathTex`.
