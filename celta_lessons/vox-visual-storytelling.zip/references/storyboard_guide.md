# Turning a Book Chapter into Visual Storytelling (Vox Style)

## The pipeline (always in this order)

1. **Scan tools** — run `scripts/check_tools.py` first. Never write a scene
   before knowing what renders. Blender absent → skip 3D shots, use
   `PaperCutout`/`TitleCard` instead. CJK font missing → install one or fall
   back to English labels.
2. **Extract beats** — read the chapter and list 5–12 *beats*: the smallest
   units that each carry ONE idea (a claim, a number, a place, a quote, a turn).
   If a beat needs two sentences to explain, split it.
3. **Map beats to shots** — one shot per beat, 3–10 s each. Choose the effect
   by narrative function (table below), not by novelty.
4. **Write the shot list** as JSON (schema below) and get it approved if the
   user is available.
5. **Render per shot** — copy `scripts/vox_manim_effects.py` into the project
   (never edit the master copy), write one config JSON per shot, render:
   `VOX_CFG=shot01.json manim -qh vox_manim_effects.py HighlightText`
   (`-qh` 1080p for final; `-ql` while iterating).
6. **Assemble** — `scripts/assemble_video.py manifest.json -o final.mp4`.

## Beat → effect mapping

| Beat contains…                    | Scene class      | Why it works                     |
|-----------------------------------|------------------|----------------------------------|
| Chapter/section opening           | TitleCard or blender_book_reveal | Sets tone, gives a rest beat |
| A key phrase in a longer passage  | HighlightText    | Marker sweep = "someone read this for you" |
| One loaded word (numbers, names)  | WordFocus        | Isolation creates emphasis       |
| Geography, movement, journey      | MapRoute         | Dashed route reads as "travel"   |
| Statistics, change over time      | AnimatedChart    | Growing bars + counting number   |
| A voice from the text (quotation) | QuoteCard        | Paper card = primary source feel |
| Photo, portrait, artifact         | PaperCutout      | Scrapbook intimacy               |

## Pacing rules (Vox grammar)

- No shot longer than ~10 s without an internal change (zoom, highlight, count).
- Alternate "reading" shots (HighlightText, QuoteCard) with "moving" shots
  (MapRoute, AnimatedChart) — never three of the same kind in a row.
- Put the single strongest fact at ~70% of runtime, not at the end.
- Cuts on narration phrase boundaries; hold 0.5–1 s after the last animation.

## Shot list JSON schema (shot01.json)

```json
{
  "scene": "HighlightText",
  "params": {
    "text": "By 1900 the city held three million people.",
    "highlights": ["three million"],
    "accent": "#FFD94A",
    "font": "Noto Sans SC"
  }
}
```

Manifest for assembly: see `scripts/assemble_video.py` docstring.

## Style constants (keep consistent across the whole video)

- Background `#111111`, marker yellow `#FFD94A`, paper `#F5F0E1`, text white.
- One font family per language; display serif only for titles.
- 24 or 30 fps, 1080p, consistent `hold` timing.

## Failure handling for smaller models

- Manim render fails → re-render with `-ql`; if a LaTeX/MathTex error appears,
  switch that mobject to `Text()` (check_tools.py reports LaTeX status).
- `points` outside 0..1 in MapRoute → clamp, don't crash.
- Missing image for PaperCutout → it renders a placeholder; report it, never
  silently skip the shot.
- If a scene renders but looks wrong, fix the JSON params — do not fork the
  script. Only extend `vox_manim_effects.py` when a genuinely new effect is
  needed, and add it to the master copy so future projects reuse it.
