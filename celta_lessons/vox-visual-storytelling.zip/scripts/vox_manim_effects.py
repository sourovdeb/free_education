"""Reusable Vox-style documentary effects for Manim Community Edition.

DO NOT rewrite these scenes per project. Drive them with a JSON config:

    export VOX_CFG=scene_config.json
    manim -qh vox_manim_effects.py HighlightText

scene_config.json:
    {"scene": "HighlightText", "params": { ... }}

Every class reads `params` for its own name. Render one scene per output
clip, then stitch clips with assemble_video.py.

Available scenes: TitleCard, HighlightText, WordFocus, MapRoute,
AnimatedChart, QuoteCard, PaperCutout.

Shared params (all scenes, optional):
    font (str)            e.g. "Noto Sans SC" for Chinese, "Inter" for English
    bg (color)            default "#111111"  (Vox charcoal)
    accent (color)        default "#FFD94A"  (Vox marker yellow)
    fg (color)            default "#FFFFFF"
    hold (float seconds)  hold at end of scene, default 1.0
"""
import json
import os

from manim import *

_CFG = {}
_cfg_path = os.environ.get("VOX_CFG")
if _cfg_path and os.path.exists(_cfg_path):
    with open(_cfg_path, encoding="utf-8") as f:
        _CFG = json.load(f)

def P(scene_name, **defaults):
    """Params for a scene = JSON overrides over built-in defaults."""
    user = _CFG.get("params", {}) if _CFG.get("scene") in (scene_name, None) else {}
    out = dict(defaults)
    for k, v in user.items():
        if k in out or not defaults:
            out[k] = v
    out.update({k: v for k, v in user.items() if k not in out})
    return out

def _style(p):
    d = {"color": p.get("fg", WHITE)}
    if p.get("font"):
        d["font"] = p["font"]
    return d

def _common(p):
    return {"bg": p.get("bg", "#111111"), "accent": p.get("accent", "#FFD94A"),
            "hold": p.get("hold", 1.0)}


class TitleCard(Scene):
    """Typewriter-style chapter title with marker underline. Params:
    title, subtitle(optional), plus shared params."""
    def construct(self):
        p = P("TitleCard", title="Chapter One", subtitle="")
        c = _common(p)
        self.camera.background_color = c["bg"]
        title = Text(p["title"], weight=BOLD, **_style(p)).scale(1.4)
        self.play(AddTextLetterByLetter(title), run_time=1.6)
        underline = Line(title.get_left() + DOWN * 0.35, title.get_right() + DOWN * 0.35,
                         color=c["accent"], stroke_width=10)
        self.play(Create(underline), run_time=0.7)
        if p.get("subtitle"):
            sub = Text(p["subtitle"], **_style(p)).scale(0.6).next_to(underline, DOWN, buff=0.4)
            self.play(FadeIn(sub, shift=UP * 0.2))
        self.wait(c["hold"])


class HighlightText(Scene):
    """Marker-pen highlight sweeping across key words in a passage. Params:
    text, highlights (list of exact substrings to mark), plus shared params."""
    def construct(self):
        p = P("HighlightText", text="The economy grew fast.", highlights=["grew fast"])
        c = _common(p)
        self.camera.background_color = c["bg"]
        t = Text(p["text"], **_style(p))
        t.scale_to_fit_width(config.frame_width - 2)
        self.play(Write(t), run_time=1.5)
        anims = []
        for needle in p["highlights"]:
            idx = p["text"].find(needle)
            if idx < 0:
                continue
            span = t[idx:idx + len(needle)]
            box = BackgroundRectangle(span, color=c["accent"], buff=0.06, fill_opacity=0.9)
            anims.append((box, span))
        for box, span in anims:
            self.play(GrowFromEdge(box, LEFT), run_time=0.5)
            self.play(span.animate.set_color(BLACK), run_time=0.2)
        self.wait(c["hold"])


class WordFocus(Scene):
    """Zoom in on one word while the rest dims — the classic Vox emphasis beat.
    Params: text, focus (exact substring), scale (default 1.6)."""
    def construct(self):
        p = P("WordFocus", text="One word changes everything.", focus="word", scale=1.6)
        c = _common(p)
        self.camera.background_color = c["bg"]
        t = Text(p["text"], **_style(p))
        self.add(t)
        idx = p["text"].find(p["focus"])
        if idx < 0:
            self.wait(c["hold"]); return
        word = t[idx:idx + len(p["focus"])]
        rest = VGroup(t[:idx], t[idx + len(p["focus"]):])
        self.play(rest.animate.set_opacity(0.15),
                  word.animate.scale(p["scale"]).set_color(c["accent"]),
                  run_time=1.0)
        self.play(Indicate(word, color=c["accent"]))
        self.wait(c["hold"])


class MapRoute(Scene):
    """Animated journey on a map: dashed route, pulsing markers, step labels.
    Params:
      map_image (path, optional)  background map image; omitted -> abstract grid
      points (list of [x,y])      normalized 0..1 coords, origin top-left
      labels (list of str)        one per point (optional)
    """
    def construct(self):
        p = P("MapRoute", map_image=None, points=[[0.2, 0.7], [0.5, 0.4], [0.8, 0.6]],
              labels=["Start", "", "End"])
        c = _common(p)
        self.camera.background_color = c["bg"]
        W, H = config.frame_width - 1, config.frame_height - 1
        if p.get("map_image") and os.path.exists(p["map_image"]):
            bg = ImageMobject(p["map_image"]).set_opacity(0.6)
            bg.scale_to_fit_width(W)
        else:
            bg = VGroup(*[DashedLine(LEFT * W / 2 + UP * y, RIGHT * W / 2 + UP * y,
                                     stroke_opacity=0.15)
                          for y in [i * H / 8 - H / 2 for i in range(9)]])
        self.add(bg)

        def to_scene(nx, ny):
            return np.array([(nx - 0.5) * W, (0.5 - ny) * H, 0])

        pts = [to_scene(*q) for q in p["points"]]
        route = VMobject(color=c["accent"], stroke_width=6)
        route.set_points_smoothly(pts)
        dashed = DashedVMobject(route, num_dashes=60)
        labels = p.get("labels") or [""] * len(pts)
        dots = []
        for pt, lab in zip(pts, labels):
            dot = Dot(pt, color=c["accent"])
            dots.append(dot)
            self.play(FadeIn(dot, scale=0.3), run_time=0.3)
            self.play(dot.animate.scale(1.6).set_opacity(0.5), run_time=0.25)
            dot.scale(1 / 1.6).set_opacity(1)
            if lab:
                t = Text(lab, **_style(p)).scale(0.5).next_to(dot, UP, buff=0.15)
                self.play(FadeIn(t), run_time=0.3)
        self.play(Create(dashed), run_time=2.0, rate_func=linear)
        self.wait(c["hold"])


class AnimatedChart(Scene):
    """Bars growing with a counting number. Hand-built (no LaTeX). Params:
      labels (list of str), values (list of float), unit (optional suffix)."""
    def construct(self):
        p = P("AnimatedChart", labels=["1990", "2020"], values=[10, 80], unit="")
        c = _common(p)
        fg = p.get("fg", WHITE)
        self.camera.background_color = c["bg"]
        vals, labels = p["values"], p["labels"]
        vmax = max(vals)
        n = len(vals)
        plot_w, plot_h = config.frame_width - 5, config.frame_height - 3.5
        origin = DOWN * plot_h / 2
        x_axis = Line(LEFT * plot_w / 2, RIGHT * plot_w / 2, color=fg).shift(origin)
        self.play(Write(x_axis), run_time=0.6)
        bars, lab_texts = VGroup(), VGroup()
        slot = plot_w / n
        for i, (v, lab) in enumerate(zip(vals, labels)):
            h = plot_h * v / (vmax * 1.15)
            bar = Rectangle(width=slot * 0.55, height=h, fill_color=c["accent"],
                            fill_opacity=1, stroke_width=0)
            bar.move_to(origin + UP * h / 2 + RIGHT * ((i + 0.5) * slot - plot_w / 2))
            bars.add(bar)
            t = Text(str(lab), **_style(p)).scale(0.45).next_to(bar, DOWN, buff=0.15)
            lab_texts.add(t)
        tracker = ValueTracker(0)
        counter = always_redraw(lambda: Text(f"{tracker.get_value():.0f}",
                                             **{**_style(p), "color": c["accent"]}
                                             ).scale(1.5).to_corner(UR))
        self.play(LaggedStart(*[GrowFromEdge(b, DOWN) for b in bars], lag_ratio=0.2),
                  LaggedStart(*[FadeIn(t) for t in lab_texts], lag_ratio=0.2),
                  tracker.animate.set_value(vmax),
                  Write(counter), run_time=2.2)
        if p.get("unit"):
            unit = Text(p["unit"], **_style(p)).scale(0.6).next_to(counter, RIGHT)
            self.play(FadeIn(unit))
        self.wait(c["hold"])


class QuoteCard(Scene):
    """Pull-quote on a torn-paper card. Params: quote, source."""
    def construct(self):
        p = P("QuoteCard", quote="It was the best of times.", source="— Dickens")
        c = _common(p)
        self.camera.background_color = c["bg"]
        card = RoundedRectangle(width=config.frame_width - 3, height=3.5,
                                corner_radius=0.15, color="#F5F0E1",
                                fill_color="#F5F0E1", fill_opacity=1)
        card.set_shadow = None
        q_style = {**_style(p), "color": BLACK}
        q = Text(f"“{p['quote']}”", **q_style).scale(0.8)
        q.scale_to_fit_width(card.width - 1)
        s = Text(p["source"], **{**_style(p), "color": GREY}).scale(0.5)
        s.next_to(q, DOWN, buff=0.4)
        grp = VGroup(card, q, s)
        self.play(FadeIn(card, shift=UP * 0.3), run_time=0.6)
        self.play(Write(q), run_time=1.5)
        self.play(FadeIn(s))
        self.wait(c["hold"])


class PaperCutout(Scene):
    """Photo/diagram popping onto the background like a paper cutout with a
    slight wobble — Vox's scrapbook feel. Params: image (path), caption (optional)."""
    def construct(self):
        p = P("PaperCutout", image="", caption="")
        c = _common(p)
        self.camera.background_color = c["bg"]
        if p.get("image") and os.path.exists(p["image"]):
            img = ImageMobject(p["image"])
        else:
            img = Square(side_length=3, fill_color=GREY, fill_opacity=1)  # placeholder
        border = SurroundingRectangle(img, color="#F5F0E1", buff=0.15,
                                      fill_color="#F5F0E1", fill_opacity=1)
        grp = VGroup(border, img)
        grp.scale_to_fit_height(config.frame_height - 2.5)
        self.play(FadeIn(grp, scale=0.6), run_time=0.5)
        self.play(grp.animate.rotate(0.04), run_time=0.15)
        self.play(grp.animate.rotate(-0.04), run_time=0.15)
        if p.get("caption"):
            cap = Text(p["caption"], **_style(p)).scale(0.5).next_to(grp, DOWN, buff=0.3)
            self.play(FadeIn(cap, shift=UP * 0.1))
        self.wait(c["hold"])
