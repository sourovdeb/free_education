#!/usr/bin/env python3
"""Stitch rendered Manim/Blender clips into a final video with ffmpeg.

Usage:
    python3 assemble_video.py manifest.json -o final.mp4

manifest.json:
{
  "clips": ["media/.../TitleCard.mp4", "media/.../MapRoute.mp4"],
  "narration": "voiceover.mp3",        // optional, ducked under nothing
  "music": "bgm.mp3",                  // optional, mixed at -22 dB under narration
  "crossfade": 0.0                     // seconds of xfade between clips (0 = hard cut)
}
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stderr[-2000:], file=sys.stderr)
        sys.exit(1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("-o", "--output", default="final.mp4")
    args = ap.parse_args()
    with open(args.manifest, encoding="utf-8") as f:
        m = json.load(f)
    clips = m["clips"]
    for c in clips:
        if not os.path.exists(c):
            sys.exit(f"missing clip: {c}")

    tmp = tempfile.mkdtemp()
    if m.get("crossfade", 0) > 0 and len(clips) > 1:
        # chain xfades (requires ffmpeg >= 4.4); keep simple: hard cut fallback note
        print("note: crossfade uses xfade; all clips must share resolution/fps", file=sys.stderr)
    # concat via list (hard cuts; uniform codec from manim makes this safe)
    listfile = os.path.join(tmp, "list.txt")
    with open(listfile, "w") as f:
        for c in clips:
            f.write(f"file '{os.path.abspath(c)}'\n")
    silent = os.path.join(tmp, "video.mp4")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", listfile,
         "-c", "copy", silent])

    audio_inputs, filter_parts, mix = [], [], None
    if m.get("narration"):
        audio_inputs += ["-i", m["narration"]]
        filter_parts.append(f"[{len(audio_inputs)//2}:a]loudnorm[nar]")
        mix = "[nar]"
    if m.get("music"):
        audio_inputs += ["-i", m["music"]]
        idx = len(audio_inputs) // 2
        filter_parts.append(f"[{idx}:a]volume=-22dB[mus]")
        mix += "[mus]"
    if mix:
        fc = ";".join(filter_parts) + f";{mix}amix=inputs={len(audio_inputs)//2}:duration=first[aout]"
        run(["ffmpeg", "-y", "-i", silent, *audio_inputs, "-filter_complex", fc,
             "-map", "0:v", "-map", "[aout]", "-c:v", "copy", "-shortest", args.output])
    else:
        run(["ffmpeg", "-y", "-i", silent, "-c", "copy", args.output])
    print(f"done -> {args.output}")

if __name__ == "__main__":
    main()
