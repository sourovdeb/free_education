"""Headless Blender: 3D book/page reveal shot for chapter openers.

Run (only when check_tools.py reports blender OK):

    blender -b -P blender_book_reveal.py -- '{"text": "Chapter 3", "out": "book.mp4", "frames": 60}'

Renders a slow camera push-in on a hardcover book whose cover title is the
given text — a signature Vox-style 3D beat between Manim segments.
Args JSON fields: text, out (mp4 path), frames (default 60), width/height.
"""
import json
import sys

import bpy
from mathutils import Vector

argv = sys.argv[sys.argv.index("--") + 1:]
cfg = json.loads(argv[0]) if argv else {}
TEXT = cfg.get("text", "Chapter 1")
OUT = cfg.get("out", "book.mp4")
FRAMES = cfg.get("frames", 60)
W, H = cfg.get("width", 1920), cfg.get("height", 1080)

scene = bpy.context.scene
scene.frame_start, scene.frame_end = 1, FRAMES
scene.render.resolution_x, scene.render.resolution_y = W, H
scene.render.fps = 24
scene.render.image_settings.file_format = "FFMPEG"
scene.render.ffmpeg.format = "MPEG4"
scene.render.filepath = OUT
scene.render.engine = "BLENDER_EEVEE_NEXT" if hasattr(bpy.types, "EEVEE") or bpy.app.version >= (4, 0, 0) else "BLENDER_EEVEE"

# --- book: two boards + pages block ---
def cube(name, loc, scale, mat):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o = bpy.context.object
    o.name, o.scale = name, scale
    o.data.materials.append(mat)
    bpy.ops.object.shade_smooth()
    return o

def material(name, color, rough=0.5):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = rough
    return m

cover_mat = material("cover", (0.55, 0.07, 0.07), 0.35)   # deep red cloth
page_mat = material("pages", (0.92, 0.88, 0.78), 0.8)
gold_mat = material("gold", (0.95, 0.75, 0.2), 0.25)

cube("cover_top", (0, 0, 0.12), (1.55, 1.05, 0.05), cover_mat)
cube("cover_bottom", (0, 0, -0.12), (1.55, 1.05, 0.05), cover_mat)
cube("pages", (0, 0, 0), (1.45, 0.95, 0.09), page_mat)
cube("spine", (-1.55, 0, 0), (0.06, 1.05, 0.13), cover_mat)

# --- title text on cover ---
bpy.ops.object.text_add(location=(0, -0.2, 0.18), rotation=(0, 0, 0))
txt = bpy.context.object
txt.data.body = TEXT
txt.data.align_x, txt.data.align_y = "CENTER", "CENTER"
txt.data.size = 0.35
txt.data.extrude = 0.01
txt.data.materials.append(gold_mat)

# --- lighting: one warm key + cool fill (documentary mood) ---
def area(name, loc, energy, color, size=5):
    bpy.ops.object.light_add(type='AREA', location=loc)
    l = bpy.context.object
    l.name, l.data.energy, l.data.color, l.data.shape, l.data.size = name, energy, color, 'DISK', size
    # point at origin
    direction = Vector((0, 0, 0)) - l.location
    l.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    return l

area("key", (3, -3, 5), 800, (1.0, 0.85, 0.7))
area("fill", (-4, 2, 3), 400, (0.6, 0.75, 1.0))

# --- camera push-in ---
bpy.ops.object.camera_add(location=(0, -7.5, 4.5))
cam = bpy.context.object
cam.rotation_euler = (Vector((0, 0, 0)) - cam.location).to_track_quat('-Z', 'Y').to_euler()
cam.data.lens = 50
scene.camera = cam
cam.location = (0, -7.5, 4.5); cam.keyframe_insert("location", frame=1)
cam.location = (0, -4.2, 2.2); cam.keyframe_insert("location", frame=FRAMES)
for fc in cam.animation_data.action.fcurves:
    for kp in fc.keyframe_points:
        kp.interpolation = 'BEZIER'

# dark backdrop world
scene.world = bpy.data.worlds.new("dark") if not scene.world else scene.world
scene.world.use_nodes = True
scene.world.node_tree.nodes["Background"].inputs[0].default_value = (0.02, 0.02, 0.03, 1)

bpy.ops.render.render(animation=True)
print(f"rendered -> {OUT}")
