#!/usr/bin/env python3
"""Environment scanner for the vox-visual-storytelling skill.

Checks every local tool the pipeline depends on and prints a JSON report.
Run FIRST, before any scene work:

    python3 check_tools.py            # human-readable report
    python3 check_tools.py --json     # machine-readable only
    python3 check_tools.py --install  # print install commands for what's missing

Exit code 0 if the core pipeline (manim + ffmpeg) is usable, 1 otherwise.
"""
import importlib.util
import json
import shutil
import subprocess
import sys

def has_module(name):
    return importlib.util.find_spec(name) is not None

def has_bin(name):
    return shutil.which(name) is not None

def version_of(cmd):
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (out.stdout or out.stderr).strip().splitlines()[0]
    except Exception:
        return None

def check():
    report = {"core": {}, "optional": {}, "fonts": {}, "ok": True}

    # --- core ---
    manim_ok = has_module("manim")
    ver = None
    if manim_ok:
        try:
            import manim
            ver = manim.__version__
        except Exception as e:
            manim_ok, ver = False, f"import error: {e}"
    report["core"]["manim"] = {"ok": manim_ok, "version": ver,
        "install": "pip install manim  (needs system cairo+pango; on Debian/Ubuntu: apt install libcairo2-dev libpango1.0-dev pkg-config; no-root alternative: micromamba create -p ./env -c conda-forge manim)"}

    ff = has_bin("ffmpeg")
    report["core"]["ffmpeg"] = {"ok": ff, "version": version_of(["ffmpeg", "-version"]) if ff else None,
        "install": "apt install ffmpeg  |  micromamba install -c conda-forge ffmpeg"}

    # --- optional ---
    blender = has_bin("blender")
    report["optional"]["blender"] = {"ok": blender, "version": version_of(["blender", "--version"]) if blender else None,
        "install": "download from blender.org (portable tarball works without root) or apt install blender; skill works without it — Blender only adds 3D title/book shots"}

    report["optional"]["latex"] = {"ok": has_bin("latex") or has_bin("tectonic"),
        "install": "only needed for manim MathTex; plain Text() scenes do not need it"}

    report["optional"]["pillow"] = {"ok": has_module("PIL"), "install": "pip install pillow"}

    # --- fonts (manim Text needs a CJK font for non-Latin scripts) ---
    try:
        out = subprocess.run(["fc-list"], capture_output=True, text=True, timeout=20).stdout
    except Exception:
        out = ""
    report["fonts"]["cjk"] = {"ok": any(k in out for k in ("CJK", "WenQuanYi", "Noto Sans SC", "Source Han")),
        "install": "install Noto Sans CJK / Source Han fonts for Chinese text"}
    report["fonts"]["serif_display"] = {"ok": "Playfair" in out or "Georgia" in out or "Noto Serif" in out}

    report["ok"] = all(v["ok"] for v in report["core"].values())
    return report

if __name__ == "__main__":
    rep = check()
    if "--json" in sys.argv:
        print(json.dumps(rep, indent=2))
    else:
        for section in ("core", "optional", "fonts"):
            print(f"[{section}]")
            for name, info in rep[section].items():
                mark = "OK " if info.get("ok") else "MISS"
                extra = f" ({info['version']})" if info.get("version") else ""
                print(f"  {mark} {name}{extra}")
                if not info.get("ok") and ("--install" in sys.argv) and info.get("install"):
                    print(f"       -> {info['install']}")
        print("PIPELINE READY" if rep["ok"] else "PIPELINE BLOCKED: fix core tools above")
    sys.exit(0 if rep["ok"] else 1)
