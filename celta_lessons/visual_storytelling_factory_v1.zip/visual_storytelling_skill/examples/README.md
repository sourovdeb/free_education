# Example Flow

1. Run preflight.
2. Place chapter text.
3. Make beats.
4. Map treatments.
5. Reuse templates.
6. Render previews.
7. Check outputs.
8. Approve finals.

No example renders ship.
The build host lacks engines.
