# Visual Storytelling Factory

Use this skill for books.
Use it for chapters.
Use it for documentaries.

It targets small models.
It keeps state on disk.
It reuses proven scripts.
It scans tools first.

Primary engines:

- Manim
- Blender
- FFmpeg

Optional editor:

- DaVinci Resolve

Start here:

```text
SKILL.md
scripts/preflight.py
config/default.json
library/templates.json
```

Then read these templates:

```text
templates/manim/vox_book.py
templates/blender/vox_book.py
```

## Current environment check

The build machine lacks Manim.
The build machine lacks Blender.
It has FFmpeg.
It has ImageMagick.
It has Inkscape.
It has Node.
It has Git.

Your Windows PC may differ.
Run the preflight there.

## Design basis

The method follows the reference.
It uses map zooms.
It uses document highlights.
It uses chart reveals.
It uses word changes.
It uses paper movement.
It uses sound timing.

It adds chapter logic.
It adds local preflight.
It adds script reuse.
It adds cache hashes.
It adds QC gates.
