---
name: visual-storytelling-factory
version: 1.0.0
platforms: [windows, linux, macos]
description: >-
  Turn book chapters into reusable visual stories.
  Use Manim for 2D motion.
  Use Blender for 3D shots.
  Use ffmpeg for assembly.
  Preflight local tools first.
  Reuse saved scene scripts.
---

# Visual Storytelling Factory

## Mission

Turn chapter text into shots.
Preserve the source meaning.
Use motion with purpose.
Prefer reusable scene scripts.
Keep each shot editable.

## Core rule

Narration controls timing.
Meaning controls shot changes.
One sentence needs no shot.
Change shots when meaning changes.

## Run order

1. Run `preflight.py`.
2. Read `preflight.json`.
3. Load chapter source.
4. Create semantic beats.
5. Map beats to shots.
6. Reuse known templates.
7. Build missing scripts.
8. Render low resolution.
9. Run visual checks.
10. Render final output.
11. Save reusable changes.

## Small-model protocol

Use state files only.
Do not resend chapters.
Do not resend shot lists.
Do not rewrite working scripts.
Change only needed fields.
Use stable shot IDs.
Log every new template.

Use these files:

```text
project.json
chapter.txt
beats.json
shots.json
render_log.json
```

## Preflight

Preflight must inspect these tools:

```text
python
manim
blender
ffmpeg
ffprobe
inkscape
magick
node
npm
git
resolve
nvidia-smi
```

Check PATH first.
Check common Windows paths.
Check Python module imports.
Check Blender version.
Check Manim version.
Check FFmpeg version.
Check GPU visibility.
Check writable output paths.

Never claim availability.
Use command results only.

Missing tools must block.
Optional tools must degrade.
Never auto-install by default.

## Tool roles

| Task | Preferred tool |
|---|---|
| Text motion | Manim |
| Diagrams | Manim |
| Maps | Manim + SVG |
| Charts | Manim |
| Timelines | Manim |
| Word swaps | Manim |
| Paper layers | Manim |
| 3D objects | Blender |
| 3D camera | Blender |
| 3D environments | Blender |
| Object parallax | Blender |
| Compositing | ffmpeg |
| Timeline edit | Resolve |

Resolve is optional.
FFmpeg remains fallback.

## Visual grammar

Use documentary motion.
Keep motion directional.
Use zooms sparingly.
Use highlight blocks.
Use drawn paths.
Use focused labels.
Use source images.
Use restrained charts.
Use paper-like layers.
Use readable typography.

Avoid decorative motion.
Avoid random camera moves.
Avoid dense overlays.
Avoid tiny text.
Avoid needless cuts.

## Reference-video translation

The reference uses several patterns.

### Pattern: map reveal

Start with context.
Zoom toward one place.
Trace the target region.
Move toward related places.
Add a connector line.

Manim implementation:

```text
MapImage
CropFrame
HighlightPath
PulseDot
ConnectorArc
CameraFrame
```

### Pattern: document highlight

Show the document.
Push toward the passage.
Isolate key words.
Reveal a highlight bar.
Move to another phrase.

Manim implementation:

```text
DocumentCard
FocusRect
HighlightBar
TextCutout
CameraFrame
```

### Pattern: chart reveal

Introduce the topic.
Show the source cue.
Draw the axis.
Draw the series.
Label the change.

### Pattern: word change

Keep the word anchored.
Swap surrounding sources.
Keep alignment fixed.
Use rapid cuts.

### Pattern: paper transition

Move a grouped card.
Keep the next card hidden.
Reveal with one motion.

### Pattern: image to subject

Start with context.
Zoom toward subject.
Separate subject layers.
Move the subject.
Add a small label.

### Pattern: sound cue

Match sounds to motion.
Use short effects.
Use one music bed.
Keep narration clear.

The reference uses these ideas.
It does not dictate software.

## Chapter analysis

First extract structure.
Use these beat types:

```text
claim
scene
person
place
event
process
comparison
cause_effect
timeline
statistic
quote
metaphor
turning_point
question
conclusion
```

Each beat needs fields:

```json
{
  "id": "b03",
  "start": 42.0,
  "end": 49.5,
  "type": "cause_effect",
  "summary": "One cause changes one outcome.",
  "source": "chapter.txt",
  "visual_need": "relationship diagram"
}
```

Do not invent evidence.
Mark interpretation as interpretation.
Keep quotes source-bound.

## Shot selection

Use this order:

```text
1. Reuse exact template.
2. Reuse close template.
3. Combine templates.
4. Create new template.
```

Assign one treatment:

```text
MAP_ZOOM
DOC_HIGHLIGHT
CHART_REVEAL
WORD_CHANGE
TIMELINE
CAUSE_EFFECT
COMPARISON
QUOTE_CARD
PHOTO_PUSH
OBJECT_PARALLAX
SCENE_3D
PAPER_COLLAGE
```

## Shot contract

Every shot needs:

```json
{
  "id": "s07",
  "beat_id": "b03",
  "duration": 7.5,
  "engine": "manim",
  "template": "cause_effect",
  "assets": [],
  "motion": {},
  "text": {},
  "source": {},
  "status": "planned"
}
```

Keep IDs stable.
Keep filenames stable.

## Template registry

Use `library/templates.json`.

Each entry records:

```text
id
engine
purpose
inputs
outputs
script
version
last_tested
```

Never duplicate templates blindly.
Update the registry instead.

## Asset policy

Search local assets first.
Reuse existing GLB files.
Reuse existing PNG files.
Reuse existing SVG files.
Reuse existing textures.

Record asset paths.
Record source URLs.
Record licenses when known.

Do not browse by default.
External assets need approval.

## Manim rules

Prefer Cairo rendering.
Prefer deterministic coordinates.
Keep helper functions small.
Use named groups.
Keep camera behavior explicit.

Avoid heavy 3D scenes.
Avoid OpenGL requirements.
Avoid unnecessary LaTeX.

Use these helpers:

```text
fade_in_group
wipe_highlight
zoom_to_box
pulse_dot
draw_connector
reveal_chart
swap_word
paper_move
source_label
```

See `templates/manim/vox_book.py`.

## Blender rules

Use Blender for real 3D.
Keep camera shots simple.
Use low polygon assets.
Reuse materials.
Reuse lighting rigs.
Reuse camera rigs.

Prefer Eevee.
Use simple shadows.
Use depth sparingly.

Store master files separately.
Never overwrite source masters.

See `templates/blender/vox_book.py`.

## Visual continuity

Keep one project style.
Keep one font system.
Keep one spacing system.
Keep one paper system.
Keep one label system.

Define them in `config/default.json`.

## Rendering

Render a preview first.
Use small dimensions first.
Render only changed shots.
Reuse unchanged outputs.

Hash these inputs:

```text
source text
shot JSON
template script
asset paths
config
```

Use the hash for cache keys.

## QC

Check every render.

```text
file exists
file opens
correct duration
correct frame rate
correct dimensions
no black frame
no missing asset
no clipped text
no accidental overlap
source label present
```

Do not mark passed.
Use measured checks.

## Failure handling

If Manim is missing:
Use Blender or ffmpeg.

If Blender is missing:
Use Manim or stills.

If both are missing:
Create plans only.

If FFmpeg is missing:
Keep separate outputs.

If a template fails:
Try one repair.
Then report the blocker.

Never fake a render.
Never hide a missing tool.

## Reuse rule

A working shot becomes library code.

After approval:

```text
copy script
extract constants
remove chapter-specific text
parameterize assets
parameterize timing
add registry entry
add one test
```

Do not create duplicates.

## Book chapter output

Create:

```text
chapter_slug/
  00_source/
  01_plan/
  02_assets/
  03_manim/
  04_blender/
  05_preview/
  06_final/
  07_logs/
```

Required files:

```text
project.json
beats.json
shots.json
render_log.json
README.md
```

## Approval gate

Planning can run automatically.
Rendering can be preview-only.
Final render needs approval.

Never publish automatically.
Never replace source files.

## Compact execution prompt

Use this with small models:

```text
Load VISUAL STORYTELLING FACTORY.
Run preflight first.
Read preflight.json only.
Load project.json.
Load beats.json.
Load shots.json.
Reuse registered templates.
Create missing templates only.
Render changed shots only.
Run QC.
Write render_log.json.
Stop at final approval.
```

## Source

Reference video:

```text
https://youtu.be/O1rMZkk7fBE
```

Video title:

```text
Create a VOX style Documentary in Canva
```

The source demonstrates maps.
It also demonstrates highlights.
It demonstrates charts and swaps.
It demonstrates layered transitions.
It demonstrates sound cues.
