# Changelog

## 1.0.0

Added tool preflight.
Added chapter state files.
Added Manim templates.
Added Blender templates.
Added cache guidance.
Added shot contracts.
Added QC checks.
Added small-model protocol.
Added reference-video mapping.
