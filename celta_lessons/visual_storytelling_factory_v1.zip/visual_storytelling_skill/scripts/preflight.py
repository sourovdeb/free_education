#!/usr/bin/env python3
"""Local tool audit for Visual Storytelling Factory."""
from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

TOOLS = [
    "python", "manim", "blender", "ffmpeg", "ffprobe", "inkscape",
    "magick", "node", "npm", "git", "resolve", "nvidia-smi"
]

WINDOWS_PATHS = {
    "blender": [
        r"C:\\Program Files\\Blender Foundation",
        r"C:\\Program Files (x86)\\Blender Foundation",
        r"C:\\Users\\%USERNAME%\\AppData\\Local\\Programs",
    ],
    "ffmpeg": [
        r"C:\\ffmpeg\\bin",
        r"C:\\ProgramData\\chocolatey\\bin",
    ],
    "inkscape": [
        r"C:\\Program Files\\Inkscape\\bin",
    ],
    "magick": [
        r"C:\\Program Files\\ImageMagick-*",
    ],
}


def run_cmd(cmd: list[str]) -> tuple[bool, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        out = (p.stdout or p.stderr).strip().splitlines()
        return p.returncode == 0, out[0] if out else ""
    except Exception as exc:
        return False, type(exc).__name__


def first_on_path(name: str) -> str | None:
    return shutil.which(name)


def find_common_windows_binary(name: str) -> str | None:
    if platform.system() != "Windows":
        return None
    roots = WINDOWS_PATHS.get(name, [])
    for raw in roots:
        expanded = os.path.expandvars(raw)
        for p in Path(expanded).glob(name + ".exe"):
            return str(p)
        for p in Path(expanded).glob("*/" + name + ".exe"):
            return str(p)
        for p in Path(expanded).glob("*/bin/" + name + ".exe"):
            return str(p)
    return None


def main() -> int:
    report: dict = {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "tools": {},
        "python_modules": {},
        "gpu": {},
        "status": "UNKNOWN",
    }

    for name in TOOLS:
        path = first_on_path(name)
        if not path:
            path = find_common_windows_binary(name)
        ok, version = run_cmd([path, "--version"] if path else []) if path else (False, "")
        report["tools"][name] = {
            "found": bool(path),
            "path": path,
            "version_check_ok": ok,
            "version": version,
        }

    for module in ["manim", "numpy", "PIL", "moviepy", "cairosvg"]:
        report["python_modules"][module] = bool(importlib.util.find_spec(module))

    nvidia = report["tools"]["nvidia-smi"]
    if nvidia["found"]:
        ok, out = run_cmd([nvidia["path"], "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"])
        report["gpu"] = {"query_ok": ok, "summary": out}
    else:
        report["gpu"] = {"query_ok": False, "summary": "not found"}

    required = {
        "python": report["tools"]["python"]["found"],
        "ffmpeg": report["tools"]["ffmpeg"]["found"],
    }
    engines = {
        "manim": report["tools"]["manim"]["found"] and report["python_modules"]["manim"],
        "blender": report["tools"]["blender"]["found"],
    }

    report["required_ok"] = all(required.values())
    report["engine_availability"] = engines
    report["can_make_plan"] = required["python"]
    report["can_render_2d"] = engines["manim"]
    report["can_render_3d"] = engines["blender"]
    report["can_assemble"] = report["tools"]["ffmpeg"]["found"]

    if report["can_render_2d"] or report["can_render_3d"]:
        report["status"] = "READY_WITH_OPTIONAL_GAPS"
    elif report["can_make_plan"]:
        report["status"] = "PLAN_ONLY"
    else:
        report["status"] = "BLOCKED"

    out_path = Path.cwd() / "preflight.json"
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
