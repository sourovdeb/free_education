#!/usr/bin/env python3
"""Create stable state files for a chapter project."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path


def slugify(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return text or "chapter"


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: chapter_scaffold.py <chapter title> [folder]")
        return 2
    title = sys.argv[1]
    root = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(slugify(title))
    for name in ["00_source","01_plan","02_assets","03_manim","04_blender","05_preview","06_final","07_logs"]:
        (root / name).mkdir(parents=True, exist_ok=True)

    files = {
        "project.json": {"chapter": title, "status":"planning", "tool_preflight":"preflight.json"},
        "beats.json": [],
        "shots.json": [],
        "render_log.json": [],
    }
    for name, data in files.items():
        p = root / name
        if not p.exists():
            p.write_text(json.dumps(data, indent=2), encoding="utf-8")
    (root / "README.md").write_text(f"# {title}\n\nState is kept on disk.\n", encoding="utf-8")
    print(root.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
