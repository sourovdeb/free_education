"""Reusable Manim effects for book storytelling.

Render examples with:
    manim -pqh vox_book.py MapZoomDemo
"""
from __future__ import annotations

from manim import *


ACCENT = "#F4C430"
PAPER = "#EEE7D7"
INK = "#202124"
ALERT = "#C83C3C"


def source_label(text: str) -> VGroup:
    box = RoundedRectangle(corner_radius=0.08, width=3.2, height=0.42)
    box.set_fill(PAPER, 1).set_stroke(width=0)
    label = Text(text, color=INK, font_size=16)
    label.move_to(box.get_center())
    return VGroup(box, label)


def highlight_bar(target: Mobject, color=ACCENT, opacity=0.75) -> Rectangle:
    bar = Rectangle(width=target.width + 0.18, height=target.height + 0.12)
    bar.set_fill(color, opacity).set_stroke(width=0)
    bar.move_to(target)
    return bar


def pulse_dot(point, color=ALERT) -> Dot:
    return Dot(point, radius=0.09, color=color)


def connector(a: Mobject, b: Mobject) -> ArcBetweenPoints:
    return ArcBetweenPoints(a.get_center(), b.get_center(), angle=-0.35, stroke_width=5, color=ACCENT)


def paper_card(title: str, body: str = "", width: float = 5.4) -> VGroup:
    card = Rectangle(width=width, height=3.2)
    card.set_fill(PAPER, 1).set_stroke(INK, 2)
    head = Text(title, color=INK, font_size=30)
    head.move_to(card.get_top() + DOWN * 0.45)
    parts = [card, head]
    if body:
        body_m = Paragraph(body, color=INK, font_size=17, line_spacing=0.75)
        body_m.move_to(card.get_center() + DOWN * 0.25)
        parts.append(body_m)
    return VGroup(*parts)


class MapZoomDemo(Scene):
    def construct(self):
        self.camera.background_color = INK
        title = Text("MAP CONTEXT", color=PAPER, font_size=42)
        grid = NumberPlane(x_range=[-7,7,1], y_range=[-4,4,1], background_line_style={"stroke_opacity":0.18})
        grid.set_color(PAPER)
        dot = pulse_dot(ORIGIN)
        self.play(FadeIn(title, shift=UP * 0.2), FadeIn(grid))
        self.play(FadeIn(dot), run_time=0.5)
        self.play(self.camera.frame.animate.scale(0.65).move_to(dot), run_time=1.6)
        self.play(Indicate(dot, color=ALERT), run_time=0.7)
        self.wait(1)


class DocumentHighlightDemo(Scene):
    def construct(self):
        self.camera.background_color = INK
        card = paper_card("SOURCE DOCUMENT", "A source paragraph appears here.")
        self.play(FadeIn(card), run_time=0.7)
        phrase = card[2] if len(card) > 2 else card[1]
        bar = highlight_bar(phrase)
        bar.shift(LEFT * 0.6)
        self.play(FadeIn(bar), run_time=0.6)
        self.play(bar.animate.shift(RIGHT * 1.2), run_time=1.1)
        self.wait(0.5)


class ChartRevealDemo(Scene):
    def construct(self):
        self.camera.background_color = INK
        axes = Axes(x_range=[0, 5, 1], y_range=[0, 6, 1], x_length=7, y_length=4)
        axes.set_color(PAPER)
        line = axes.plot(lambda x: 0.6 * x**2, x_range=[0, 3.0], color=ACCENT)
        label = Text("TREND", color=PAPER, font_size=38).to_edge(UP)
        self.play(Write(label), Create(axes), run_time=1.0)
        self.play(Create(line), run_time=1.7)
        self.play(Indicate(line), run_time=0.8)
        self.wait(0.8)


class WordChangeDemo(Scene):
    def construct(self):
        self.camera.background_color = INK
        anchor = Rectangle(width=4.4, height=1.2).set_stroke(ACCENT, 5)
        words = VGroup(*[Text(w, color=PAPER, font_size=54) for w in ["power", "status", "fear", "trust"]])
        words.arrange(DOWN, buff=0.4).move_to(ORIGIN)
        self.add(anchor)
        self.play(FadeIn(words[0]))
        for old, new in zip(words, words[1:]):
            new.move_to(old)
            self.play(TransformMatchingShapes(old, new), run_time=0.28)
        self.wait(0.7)


class CauseEffectDemo(Scene):
    def construct(self):
        self.camera.background_color = INK
        a = paper_card("CAUSE", "A changes B.", 3.8)
        b = paper_card("OUTCOME", "B changes C.", 3.8)
        a.to_edge(LEFT)
        b.to_edge(RIGHT)
        line = connector(a, b)
        self.play(FadeIn(a), FadeIn(b))
        self.play(Create(line), run_time=0.9)
        self.play(Indicate(a), Indicate(b), run_time=0.7)
        self.wait(0.8)


class TimelineDemo(Scene):
    def construct(self):
        self.camera.background_color = INK
        axis = Line(LEFT * 6, RIGHT * 6, color=PAPER)
        labels = [Text(x, color=PAPER, font_size=24) for x in ["A", "B", "C", "D"]]
        for i, label in enumerate(labels):
            label.move_to(LEFT * 4.5 + RIGHT * i * 3)
        dots = [Dot(p, color=ACCENT) for p in [LEFT * 4.5, LEFT * 1.5, RIGHT * 1.5, RIGHT * 4.5]]
        self.play(Create(axis))
        for dot, label in zip(dots, labels):
            self.play(FadeIn(dot), Write(label), run_time=0.5)
        self.wait(0.8)
