"""Reusable Blender helpers.

Run inside Blender's Python API.
"""
from __future__ import annotations

import bpy
import math


PAPER = (0.85, 0.80, 0.68, 1.0)
INK = (0.02, 0.02, 0.025, 1.0)
ACCENT = (0.95, 0.70, 0.08, 1.0)


def clear_scene() -> None:
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)


def make_material(name: str, rgba) -> bpy.types.Material:
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.diffuse_color = rgba
    return mat


def add_paper_card(name: str, size=(5.0, 3.0, 0.08), location=(0, 0, 0)):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = size
    obj.data.materials.append(make_material("Paper", PAPER))
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return obj


def add_camera(name="Camera", location=(0, -8, 5)):
    bpy.ops.object.camera_add(location=location)
    cam = bpy.context.object
    cam.name = name
    cam.rotation_euler = (math.radians(63), 0, 0)
    bpy.context.scene.camera = cam
    return cam


def add_soft_light(name="Key", location=(2, -4, 7), energy=900):
    data = bpy.data.lights.new(name=name, type="AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = 6
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    return obj


def setup_eevee():
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = 1280
    scene.render.resolution_y = 720
    scene.render.resolution_percentage = 50
    scene.render.fps = 25


def simple_parallax_demo():
    clear_scene()
    setup_eevee()
    cam = add_camera()
    add_soft_light()
    add_paper_card("BackCard", location=(0, 0.5, 0))
    front = add_paper_card("FrontCard", size=(3.4, 2.0, 0.1), location=(0.6, -0.1, 0.35))
    front.keyframe_insert(data_path="location", frame=1)
    front.location.x += 1.0
    front.keyframe_insert(data_path="location", frame=40)
    cam.keyframe_insert(data_path="location", frame=1)
    cam.location.y += 0.6
    cam.keyframe_insert(data_path="location", frame=40)


if __name__ == "__main__":
    simple_parallax_demo()
