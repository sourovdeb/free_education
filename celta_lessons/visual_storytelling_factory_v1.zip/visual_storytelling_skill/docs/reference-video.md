# Reference Video Notes

Source:

https://youtu.be/O1rMZkk7fBE

Title:

Create a VOX style Documentary in Canva

The video shows:

- 16:9 documentary framing.
- Grid-based title design.
- Layered title elements.
- Map reveal transitions.
- Map zooms.
- Hand-drawn map borders.
- Highlighted map points.
- Connector lines.
- Newspaper layers.
- Highlighted words.
- Population chart reveals.
- Rapid word changes.
- Image-to-subject moves.
- Layered paper movement.
- Marker sound effects.
- Paper sound effects.
- One music bed.

Adaptation rule:

Use the ideas.
Do not copy Canva UI.
Do not require Canva.

Implementation mapping:

| Reference pattern | Manim | Blender |
|---|---|---|
| map zoom | camera frame | camera rig |
| border draw | Create path | Grease Pencil optional |
| dot pulse | Dot + scale | emissive object |
| connector line | ArcBetweenPoints | Curve |
| document highlight | Rectangle | plane layer |
| chart reveal | Axes + graph | geometry nodes optional |
| word change | TransformMatchingShapes | text objects |
| paper move | VGroup transform | keyframes |
| subject reveal | image masks | 3D object |
| sound cue | timeline export | timeline marker |
