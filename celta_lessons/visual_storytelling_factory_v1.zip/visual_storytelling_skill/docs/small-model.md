# Small Model Operating Guide

Keep context local.
Use stable IDs.
Use one task per turn.

## State contract

The model reads:

```text
preflight.json
project.json
beats.json
shots.json
library/templates.json
```

The model writes:

```text
shots.json
render_log.json
```

Template code stays stable.

## Planning turn

Return only these fields:

```text
beat_id
treatment
template
engine
duration
assets
source_note
```

## Build turn

Open one template.
Change parameters only.
Save chapter-specific code.
Register new reusable logic.

## Render turn

Render changed shots.
Read measured QC.
Stop on failures.

## Resume turn

Read `render_log.json`.
Find failed shot IDs.
Repair only those shots.

This avoids context growth.
