from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def test_preflight_writes_json(tmp_path):
    r = subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "preflight.py")],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert r.returncode == 0
    data = json.loads((tmp_path / "preflight.json").read_text(encoding="utf-8"))
    assert "tools" in data
    assert "engine_availability" in data
    assert "status" in data
