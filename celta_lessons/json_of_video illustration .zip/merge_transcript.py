#!/usr/bin/env python3
"""Fill audio.transcript_segments in every frame_XX.json from a real transcript.

Usage:
  python merge_transcript.py TRANSCRIPT.(srt|vtt|json) [--dir .] [--pad 6]

TRANSCRIPT formats: .srt, .vtt, or .json (a list of {start,end,text} or {"segments":[...]}, seconds).
Frames with an exact timestamp get [t-pad, t+pad]; frames with an estimated window get that window.
Frames whose window is open-ended (end = null) are flagged needs_manual_timestamp instead of guessed.
"""
import argparse, glob, json, os, re

TS = re.compile(r"(?:(\d+):)?(\d+):(\d+)[.,](\d+)")


def to_sec(m):
    h, mi, s, ms = m.groups()
    return int(h or 0) * 3600 + int(mi) * 60 + int(s) + int(ms.ljust(3, "0")[:3]) / 1000


def load(path):
    if path.endswith(".json"):
        data = json.load(open(path, encoding="utf-8"))
        segs = data["segments"] if isinstance(data, dict) else data
        return [{"start": float(s["start"]), "end": float(s["end"]), "text": s["text"].strip()} for s in segs]
    out, text = [], open(path, encoding="utf-8-sig").read()
    for block in re.split(r"\n\s*\n", text):
        lines = [l for l in block.strip().splitlines() if l.strip()]
        for i, l in enumerate(lines):
            if "-->" in l:
                a, b = l.split("-->")[:2]
                ma, mb = TS.search(a), TS.search(b)
                body = re.sub(r"<[^>]+>", "", " ".join(lines[i + 1:])).strip()
                if ma and mb and body:
                    out.append({"start": to_sec(ma), "end": to_sec(mb), "text": body})
                break
    dedup = []                       # YouTube auto-captions repeat rolling lines
    for s in out:
        if dedup and (s["text"] == dedup[-1]["text"] or s["text"].startswith(dedup[-1]["text"])):
            dedup[-1].update(end=s["end"], text=s["text"])
        elif not dedup or not dedup[-1]["text"].endswith(s["text"]):
            dedup.append(s)
    return dedup


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("transcript")
    ap.add_argument("--dir", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--pad", type=float, default=6.0)
    a = ap.parse_args()
    segs = load(a.transcript)
    for p in sorted(glob.glob(os.path.join(a.dir, "frame_*.json"))):
        d = json.load(open(p, encoding="utf-8"))
        v = d["video"]
        if v["timestamp_seconds"] is not None:
            lo, hi = v["timestamp_seconds"] - a.pad, v["timestamp_seconds"] + a.pad
        else:
            lo, hi = v["estimated_window_seconds"]
        au = d["audio"]
        if hi is None:
            au["needs_manual_timestamp"] = True
            au["transcript_segments"] = []
        else:
            au.pop("needs_manual_timestamp", None)
            au["window_used_seconds"] = [max(lo, 0), hi]
            au["transcript_segments"] = [s for s in segs if s["end"] >= lo and s["start"] <= hi]
            au["extractable_from_screenshot"] = False
            au["source_of_segments"] = os.path.basename(a.transcript)
        json.dump(d, open(p, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
        print(d["frame_id"], "segments:", len(au["transcript_segments"]), "manual" if hi is None else "")


if __name__ == "__main__":
    main()
