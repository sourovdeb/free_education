# Safe WordPress Operations — candidate review

Identity: M40 / mishu-wordpress-operations / 2.0.0.

## Source boundary
Origin: upgraded-from-inspected-source-content.
Source IDs: REGISTRY10, REGISTRY11, REGISTRY12, REGISTRY14, REGISTRY15, REGISTRY16, L18, W7. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
RESTRUCTURE / focused consolidation: Replaces brittle deployment gateways and database shortcuts with current, staged and verified site operations.

Preserved outcome: Create or repair approved WordPress content and operational changes with current interface checks, staged validation and a recoverable result.

## Silent failure to prevent
The old note tells the agent to POST arbitrary PHP to deploy.php.
Required handling: Do not assume that unsafe route is authorized or valid; choose a supported scoped administration route.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
