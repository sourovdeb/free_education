# Evidence Dossier and Complaint Drafter — candidate review

Identity: M45 / mishu-evidence-dossier / 2.0.0.

## Source boundary
Origin: upgraded-from-inspected-source-content.
Source IDs: REGISTRY17, REGISTRY18, REGISTRY19, REGISTRY20, REGISTRY21, REGISTRY22, REGISTRY24, L04, MASTER. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
RESTRUCTURE / focused consolidation: Reconstructs the registry’s complaint activities as evidence-first drafting with current-rule verification, not preset breach conclusions.

Preserved outcome: Organize records into a clear, source-linked account and a proportionate complaint or information request without inventing legal conclusions.

## Silent failure to prevent
An old skill states that a fixed indicator or deadline always applies.
Required handling: Verify the current authoritative rule before using it; do not carry over the unsupported statement.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
