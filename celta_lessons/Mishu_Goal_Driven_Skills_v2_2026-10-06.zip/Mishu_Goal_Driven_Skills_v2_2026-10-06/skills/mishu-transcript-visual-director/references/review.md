# Transcript-to-Visual Teaching Director — candidate review

Identity: M32 / mishu-transcript-visual-director / 2.0.0.

## Source boundary
Origin: upgraded-from-inspected-source-content.
Source IDs: PROJECT, S002. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
RESTRUCTURE / focused consolidation: Adds meaning-led visual variety, two-thirds layout and a reusable cue contract for non-reasoning hosts.

Preserved outcome: Create a visually engaging, transcript-linked teaching or reading video plan in which graphics support meaning and leave the presenter’s space clear.

## Silent failure to prevent
The transcript contains no numerical data, but the model creates a rising success-rate chart.
Required handling: Replace the fabricated chart with a qualitative comparison.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
