# Project Library and Knowledge Curator — candidate review

Identity: M42 / mishu-project-library-curator / 2.0.0.

## Source boundary
Origin: upgraded-from-inspected-source-content.
Source IDs: L16, REGISTRY40, MASTER, PROJECT. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
RESTRUCTURE / focused consolidation: Adds honest source coverage, content-based deduplication and a resumable goal index.

Preserved outcome: Maintain a compact, traceable project library so future sessions can find the correct source, reuse work and resume without invented memory.

## Silent failure to prevent
A newer file is titled COMPLETE but contains only a placeholder.
Required handling: Inspect content and do not replace a substantive earlier file based on the title alone.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
