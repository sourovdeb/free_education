# Career Application Workflow — candidate review

Identity: M43 / mishu-career-application-workflow / 2.0.0.

## Source boundary
Origin: reconstructed-from-registry.
Source IDs: L24, REGISTRY01, REGISTRY02, REGISTRY03, REGISTRY08, W3. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
REBUILD / description-to-operational-specification: Preserves the original one-application acceptance target and replaces stale career assumptions with verified facts.

Preserved outcome: Produce one truthful, relevant application for a verified opportunity and advance to submission only within the user’s actual authorization.

## Silent failure to prevent
The old profile claims an awarded qualification whose current status is unknown.
Required handling: Do not repeat the award claim until current evidence supports it.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
