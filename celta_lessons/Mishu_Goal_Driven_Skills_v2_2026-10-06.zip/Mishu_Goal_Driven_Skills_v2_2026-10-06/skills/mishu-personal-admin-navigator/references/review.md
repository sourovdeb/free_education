# Personal Administration Navigator — candidate review

Identity: M47 / mishu-personal-admin-navigator / 2.0.0.

## Source boundary
Origin: reconstructed-from-registry.
Source IDs: REGISTRY30, REGISTRY31, REGISTRY32, MASTER. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
REBUILD / description-to-operational-specification: Replaces stale personal-admin rules with current-form mapping, privacy and truthful declarations.

Preserved outcome: Help the user assemble the correct current administrative dossier with the least unnecessary burden, preserving privacy and factual accuracy.

## Silent failure to prevent
An old note says every medical certificate must be less than three months old.
Required handling: Check the specific current official form requirements instead of repeating the old rule.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
