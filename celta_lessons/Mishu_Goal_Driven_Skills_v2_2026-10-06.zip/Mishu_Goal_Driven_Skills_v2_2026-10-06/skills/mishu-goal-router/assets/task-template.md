# Task brief — Goal and Delivery Router

Desired outcome:
Source/input and version:
Audience and language:
Requested scope and output:
Protected text/facts/canon:
Available tools (verified, unknown or unavailable):
Resource/spending limit:
External actions authorized (none unless specified):
Acceptance criteria:

The skill supplies default method and quality checks. Omit nonessential fields rather than inventing their contents.

## Checkpoint after a real run
Completed source units:
Actual output paths/object IDs:
Checks actually performed:
Remaining gaps:
Next unit/action:
Source/host changes requiring revalidation:
