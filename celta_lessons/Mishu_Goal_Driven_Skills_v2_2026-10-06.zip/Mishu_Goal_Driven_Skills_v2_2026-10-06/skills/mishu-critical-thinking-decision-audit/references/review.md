# Critical Thinking and Decision Audit — candidate review

Identity: M03 / mishu-critical-thinking-decision-audit / 2.0.0.

## Source boundary
Origin: upgraded-from-inspected-source-content.
Source IDs: L01, L02, L03, MASTER. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
RESTRUCTURE / focused consolidation: Merges compact, full and domain variants while retaining evidence/action separation and appropriate stopping rules.

Preserved outcome: Help the user form a defensible judgment and select a feasible next action without confusing evidence, preferences and speculation.

## Silent failure to prevent
The user requests an exact confidence percentage from two ambiguous messages.
Required handling: Decline invented precision and describe the actual evidential limits.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
