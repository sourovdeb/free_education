# Research Manuscript and Preprint Publisher — candidate review

Identity: M48 / mishu-research-publication / 2.0.0.

## Source boundary
Origin: reconstructed-from-registry.
Source IDs: REGISTRY25, REGISTRY26, REGISTRY27, MASTER. Resolve archive/registry IDs in the bundle's sources catalog; source IDs are provenance, not hidden runtime dependencies.
The source archive was inspected through indexed excerpts and catalog entries, not recovered byte for byte. Registry items are activity descriptions, not complete implementations. S001 and S002 are full recovered text exports. Do not claim a line-by-line migration of every upstream file.

## Architecture and substantive change
REBUILD / description-to-operational-specification: Adds actual-method, rights and publication-state integrity to the academic/preprint activities.

Preserved outcome: Prepare a defensible research manuscript or preprint package whose methods, evidence, authorship and repository status are accurately represented.

## Silent failure to prevent
The model claims HAL has accepted the paper before a deposit tool is called.
Required handling: Remove the claim and keep status NOT_SUBMITTED.

## Design checks
The core explicitly specifies a goal, activation boundary, input contract, preflight, domain method, acceptance criteria, output, fallback, stopping/resumption and a bounded small-model route. This is a design review, not empirical proof of reliability.

## Remaining validation
Six concrete cases are supplied in evals/cases.json. No baseline output, live model trial, independent craft review or target-host integration was executed for this candidate. Those cases remain NOT_RUN. Utility tests elsewhere in this bundle do not validate this skill's model behavior.

## Release
work_status: REVIEWED
validation: STATIC_ONLY
approval: NOT_REQUESTED
deployment: NOT_DEPLOYED
Target-specific claims: TARGET_UNVERIFIED.

## Revalidation triggers
Changed source or canon; changed provider or tool version; new permission/spending scope; a preservation or quality failure; host metadata/loading change. Keep original results and failed cases, patch the narrow cause, then rerun affected cases.
