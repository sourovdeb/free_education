# Source-to-upgrade coverage

This is a coverage map, not a claim that all remote files were recovered. Archive text was inspected through indexed excerpts. The 42 older registry entries describe activities; their new workflows are reconstructed specifications, not tested ports of unseen scripts.

## Original 27-row archive

| Source ID | Canonical entry | Disposition | Target skill IDs |
|---|---|---|---|
| L01 | `critical-thinking-agent-instructions.txt` | merged | M03 |
| L02 | `critical-thinking-and-decision-audit.md` | consolidated | M03 |
| L03 | `critical-thinking-operating-procedure-domain.txt` | merged | M03 |
| L04 | `rigorous-analysis.md` | consolidated | M04 |
| L05 | `rigorous-analysis-invocation.txt` | merged | M04 |
| L06 | `deep-online-investigation.md` | consolidated | M05 |
| L07 | `deep-online-search-framework.txt` | merged | M05 |
| L08 | `deep-research-agent-instruction.md` | merged | M05 |
| L09 | `hermes-memoir-daily-interview.md` | consolidated | M20, M21 |
| L10 | `humanizer.md` | corrected | M22 |
| L11 | `memoir-writer-session-notes.txt` | merged | M20, M21 |
| L12 | `mishu-writer-os.txt` | decomposed | M08, M09, M10, M12, M16, M17, M19, M20, M21 |
| L13 | `narrative-skills-engine-sudowrite-portfolio.md` | decomposed | M09, M10, M11, M12, M13, M14, M15, M17, M18, M19, M23 |
| L14 | `writer-system-story-development.md` | consolidated | M08, M15, M17, M18, M19 |
| L15 | `writer-system-architecture.txt` | merged | M08, M09, M19 |
| L16 | `writing-skills-repos-status.csv` | reference-only | M42 |
| L17 | `elt365-micro-lesson-writer.md` | corrected | M25 |
| L18 | `open-teacher-training-website-section.md` | decomposed | M26, M27 |
| L19 | `open-teacher-training-website-section.duplicate.md` | duplicate-of-L18 | M27 |
| L20 | `weekly-book-reading-prosody-3b-draft.txt` | capability-mode | M29 |
| L21 | `weekly-book-reading-omni-v1.md` | superseded-mode-merged | M29 |
| L22 | `weekly-book-reading-omni-v2.md` | capability-mode | M29 |
| L23 | `weekly-book-reading-mistral-small-v2.md` | capability-mode | M29 |
| L24 | `teaching-job-search-restart-start-here.md` | career-route-reconstructed | M43 |
| L25 | `cambridge-appeal-stage1-stage2-2026.zip` | excluded-private-evidence | None — excluded |
| L26 | `agnes-api-credentials.REDACTED.txt` | excluded-credentials | None — excluded |
| L27 | `narrative-skills-engine-sudowrite-portfolio-pack.zip` | binary-not-recovered-text-counterpart-L13-used | M23 |

## Additional 42-activity registry

| ID | Original activity | Reconstructed target IDs |
|---|---|---|
| REGISTRY01 | Bilingual CV and letter | M43 |
| REGISTRY02 | Verified job opportunities | M43 |
| REGISTRY03 | Targeted French application email | M43, M44 |
| REGISTRY04 | Gmail send deduplication | M44 |
| REGISTRY05 | Verified contact discovery | M44 |
| REGISTRY06 | Apps Script batch sender | M39 |
| REGISTRY07 | Bounce analysis | M44 |
| REGISTRY08 | Career email archaeology | M43, M44 |
| REGISTRY09 | Bounded scheduled applications | M39, M43 |
| REGISTRY10 | WordPress plugin deployment | M40 |
| REGISTRY11 | WP-Cron diagnosis | M40 |
| REGISTRY12 | WordPress REST publishing | M40 |
| REGISTRY13 | ELT generation workflow | M26, M36, M38 |
| REGISTRY14 | SEO metadata | M40 |
| REGISTRY15 | Content scheduling | M36, M40 |
| REGISTRY16 | Plugin activation | M40 |
| REGISTRY17 | Multi-jurisdiction dossier | M45 |
| REGISTRY18 | UK education complaint | M45 |
| REGISTRY19 | French administrative complaint | M45 |
| REGISTRY20 | Adjustment/disclosure evidence | M45 |
| REGISTRY21 | Data-access request | M45 |
| REGISTRY22 | Assessment-record audit | M45 |
| REGISTRY23 | Evidence translation | M46 |
| REGISTRY24 | Qualiopi compliance mapping | M45 |
| REGISTRY25 | Research manuscript | M06, M48 |
| REGISTRY26 | Preprint deposit | M48 |
| REGISTRY27 | Citation verification | M06, M48 |
| REGISTRY28 | Research to video | M32, M36 |
| REGISTRY29 | Research to blog | M26, M36 |
| REGISTRY30 | Administrative application forms | M47 |
| REGISTRY31 | Supporting medical records | M47 |
| REGISTRY32 | Education/experience pathways | M47 |
| REGISTRY33 | Apps Script runtime | M39 |
| REGISTRY34 | Persistent tracking state | M39 |
| REGISTRY35 | Timezone and triggers | M39 |
| REGISTRY36 | External API integration | M37, M38, M39 |
| REGISTRY37 | File type and archive intake | M41 |
| REGISTRY38 | Markdown to PDF | M41 |
| REGISTRY39 | DOCX extraction | M41 |
| REGISTRY40 | Project knowledge index | M42 |
| REGISTRY41 | Bilingual content pipeline | M28, M36 |
| REGISTRY42 | Institutional outreach | M44, M46 |

## Scope exclusions

The personal appeal evidence ZIP and credentials are excluded. The original portfolio binary was not recovered; its inspected Markdown counterpart informed the writing modules. The external writing-repository CSV is a historical reference, not evidence that those repositories were audited or remain current. Native app skill installations, the full GitHub tree and Box libraries were not rewritten.
