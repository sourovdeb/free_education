#!/usr/bin/env python3
"""Static checks for this bundle. Not a semantic/model/host certification.

The frontmatter reader supports only the narrow format emitted by this bundle.
It is not a general YAML parser and it does not replace the official skills-ref tool.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REQUIRED=['Goal','Activation and boundaries','Inputs','Preflight and authority','Method','Quality and acceptance','Output contract','Failure and recovery','Small-model and no-install route','Worked acceptance example','Release status']

def frontmatter(text: str) -> dict:
    if not text.startswith('---\n') or '\n---\n' not in text[4:]:
        raise ValueError('Missing frontmatter delimiters')
    raw=text.split('\n---\n',1)[0][4:]
    result={}; meta={}; inmeta=False
    for line in raw.splitlines():
        if line=='metadata:': inmeta=True; continue
        if ':' not in line: raise ValueError('Unsupported frontmatter line')
        key,value=line.strip().split(':',1); value=value.strip()
        if not value: raise ValueError('Empty frontmatter field')
        value=json.loads(value) if value.startswith('"') else value
        if inmeta and line.startswith('  '): meta[key]=value
        elif not line.startswith(' '): result[key]=value; inmeta=False
        else: raise ValueError('Unsupported indentation')
    result['metadata']=meta
    return result

def validate(root: Path) -> dict:
    errors=[]; checks=0
    def check(ok: bool, message: str) -> None:
        nonlocal checks
        checks+=1
        if not ok: errors.append(message)
    try:
        catalog=json.loads((root/'catalog.json').read_text(encoding='utf-8'))
        skills=catalog['skills']; names=[s['slug'] for s in skills]
        check(len(skills)==48 and catalog['count']==len(skills),'Skill count mismatch')
        check(len(names)==len(set(names)),'Duplicate skill names')
        cov=json.loads((root/'sources/source_coverage.json').read_text(encoding='utf-8'))
        check([r['id'] for r in cov['archive']]==[f'L{i:02d}' for i in range(1,28)],'Archive coverage IDs mismatch')
        check([r['id'] for r in cov['registry']]==[f'REGISTRY{i:02d}' for i in range(1,43)],'Registry coverage IDs mismatch')
        for row in cov['archive']+cov['registry']:
            check(all(t in names for t in row['targets']),f"Invalid coverage target {row['id']}")
            if row['id'] not in {'L25','L26'}:
                check(bool(row['targets']),f"Unmapped non-excluded source {row['id']}")
        sc=json.loads((root/'sources/source_catalog.json').read_text(encoding='utf-8'))
        valid_sources=set(sc)|{r['id'] for r in cov['archive']+cov['registry']}
        behavior_cases=0
        for s in skills:
            slug=s['slug']; folder=root/'skills'/slug
            text=(folder/'SKILL.md').read_text(encoding='utf-8')
            fm=frontmatter(text)
            check(bool(re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',slug)) and len(slug)<=64,f'Bad slug {slug}')
            check(fm.get('name')==slug,f'Name/directory mismatch {slug}')
            check(isinstance(fm.get('description'),str) and 0<len(fm['description'])<=1024,f'Bad description {slug}')
            check(fm['metadata'].get('version')=='2.0.0',f'Bad metadata {slug}')
            check(all(isinstance(k,str) and isinstance(v,str) for k,v in fm['metadata'].items()),f'Non-string metadata {slug}')
            check(len(text.splitlines())<500,f'Overlong SKILL.md {slug}')
            for h in REQUIRED: check('## '+h+'\n' in text,f'Missing {h}: {slug}')
            check(len(s['method'])>=7 and len(s['checks'])>=3,f'Insufficient method/check data {slug}')
            check(all(x in valid_sources for x in s['sources']),f'Unknown provenance ID {slug}')
            p=root/'prompts'/(slug+'.md')
            check(p.is_file() and len(p.read_text(encoding='utf-8'))>2000,f'Missing standalone prompt {slug}')
            ev=json.loads((folder/'evals/cases.json').read_text(encoding='utf-8'))
            check(ev['suite_status']=='NOT_RUN',f'False model-test status {slug}')
            check(len(ev['cases'])==6 and len({c['id'] for c in ev['cases']})==6,f'Cases mismatch {slug}')
            behavior_cases+=len(ev['cases'])
            for c in ev['cases']:
                check(c['status']=='NOT_RUN' and bool(c['input']) and bool(c['expected']),f'Invalid case {slug}/{c["id"]}')
            check(s['validation']=='STATIC_ONLY' and s['deployment']=='NOT_DEPLOYED',f'False release status {slug}')
        for p in root.rglob('*'):
            if '__pycache__' in p.parts: continue
            check(not p.is_symlink(),f'Symlink in package: {p}')
            if p.is_file():
                check(p.stat().st_size>0,f'Empty file: {p}')
                check(p.suffix.lower() not in {'.ttf','.otf','.woff','.woff2','.pyc'},f'Unneeded binary/font: {p}')
            if p.is_file() and p.suffix=='.md':
                for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
                    if target.startswith(('http:','https:','#','mailto:')): continue
                    check((p.parent/target.split('#',1)[0]).exists(),f'Broken relative link in {p.relative_to(root)}: {target}')
        # Non-comprehensive accidental-secret scan. This is not a security certification.
        secret=re.compile(r'(?i)\b(?:sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{20,}|AIza[A-Za-z0-9_-]{25,})')
        for p in root.rglob('*'):
            if '__pycache__' in p.parts or p.suffix not in {'.md','.txt','.json','.py','.html','.csv'}: continue
            check(not secret.search(p.read_text(encoding='utf-8')),f'Potential secret in {p.relative_to(root)}')
        mf=root/'MANIFEST.sha256'
        if mf.exists():
            entries={}
            for line in mf.read_text(encoding='utf-8').splitlines():
                digest,rel=line.split('  ',1)
                entries[rel]=digest
                path=root/rel
                check(path.is_file(),f'Manifest missing {rel}')
                if path.is_file(): check(hashlib.sha256(path.read_bytes()).hexdigest()==digest,f'Hash mismatch {rel}')
            actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.sha256' and '__pycache__' not in p.parts and p.suffix!='.pyc'}
            check(set(entries)==actual,'Manifest membership mismatch')
        return {'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,'skills':len(skills),'standalone_prompts':len(skills),'designed_model_cases':behavior_cases,'model_cases_executed':0,'scope':'Package structure, local links, source mapping, narrow frontmatter and optional file hashes. Not semantic or host validation.'}
    except (OSError,ValueError,KeyError,TypeError) as exc:
        return {'status':'ERROR','checks':checks,'errors':errors+[str(exc)],'scope':'Static package checks only'}

def main()->int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT)
    args=p.parse_args(); result=validate(args.root)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
