#!/usr/bin/env python3
"""Validate exact source-block preservation. Python 3.10+, standard library only.

Input documents: {"blocks": [{"id": "P01-S01", "text": "Exact source."}, ...]}
The source must enumerate the entire intended scope. No normalization is performed.
This checks text fidelity, not rendered layout, pronunciation or semantic quality.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any

MAX_BYTES = 20_000_000
MAX_BLOCKS = 100_000

def load_blocks(path: Path) -> list[dict[str, str]]:
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Not a regular non-symlink input: {path}")
    if path.stat().st_size > MAX_BYTES:
        raise ValueError(f"Input exceeds {MAX_BYTES} bytes; split deliberately: {path}")
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    return validate_blocks(value)

def validate_blocks(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, dict) or not isinstance(value.get("blocks"), list):
        raise ValueError('Expected an object with a "blocks" list')
    blocks = value["blocks"]
    if not blocks or len(blocks) > MAX_BLOCKS:
        raise ValueError(f"Expected 1..{MAX_BLOCKS} source blocks")
    seen: set[str] = set()
    result: list[dict[str, str]] = []
    for i, b in enumerate(blocks):
        if not isinstance(b, dict) or not isinstance(b.get("id"), str) or not isinstance(b.get("text"), str):
            raise ValueError(f"Block {i}: id and text must be strings")
        if not b["id"].strip() or not b["text"].strip():
            raise ValueError(f"Block {i}: blank id or source text")
        if b["id"] in seen:
            raise ValueError(f"Duplicate block ID: {b['id']}")
        seen.add(b["id"])
        result.append({"id": b["id"], "text": b["text"]})
    return result

def compare(source: list[dict[str, str]], reader: list[dict[str, str]]) -> dict[str, Any]:
    # Revalidate direct callers as well as CLI inputs.
    source = validate_blocks({"blocks": source})
    reader = validate_blocks({"blocks": reader})
    src_ids = [b["id"] for b in source]
    got_ids = [b["id"] for b in reader]
    src = {b["id"]: b["text"] for b in source}
    got = {b["id"]: b["text"] for b in reader}
    missing = [x for x in src_ids if x not in got]
    extra = [x for x in got_ids if x not in src]
    changed = [x for x in src_ids if x in got and src[x] != got[x]]
    order_ok = src_ids == got_ids
    ok = not missing and not extra and not changed and order_ok
    return {"status": "PASS" if ok else "FAIL", "source_blocks": len(source),
            "reader_blocks": len(reader), "missing_ids": missing, "extra_ids": extra,
            "changed_ids": changed, "exact_order": order_ok,
            "scope": "Exact IDs, order and Unicode text only; no layout or semantic certification."}

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("reader", type=Path)
    args = p.parse_args()
    try:
        result = compare(load_blocks(args.source), load_blocks(args.reader))
    except (ValueError, OSError) as exc:
        print(json.dumps({"status": "ERROR", "message": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
