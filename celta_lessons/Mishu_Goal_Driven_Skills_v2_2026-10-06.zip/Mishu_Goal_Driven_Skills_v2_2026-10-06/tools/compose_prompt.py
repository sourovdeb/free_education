#!/usr/bin/env python3
"""Print one standalone prompt plus an optional task file. No network/model calls."""
from __future__ import annotations
import argparse
import re
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def compose(root: Path, skill: str, task: str = "") -> str:
    if len(skill) > 64 or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", skill):
        raise ValueError("Invalid skill name")
    path = root / "prompts" / (skill + ".md")
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Prompt not found: {skill}")
    return path.read_text(encoding="utf-8") + "\n\n---\n\n# User task and source\n\n" + task + "\n"

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("skill")
    p.add_argument("--task", type=Path)
    args=p.parse_args()
    try:
        if args.task and (not args.task.is_file() or args.task.is_symlink() or args.task.stat().st_size > 2_000_000):
            raise ValueError("Task must be a regular non-symlink UTF-8 file under 2 MB")
        task=args.task.read_text(encoding="utf-8-sig") if args.task else ""
        sys.stdout.write(compose(ROOT,args.skill,task))
    except (ValueError,OSError) as exc:
        print(str(exc),file=sys.stderr); return 2
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
