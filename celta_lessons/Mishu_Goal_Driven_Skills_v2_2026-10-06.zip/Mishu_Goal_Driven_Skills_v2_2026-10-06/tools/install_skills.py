#!/usr/bin/env python3
"""Copy selected skills to an explicit destination. Dry-run unless --apply.

Never overwrites or deletes. Does not install Python, providers or host software.
Local copies are not evidence that a host has loaded or successfully run a skill.
Do not run while an untrusted process can mutate the source/destination tree.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SLUG = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")

def reject_symlink_chain(path: Path) -> None:
    # Check before resolve(), which would hide a symlink in an ancestor.
    absolute = path.expanduser().absolute()
    for item in [absolute, *absolute.parents]:
        if item.is_symlink():
            raise ValueError(f"Symlink path component is not supported: {item}")

def prepare(root: Path, dest: Path, names: list[str]) -> list[tuple[Path, Path]]:
    if not names or len(names) != len(set(names)):
        raise ValueError("Select at least one unique skill")
    reject_symlink_chain(dest)
    dest = dest.expanduser().absolute()
    skill_root = (root / "skills").resolve()
    if dest == skill_root or skill_root in dest.parents:
        raise ValueError("Destination must not be inside this bundle's source skills")
    if dest.exists() and not dest.is_dir():
        raise ValueError("Destination is not a directory")
    plan = []
    for name in names:
        if len(name) > 64 or not SLUG.fullmatch(name):
            raise ValueError(f"Invalid skill name: {name!r}")
        src = skill_root / name
        if src.is_symlink() or not (src / "SKILL.md").is_file():
            raise ValueError(f"Missing or unsafe skill: {name}")
        for item in src.rglob("*"):
            if item.is_symlink():
                raise ValueError(f"Symlink source rejected: {item}")
            if not item.is_file() and not item.is_dir():
                raise ValueError(f"Special source file rejected: {item}")
        dst = dest / name
        if dst.exists() or dst.is_symlink():
            raise ValueError(f"Refusing to overwrite existing destination: {dst}")
        plan.append((src, dst))
    return plan

def digest_tree(folder: Path) -> dict[str, str]:
    return {p.relative_to(folder).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob("*")) if p.is_file()}

def install(root: Path, dest: Path, names: list[str], apply: bool = False) -> dict:
    plan = prepare(root, dest, names)
    report = {"mode": "APPLY" if apply else "DRY_RUN", "host_loaded": "UNVERIFIED",
              "entries": [{"source": str(s), "destination": str(d), "status": "PLANNED"} for s, d in plan]}
    if apply:
        for i, (src, dst) in enumerate(plan):
            try:
                # copytree refuses an existing folder even if created after preflight.
                shutil.copytree(src, dst, symlinks=False)
                if digest_tree(src) != digest_tree(dst):
                    raise OSError("Read-back hash mismatch")
                report["entries"][i]["status"] = "COPIED_AND_HASH_VERIFIED"
            except OSError as exc:
                report["entries"][i]["status"] = "FAILED_OR_PARTIAL"
                report["error"] = str(exc)
                # Keep exact state visible; never delete existing or partly copied user files.
                report["status"] = "PARTIAL"
                return report
    report["status"] = "COPIED" if apply else "PREVIEW_ONLY"
    return report

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dest", required=True, type=Path)
    selection = p.add_mutually_exclusive_group(required=True)
    selection.add_argument("--skill", action="append", help="Repeat to choose several skill names")
    selection.add_argument("--all", action="store_true", help="Explicitly select the whole bundle")
    p.add_argument("--apply", action="store_true", help="Actually copy; default is dry-run")
    args = p.parse_args()
    names = args.skill or sorted(p.name for p in (ROOT / "skills").iterdir() if p.is_dir())
    try:
        result = install(ROOT, args.dest, names, args.apply)
    except (ValueError, OSError) as exc:
        print(json.dumps({"status": "ERROR", "message": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if result["status"] == "PARTIAL" else 0

if __name__ == "__main__":
    raise SystemExit(main())
