# Skill catalog — choose by the result you need

48 focused skills. Use one at a time; helpers are optional, not a mandatory stack.

## 00 Standards

| ID | Skill | Goal |
|---|---|---|
| M01 | [Goal and Delivery Router](skills/mishu-goal-router/SKILL.md) | Turn an ordinary request into the smallest useful completed deliverable, selecting a specialist only when it improves the result. |
| M02 | [Skill Architect and Upgrade Doctor](skills/mishu-skill-architect/SKILL.md) | Improve an existing skill only where its behavior needs improvement, and deliver a traceable candidate with concrete tests and honest release status. |

## 01 Research

| ID | Skill | Goal |
|---|---|---|
| M03 | [Critical Thinking and Decision Audit](skills/mishu-critical-thinking-decision-audit/SKILL.md) | Help the user form a defensible judgment and select a feasible next action without confusing evidence, preferences and speculation. |
| M04 | [Rigorous Evidence and Argument Analysis](skills/mishu-rigorous-analysis/SKILL.md) | Identify exactly what is supported, contradicted, overstated or unproven in an argument or record, with traceable findings. |
| M05 | [Deep Online Investigation](skills/mishu-deep-online-investigation/SKILL.md) | Find and evaluate the strongest available evidence for a specific difficult research question, including obscure or historical material. |
| M06 | [Research Synthesis and Reference Audit](skills/mishu-research-synthesis-reference-audit/SKILL.md) | Produce an evidence-grounded synthesis or repair a draft’s citations without turning source lists into unsupported authority. |
| M07 | [YouTube Evidence and Bias Auditor](skills/mishu-youtube-evidence-auditor/SKILL.md) | Help the user decide what to learn from a video by locating checkable claims, verifying them and explaining both strengths and errors at the relevant moments. |

## 02 Writing

| ID | Skill | Goal |
|---|---|---|
| M08 | [Story Development Director](skills/mishu-story-development-director/SKILL.md) | Turn the user’s story fragments into a coherent story direction and the next usable scene without making them master fiction terminology first. |
| M09 | [Story Bible and Context Packer](skills/mishu-story-bible-context/SKILL.md) | Give a writing task exactly the relevant approved story facts, current state and voice constraints without flooding a small model or losing decisive context. |
| M10 | [Fiction Continuation](skills/mishu-fiction-continue/SKILL.md) | Continue a passage with a meaningful next movement while preserving viewpoint, tense, voice and established story state. |
| M11 | [Controlled Fiction Rewrite](skills/mishu-fiction-rewrite/SKILL.md) | Improve the requested surface of a passage while retaining its events, meaning and authorial decisions unless change is explicitly authorized. |
| M12 | [POV-Grounded Description](skills/mishu-fiction-description/SKILL.md) | Create specific descriptive choices that reveal the scene through the focal character rather than decorate it generically. |
| M13 | [Meaningful Scene Expansion](skills/mishu-fiction-expand/SKILL.md) | Lengthen or slow a selected narrative moment through meaningful action, perception and interior response while preserving its result. |
| M14 | [Purposeful Story Brainstorming](skills/mishu-fiction-brainstorm/SKILL.md) | Generate distinct usable possibilities that solve a stated story problem without displacing the author’s locked decisions. |
| M15 | [Scene Planner and Drafter](skills/mishu-scene-planner-drafter/SKILL.md) | Turn an approved story beat into a scene whose pressures, choices and consequences can be followed in engaging prose. |
| M16 | [Dialogue and Subtext Editor](skills/mishu-dialogue-editor/SKILL.md) | Make dialogue responsive, character-specific and purposeful while preserving who knows what and what the exchange accomplishes. |
| M17 | [Style Discovery and Voice Control](skills/mishu-style-discovery/SKILL.md) | Help the author choose and consistently apply observable prose qualities without pretending to infer a complete personal voice from insufficient evidence. |
| M18 | [Evidence-Based Editorial Feedback](skills/mishu-editorial-feedback/SKILL.md) | Identify the changes most likely to improve a manuscript for its intended reader, with exact locations and practical revision actions. |
| M19 | [Continuity and Canon Keeper](skills/mishu-continuity-canon/SKILL.md) | Detect and repair story-state contradictions while preserving a traceable distinction between approved canon, character belief and proposal. |
| M20 | [Memoir Interviewer](skills/mishu-memoir-interviewer/SKILL.md) | Collect the user’s own accounts through manageable non-leading questions and turn enough material into a faithful draft rather than an endless interview. |
| M21 | [Memoir Manuscript Builder](skills/mishu-memoir-manuscript/SKILL.md) | Assemble and revise a readable memoir from documented and remembered material while preserving uncertainty, privacy and the author’s intended meaning. |
| M22 | [Natural Prose Editor](skills/mishu-humanizer/SKILL.md) | Make prose clearer, more specific and less formulaic without changing its facts, uncertainty, intention or individual voice. |
| M23 | [Narrative Skill Benchmark and Portfolio](skills/mishu-narrative-benchmark/SKILL.md) | Test whether a skill improves defined writing tasks and present the actual evidence, including failures, without claiming proprietary parity. |
| M24 | [Mistral-Compatible Writing Director](skills/mishu-mistral-writing-director/SKILL.md) | Run a focused writing task through an available text host, preserving the same author, source and canon contract when providers or tools change. |

## 03 Teaching

| ID | Skill | Goal |
|---|---|---|
| M25 | [ELT365 Micro-Lesson Writer](skills/mishu-elt365-micro-lesson/SKILL.md) | Produce a compact teacher-learning unit with one correct idea, a concrete example and a short task that demonstrates learning. |
| M26 | [Teaching Materials and Methods Designer](skills/mishu-teaching-materials-methods/SKILL.md) | Create a lesson or teaching pack in which the learner practices an observable skill and can use feedback to improve. |
| M27 | [Teacher-Training Website Builder](skills/mishu-teacher-training-site/SKILL.md) | Create a navigable, honest training pathway with one complete usable pilot unit before expanding a public course. |
| M28 | [Lecture and Resource to Small Lessons](skills/mishu-lecture-to-lessons/SKILL.md) | Turn a long lecture, book section or old resource into coherent small lessons with source traceability, practice and corrections for outdated claims. |
| M29 | [Weekly Reading Sentence Laboratory](skills/mishu-weekly-reading-sentence-lab/SKILL.md) | Help the reader understand and perform every sentence in a chosen passage through meaningful prominence, pronunciation, thought groups and rehearsal. |
| M30 | [Audiobook Performance Coach](skills/mishu-audiobook-performance-coach/SKILL.md) | Transform a supplied book passage into faithful, separate reading and pronunciation scripts that a narrator can rehearse directly. |

## 04 Visual Media

| ID | Skill | Goal |
|---|---|---|
| M31 | [Faithful Book and Document Illumination](skills/mishu-faithful-book-illumination/SKILL.md) | Redesign the same supplied book or document with passage-linked visual explanations while preserving its text and reading order. |
| M32 | [Transcript-to-Visual Teaching Director](skills/mishu-transcript-visual-director/SKILL.md) | Create a visually engaging, transcript-linked teaching or reading video plan in which graphics support meaning and leave the presenter’s space clear. |
| M33 | [Resource-Aware Blender Storyboard Producer](skills/mishu-blender-storyboard-producer/SKILL.md) | Produce a readable, editable storyboard or short teaching animation with a tested lightweight route rather than an unnecessarily expensive scene. |
| M34 | [Reusable Storyboard Asset Librarian](skills/mishu-reusable-storyboard-assets/SKILL.md) | Build a practical, customizable asset-and-scene library whose items can be found, reused and recombined without recreating everything. |
| M35 | [Lightweight Video Editing Automator](skills/mishu-lightweight-video-editing/SKILL.md) | Automate a small set of repetitive editing tasks while protecting the source footage, timing, deliberate pauses and limited hardware resources. |
| M36 | [Educational Multichannel Publishing](skills/mishu-educational-publishing-pipeline/SKILL.md) | Turn one verified teaching or research unit into coherent blog, video and social drafts while keeping evidence, versions and release status aligned. |

## 05 Engineering

| ID | Skill | Goal |
|---|---|---|
| M37 | [Reusable Software Utility Builder](skills/mishu-software-utility-builder/SKILL.md) | Build or repair the smallest trustworthy utility that replaces repetitive work and can be tested and reused by a nontechnical operator. |
| M38 | [Provider and Capability Router](skills/mishu-provider-capability-router/SKILL.md) | Choose an available, authorized route for text, OCR, transcription or media work using current capabilities and cost information rather than hardcoded provider promises. |
| M39 | [Google Apps Script Automation Engineer](skills/mishu-apps-script-automation/SKILL.md) | Build a restartable, permission-bounded Apps Script workflow that performs verified operations without duplicate sends or hidden state loss. |
| M40 | [Safe WordPress Operations](skills/mishu-wordpress-operations/SKILL.md) | Create or repair approved WordPress content and operational changes with current interface checks, staged validation and a recoverable result. |
| M41 | [Document and File Workbench](skills/mishu-document-file-workbench/SKILL.md) | Read, transform and package files faithfully, preserving structure and verifying the actual delivered format. |
| M42 | [Project Library and Knowledge Curator](skills/mishu-project-library-curator/SKILL.md) | Maintain a compact, traceable project library so future sessions can find the correct source, reuse work and resume without invented memory. |

## 06 Career and Administration

| ID | Skill | Goal |
|---|---|---|
| M43 | [Career Application Workflow](skills/mishu-career-application-workflow/SKILL.md) | Produce one truthful, relevant application for a verified opportunity and advance to submission only within the user’s actual authorization. |
| M44 | [Verified Contacts and Outreach Mail](skills/mishu-verified-outreach-mail/SKILL.md) | Prepare or send relevant correspondence to verified recipients while preventing guessed addresses, duplicate effects and misleading delivery claims. |
| M45 | [Evidence Dossier and Complaint Drafter](skills/mishu-evidence-dossier/SKILL.md) | Organize records into a clear, source-linked account and a proportionate complaint or information request without inventing legal conclusions. |
| M46 | [Faithful Evidence Translation](skills/mishu-evidence-translation/SKILL.md) | Translate evidence faithfully across languages while preserving dates, attribution, qualifications and uncertainty for the intended reader. |
| M47 | [Personal Administration Navigator](skills/mishu-personal-admin-navigator/SKILL.md) | Help the user assemble the correct current administrative dossier with the least unnecessary burden, preserving privacy and factual accuracy. |
| M48 | [Research Manuscript and Preprint Publisher](skills/mishu-research-publication/SKILL.md) | Prepare a defensible research manuscript or preprint package whose methods, evidence, authorship and repository status are accurately represented. |

