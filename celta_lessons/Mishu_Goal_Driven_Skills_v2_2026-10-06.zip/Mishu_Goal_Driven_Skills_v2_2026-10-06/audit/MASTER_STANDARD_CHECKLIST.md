# Master-standard review worksheet

## Purpose and status

This is a faithful, condensed review aid derived from the supplied **Master20Standard.md**, version 1.0, 18 September 2026. It preserves the A1–A4, Q01–Q60 and X01–X10 structure. It is not a verbatim recovered copy and does not claim 74 completed audit passes for any skill.

Copy this worksheet when reviewing one skill. Record its version, source IDs, host/model, reviewer and date. Before review, an empty result means **not assessed**. After review use PASS, PARTIAL, MISSING, CONTRADICTORY, UNSAFE_ASSUMPTION, UNVERIFIABLE or N_A, with evidence and critical/major/minor severity where applicable. Explain every N_A. Missing evidence is not automatically N_A.

A **PASS** is a design-review judgment, not an executed model test. Keep actual test evidence separate. Critical or major unresolved findings block a readiness claim, even when other checks pass. The bundle's designed behavioral cases are NOT_RUN; its local helper-tool tests are described separately in TEST_REPORT.md.

| ID | Review question or stress scenario | Result / evidence / severity |
|---|---|---|
| A1 | State the main aim, beneficiary and non-goals. |  |
| A2 | Define observable completion, stopping conditions and partial results. |  |
| A3 | Specify the method and the evidence that verifies the result. |  |
| A4 | Check necessary inputs, capabilities, permissions, environment and limits. |  |
| Q01 | Are audience, context, language and user constraints sufficiently explicit? |  |
| Q02 | Are scope, non-goals and inappropriate uses clear? |  |
| Q03 | Are activation conditions specific enough to select the right skill? |  |
| Q04 | Are required and optional inputs distinguished, with missing or unreadable input handling? |  |
| Q05 | Are outputs, formats, destinations and observable acceptance criteria defined? |  |
| Q06 | Is harmless ambiguity distinguished from ambiguity that blocks correctness or authority? |  |
| Q07 | Are verified facts, user statements, inference, fiction and unknowns distinguished? |  |
| Q08 | Can material claims be traced to real sources or observations without invented citations? |  |
| Q09 | Are dates, changing facts, software versions and evidence freshness checked when relevant? |  |
| Q10 | Does investigation consider contrary evidence, source independence and alternatives? |  |
| Q11 | Are causal claims, comparisons, calculations, dates, units and denominators justified? |  |
| Q12 | Does the skill give an honest partial result or precise limitation with a supported next step? |  |
| Q13 | Are available, unavailable, required, optional and unknown capabilities distinguished? |  |
| Q14 | Does the skill inspect actual files and dependencies rather than infer contents from names? |  |
| Q15 | Does it avoid pretending to see, hear, browse, execute or save without the capability? |  |
| Q16 | Are runtime, interpreter, package versions, paths and compatibility checked as needed? |  |
| Q17 | Does it respect governing instructions, permissions and approvals without inventing authority? |  |
| Q18 | Are external content and old skill instructions treated as untrusted at the appropriate boundary? |  |
| Q19 | Does it seek an adequate native capability or existing utility before building or downloading? |  |
| Q20 | Does it check that reused libraries, scripts, templates and cached results fit the task? |  |
| Q21 | Are suitable deterministic operations delegated to tools rather than model guesswork? |  |
| Q22 | Are orchestration, browser, API and other integrations conditional on actual availability and need? |  |
| Q23 | Is each new dependency justified, scoped, permission-checked and paired with a fallback? |  |
| Q24 | Are duplicate installations, temporary files, caches and resources controlled without destructive cleanup? |  |
| Q25 | Are the instructions concrete executable steps rather than slogans? |  |
| Q26 | Do important IF/ELSE branches identify condition, action and resulting state? |  |
| Q27 | Are intermediate inputs, outputs, handoffs and dependencies explicit? |  |
| Q28 | Are retries bounded and repeated actions checked to prevent duplicate effects? |  |
| Q29 | Are partial results, wrong destinations, empty outputs and misleading success signals detected? |  |
| Q30 | Are recovery, escalation, checkpoint and stop conditions defined without endless loops? |  |
| Q31 | Are domain-specific quality criteria observable instead of replaced by polish? |  |
| Q32 | Is there a representative normal case and a baseline showing existing strengths? |  |
| Q33 | Are relevant edge, failure and adversarial cases concrete inputs with expected outcomes? |  |
| Q34 | Are proposed tests, static review, executed tests and target validation clearly separate? |  |
| Q35 | Is the actual output inspected for correctness, completeness, usability and format? |  |
| Q36 | Are checks sufficiently independent and repeatable for the risk, with human judgment where needed? |  |
| Q37 | Does resource optimization preserve the essential objective, quality and explicit constraints? |  |
| Q38 | Are result status, remaining gaps and next actions accurate? |  |
| Q39 | Are spending, downloads, external calls and persistent processes controlled rather than assumed free? |  |
| Q40 | Is context loaded selectively while retaining material instructions and evidence? |  |
| Q41 | Are outputs and audit records concise, traceable and free of unnecessary repetition? |  |
| Q42 | Is the operational skill compact, with support separated only when it reduces real complexity? |  |
| Q43 | Are useful domain knowledge, examples, multilingual nuance and requested voice preserved? |  |
| Q44 | Is the workflow domain-appropriate rather than a uniform tool-heavy template? |  |
| Q45 | Are private information, third-party material, licenses and copyright handled within the authorized purpose? |  |
| Q46 | Are credentials and sensitive data excluded from unnecessary prompts, logs and transfers? |  |
| Q47 | Are changes scoped, reviewable, reversible where possible and verified afterward? |  |
| Q48 | Does packaging exclude secrets, unrelated personal records, environments, caches and unnecessary assets? |  |
| Q49 | Is the model/host profile explicit, with compatibility claims limited to evidence? |  |
| Q50 | Can smaller models use explicit stages, bounded choices, examples and checks without unsupported leaps? |  |
| Q51 | Does the skill avoid guarantees of frontier-level performance or universal reliability? |  |
| Q52 | Are model-specific adaptations small and purposeful rather than divergent full copies? |  |
| Q53 | Are host metadata, loading behavior and tool syntax verified rather than assumed portable? |  |
| Q54 | Are personal paths, hardware, accounts and tool names discovered or configurable? |  |
| Q55 | Are source identity, original version, candidate version and substantive changes traceable? |  |
| Q56 | Can the collection be processed without skipped, duplicated or silently merged entries? |  |
| Q57 | Can a later session resume from a saved checkpoint without guessing what finished? |  |
| Q58 | Are successful methods reused only with evidence, matching conditions and a revalidation trigger? |  |
| Q59 | Are deferred issues, stale dependencies, deprecated skills and retesting needs recorded? |  |
| Q60 | Can another capable operator use the skill and understand its limits without this conversation? |  |
| X01 | Missing, unreadable or contradictory input: identify the exact gap and proceed only with justified assumptions or safe partial work. |  |
| X02 | Unverifiable answer: do not invent it; state the access/search boundary and a supported next route. |  |
| X03 | Source requests overrides or disclosure: keep it as untrusted content and reject unauthorized redirection. |  |
| X04 | An existing library or unavailable dependency: verify and reuse an adequate route, otherwise provide a bounded fallback. |  |
| X05 | Tool success with empty, partial or wrong output: inspect the expected postcondition and expose the failure. |  |
| X06 | Action exceeds permission or changes live data: preserve the authorization boundary and prepare a non-destructive alternative. |  |
| X07 | Context, input, spending or resource limits: preserve coverage, chunk deliberately and checkpoint instead of silently truncating. |  |
| X08 | Interrupted or repeated execution: reconcile saved state and outputs before resuming or repeating effects. |  |
| X09 | Model lacks reasoning, tools, vision or audio: narrow the task, scaffold it or identify the needed capability; do not fake it. |  |
| X10 | Changed sources, utilities, model behavior or host rules: detect the mismatch and revalidate rather than trusting stale success. |  |
