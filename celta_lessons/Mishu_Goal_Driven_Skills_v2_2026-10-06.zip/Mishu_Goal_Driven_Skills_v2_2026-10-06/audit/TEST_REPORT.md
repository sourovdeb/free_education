# Test report — Goal-Driven Skills 2.0.0

**Date:** 6 October 2026  
**Environment:** Local Linux build container; Python 3.13.5.  
**Target user environment:** Not accessed for installation or execution.

## Executed helper-tool tests

**28 of 28 unit tests passed.** The unedited unittest output is in `utility_tests.log`. The suite exercises exact block preservation and error cases, prompt composition, narrow frontmatter parsing, and the installer's dry-run, no-overwrite, path checks and hash-verified copies. Installer tests write only to temporary test directories.

Three command-line smoke checks also passed their expected outcomes. The matching source/reader fixture returns PASS with exit 0. The deliberately incomplete reader fixture returns FAIL with exit 1, as required. The prompt composer returns the selected standalone prompt and task with exit 0. See `cli_checks.json`. These are software checks, not trials of a language model following the skill.

## Static packaging checks

The local validator checks 48 skill folders, 48 standalone prompts, required sections, narrow frontmatter, source mappings, the 27 archive-row IDs and 42 registry-activity IDs, designed evaluation data, Markdown links, nonempty files, and a limited accidental-secret pattern scan. A final SHA-256 manifest and ZIP integrity check are run during packaging. A manifest establishes byte integrity, not meaning, rights or security. The validator is not the official Agent Skills validator and is not a general YAML parser.

`static_validation.json` records the pre-manifest validation result. HTML link checks are recorded in `html_link_checks.json`. Only link structure is checked for the HTML catalog; no browser rendering or accessibility certification is claimed. Final manifest validation is performed after this report is written so the report itself can be checksummed.

## Designed model tests — NOT RUN

**288 cases across 48 skills; 0 executed model cases.** Each skill has a normal case, a domain-specific failure case, missing input, hostile source instructions, misleading tool success and interrupted/repeated work. These are stored in `skills/*/evals/cases.json`. Expected behavior is a proposed acceptance criterion, not an observed success.

There are no measured baseline-versus-upgraded model results. No Hermes, Mistral, Agnes, TypeSafe, WordPress, Apps Script or Blender live integration was run. No independent educator, narrator or author trial was performed. The 74-entry master-standard worksheet is a review aid, not a completed 74-pass scorecard.

## Source and deployment boundaries

The main archive was reviewed through indexed excerpts; all 27 catalog rows have a disposition. The 42 older registry activities are mapped to reconstructed workflows. Two recovered newer source exports were read in full and are retained with hashes. This does not establish recovery of every historical skill, binary attachment or remote repository file. Read `../SOURCE_COVERAGE.md` and `../LIMITATIONS.md` for exclusions.

No user-host installation, remote-library overwrite, email send, public publication, purchase or scheduled automation was performed. **Instruction status: reviewed candidate. Model validation: NOT_RUN. Target: TARGET_UNVERIFIED. Deployment: NOT_DEPLOYED.**
