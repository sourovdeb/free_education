# Standalone prompts

Each file here contains the full operational instructions without host frontmatter or hidden dependencies. Choose one, paste it, then add the actual task/source. These are full-quality prompts, not abbreviated commands that require an unseen system prompt. Their evaluation cases remain NOT_RUN until tried in your actual model. Do not paste all 48 prompts together.
