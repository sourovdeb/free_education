# Mishu — Goal-Driven Skills
## Version 2.0.0 · 6 October 2026

**Start with the result you need, not the number of skills.** This bundle contains 48 focused skills and 48 complete standalone prompts. They cover the recovered writing, research, teaching and reading material, plus reconstructed registry workflows and clearly identified project extensions.

## Easiest route: no installation

1. Open **CATALOG.md** or **BROWSE.html** and choose one goal.
2. Open the matching file in **prompts/** and paste its contents into your agent or text chat.
3. Add your actual task and relevant source. State only material constraints such as audience, format, protected text and permitted external actions.
4. Ask for the actual deliverable. The prompt contains the method, fallback and completion checks. You do not need to paste the entire library or master standard.

For book work, begin with **mishu-audiobook-performance-coach** for narration scripts, **mishu-weekly-reading-sentence-lab** for detailed English/prosody study, or **mishu-faithful-book-illumination** for the same text with integrated visuals. For old lectures use **mishu-lecture-to-lessons**. For fiction use **mishu-story-development-director** or the particular craft operation you need.

### Example task to append

> Work on the attached passage. Preserve every source word and its order. Give me a separate performance script, pronunciation script and short coaching notes. Use only capabilities actually available. Start with a coherent short section and record the next sentence ID if the whole source is too large.

## Hermes or another Agent Skills host

The **skills/** directories each contain a self-contained **SKILL.md**, plus optional local examples/evaluation data and review notes. Names use the **mishu-** prefix to reduce collisions with existing skills. Installation is optional and has NOT been performed in your environment.

For Hermes, the documented default skill directory is **~/.hermes/skills/**, but named profiles, HERMES_HOME and custom directories must be checked in the actual installation. Consult source W2 in sources/README.md. Do not replace your existing library wholesale.

### Optional local installer — Python 3.10 or newer

No third-party Python packages are required for the bundled helper tools. From the extracted bundle folder, preview one copy:

```sh
python tools/install_skills.py --dest /path/to/your/verified/skills --skill mishu-audiobook-performance-coach
```

Replace the destination with the skill folder actually used by your host. The command is a **dry run**: it does not create the destination or modify existing files. After checking the printed destination and selected skill, repeat with **--apply** to copy it. Existing folders are never overwritten. Use repeated **--skill** options to select several; **--all** is an explicit optional choice, not the recommended starting route.

If a folder already exists, the installer stops. Compare versions manually and keep a backup; do not delete the old version merely to silence the check. To undo a new copy, remove only the exact newly installed folder recorded in the installer output, after checking that you have not edited it. Never delete the host's entire skills folder.

On Windows, **py** may be the available Python command instead of **python**. No Python installed? Use the no-install prompt route above; installing Python is not necessary to use the skills.

## Optional checks

```sh
python tools/validate_bundle.py
python -m unittest discover -s tests -v
python tools/source_guard.py examples/source_blocks.json examples/reader_blocks.json
```

The source guard compares stable block IDs, order and exact text. It does not certify the quality of a translation, pronunciation guide or rendered layout. The included good fixture should pass; **examples/reader_blocks_bad.json** intentionally fails.

The prompt composer prints a selected standalone prompt plus a task file without calling a provider:

```sh
python tools/compose_prompt.py mishu-audiobook-performance-coach --task examples/task.txt
```

## What changed

Skills now have a concrete goal, observable output, specialist method, tool/no-tool branches, source/canon protection, stopping and resumption rules, and domain-specific acceptance examples. Creative methods remain central; the user does not need to approve every harmless drafting choice. Source facts and external actions are different boundaries.

Read **CHANGELOG.md** for the individual changes and **SOURCE_COVERAGE.md** for all 27 archive entries and all 42 older activity descriptions. Duplicate modes are consolidated rather than counted as separate accomplishments. **GOAL_WORKFLOWS.md** gives practical combinations without loading all bodies at once.

## Honest status

This is a completed package of reviewed skill candidates. Static packaging and local utility test results are recorded in **audit/TEST_REPORT.md**. The 288 model-behavior cases have **not** been run on Hermes/Mistral or another target model. No remote library was changed, no software was installed on your machine and no automation was enabled. See **LIMITATIONS.md** for exact coverage.
