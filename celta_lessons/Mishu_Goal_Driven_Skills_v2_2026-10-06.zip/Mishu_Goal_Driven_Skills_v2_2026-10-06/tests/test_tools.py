"""Local utility tests. No models, network, host installs or user data are used."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from source_guard import compare, validate_blocks, load_blocks
from install_skills import install, prepare, digest_tree
from compose_prompt import compose
from validate_bundle import frontmatter

class SourceGuardTests(unittest.TestCase):
    def setUp(self):
        self.source=[{'id':'S01','text':'You came back.'},{'id':'S02','text':'I waited.'}]
    def test_exact(self): self.assertEqual(compare(self.source,copy.deepcopy(self.source))['status'],'PASS')
    def test_omission(self): self.assertEqual(compare(self.source,self.source[:1])['missing_ids'],['S02'])
    def test_changed_word(self):
        r=copy.deepcopy(self.source); r[1]['text']='I never waited.'
        self.assertEqual(compare(self.source,r)['changed_ids'],['S02'])
    def test_punctuation(self):
        r=copy.deepcopy(self.source); r[0]['text']='You came back!'
        self.assertEqual(compare(self.source,r)['status'],'FAIL')
    def test_order(self): self.assertFalse(compare(self.source,list(reversed(self.source)))['exact_order'])
    def test_extra(self): self.assertEqual(compare(self.source,self.source+[{'id':'S03','text':'Extra.'}])['extra_ids'],['S03'])
    def test_duplicate_rejected(self):
        with self.assertRaises(ValueError): validate_blocks({'blocks':[self.source[0],self.source[0]]})
    def test_empty_rejected(self):
        with self.assertRaises(ValueError): validate_blocks({'blocks':[]})
    def test_bad_type(self):
        with self.assertRaises(ValueError): validate_blocks({'blocks':[{'id':'S01','text':7}]})
    def test_blank(self):
        with self.assertRaises(ValueError): validate_blocks({'blocks':[{'id':'S01','text':'  '}]})
    def test_unicode_exact(self):
        b=[{'id':'P01','text':'Réunion — café. বাংলা'}]
        self.assertEqual(compare(b,b)['status'],'PASS')
    def test_no_unicode_normalization(self):
        a=[{'id':'S01','text':'café'}]; b=[{'id':'S01','text':'cafe\u0301'}]
        self.assertEqual(compare(a,b)['status'],'FAIL')
    def test_load_fixture(self): self.assertEqual(len(load_blocks(ROOT/'examples/source_blocks.json')),3)

class InstallTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.home=Path(self.tmp.name)
        self.root=self.home/'bundle'; self.src=self.root/'skills/mishu-demo'
        self.src.mkdir(parents=True); (self.src/'SKILL.md').write_text('sample skill',encoding='utf-8')
        self.dest=self.home/'destination'
    def tearDown(self): self.tmp.cleanup()
    def test_dry_run_writes_nothing(self):
        result=install(self.root,self.dest,['mishu-demo'])
        self.assertEqual(result['status'],'PREVIEW_ONLY'); self.assertFalse(self.dest.exists())
    def test_apply_hash_verified(self):
        r=install(self.root,self.dest,['mishu-demo'],True)
        self.assertEqual(r['entries'][0]['status'],'COPIED_AND_HASH_VERIFIED')
        self.assertEqual(digest_tree(self.src),digest_tree(self.dest/'mishu-demo'))
    def test_no_overwrite(self):
        install(self.root,self.dest,['mishu-demo'],True)
        (self.dest/'mishu-demo/SKILL.md').write_text('user edit',encoding='utf-8')
        with self.assertRaises(ValueError): install(self.root,self.dest,['mishu-demo'],True)
        self.assertEqual((self.dest/'mishu-demo/SKILL.md').read_text(),'user edit')
    def test_traversal(self):
        with self.assertRaises(ValueError): prepare(self.root,self.dest,['../outside'])
    def test_missing_skill(self):
        with self.assertRaises(ValueError): prepare(self.root,self.dest,['not-here'])
    def test_duplicate_selection(self):
        with self.assertRaises(ValueError): prepare(self.root,self.dest,['mishu-demo','mishu-demo'])
    def test_source_destination(self):
        with self.assertRaises(ValueError): prepare(self.root,self.root/'skills',['mishu-demo'])
    def test_source_symlink(self):
        try: (self.src/'bad').symlink_to(self.home)
        except OSError: self.skipTest('Symlinks unavailable on this platform')
        with self.assertRaises(ValueError): prepare(self.root,self.dest,['mishu-demo'])
    def test_destination_symlink(self):
        real=self.home/'real'; real.mkdir()
        try: self.dest.symlink_to(real,target_is_directory=True)
        except OSError: self.skipTest('Symlinks unavailable on this platform')
        with self.assertRaises(ValueError): prepare(self.root,self.dest,['mishu-demo'])
    def test_preflight_all_before_writes(self):
        with self.assertRaises(ValueError): install(self.root,self.dest,['mishu-demo','missing'],True)
        self.assertFalse(self.dest.exists())

class FormatAndPromptTests(unittest.TestCase):
    def test_frontmatter(self):
        s='---\nname: demo\ndescription: "A useful goal"\nmetadata:\n  version: "2.0.0"\n---\n# Body'
        self.assertEqual(frontmatter(s)['metadata']['version'],'2.0.0')
    def test_missing_frontmatter(self):
        with self.assertRaises(ValueError): frontmatter('# text')
    def test_prompt_composition(self):
        text=compose(ROOT,'mishu-audiobook-performance-coach','My actual task.')
        self.assertIn('My actual task.',text); self.assertIn('## Goal',text)
    def test_prompt_path_traversal(self):
        with self.assertRaises(ValueError): compose(ROOT,'../../private')
    def test_missing_prompt(self):
        with self.assertRaises(ValueError): compose(ROOT,'mishu-absent')

if __name__=='__main__': unittest.main()
