# Sources and coverage

**MASTER** — {"title": "Master20Standard.md", "source": "user-uploaded project file", "date": "2026-09-18", "access": "indexed excerpts covering foundations, operating rules, 74-question structure and release gates"}

**SKILL_MAKING** — {"title": "skill-making.txt", "source": "user-uploaded project file", "access": "indexed excerpts covering upgrade procedure"}

**LIBRARY** — {"title": "LIBRARY_SKILLS_BUNDLE.md", "source": "user-uploaded project file", "date": "2026-09-18", "access": "catalog and selected relevant body excerpts; not complete byte-level source backup"}

**REGISTRY** — {"title": "SKILL_REGISTRY_ALL_ACTIVITIES.md", "source": "connected Drive text download", "date": "2026-06-06", "access": "full local text read", "sha256": "0f147c310fbc6b1d264e67c61821c9d1a5fa9edaefbf1fac67a6eb5ae1bdcadc", "included_raw": false, "reason": "Raw file contains personal case/context details and obsolete operational shortcuts; sanitized 42-item mapping included instead."}

**S001** — {"title": "Audiobook Performance Coach", "source": "connected Google Doc text export", "version": "1.2.1", "access": "full local export read and preserved"}

**S002** — {"title": "Mistral Writing Specialist candidate", "source": "connected Google Doc text export", "version": "1.1.0-rc1", "access": "full local export read and preserved", "limit": "Not certified as the latest remote version; newer titles discovered but not relied on without substantive content inspection."}

**PROJECT** — {"title": "Shared project requests", "source": "supplied conversation context", "access": "book illumination, small/non-reasoning models, lecture chunking, low-resource media, two-thirds visuals and reusable assets"}

**CONNECTED_DISCOVERY** — {"source": "GitHub, Drive, Box and one Gmail search", "access": "repository/index and file/folder discovery; selected Drive text retrieval", "limit": "Not a complete recovery or update of every remote repository/folder. No remote content was modified or published."}

**W1** — {"title": "Agent Skills specification", "url": "https://agentskills.io/specification", "note": "Inspected 2026-10-06. Directory/frontmatter, naming, optional references and progressive loading. Local validator checks a deliberately narrow serialization; not the official skills-ref validator."}

**W2** — {"title": "Hermes skills documentation", "url": "https://hermes-agent.nousresearch.com/docs/user-guide/features/skills/", "note": "Inspected 2026-10-06 with official creating-skills/work-with-skills pages. Intended on-demand use; actual user profile and host installation were not tested."}

**W3** — {"title": "Cambridge CELTA course details", "url": "https://www.cambridgeenglish.org/educators-organisations/professional-development/teaching-qualifications/celta/about/", "note": "Inspected 2026-10-06. Distinguishes at least 120 course contact hours from 6 assessed teaching-practice hours. Does not verify any individual qualification."}

**W4** — {"title": "Google Apps Script V8 runtime", "url": "https://developers.google.com/apps-script/guides/v8-runtime", "note": "Inspected 2026-10-06. Runtime-specific JavaScript support; actual user project not inspected."}

**W5** — {"title": "Google GmailApp reference", "url": "https://developers.google.com/apps-script/reference/gmail/gmail-app", "note": "Inspected 2026-10-06. Includes createDraft options overload; current live API not exercised."}

**W6** — {"title": "Google installable triggers", "url": "https://developers.google.com/apps-script/guides/triggers/installable", "note": "Inspected 2026-10-06. Time-driven schedules may be randomized within a window; no user trigger installed."}

**W7** — {"title": "WordPress REST posts reference", "url": "https://developer.wordpress.org/rest-api/reference/posts/", "note": "Inspected 2026-10-06. Standard post objects and state fields; does not establish any custom site endpoint."}

**W8** — {"title": "Blender Python API reference", "url": "https://docs.blender.org/api/current/", "note": "Reference destination only. Attempt to open quickstart failed in this run. No version-specific Blender API recipe or compatibility claim is certified here; verify installed-version docs at execution."}

See source_coverage.json for every archive and registry disposition. Reported archive hash prefixes were copied from its catalog and were not rehashed locally. Only the two retrieved text exports have locally verified source hashes. The final bundle has independent hashes for its own actual files.
