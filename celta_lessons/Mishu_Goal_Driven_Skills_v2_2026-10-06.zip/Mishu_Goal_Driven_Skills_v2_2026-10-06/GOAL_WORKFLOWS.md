# Practical goal workflows

These are suggested handoffs, not automatically running integrations. Start with one skill and pass only the necessary source/state to the next.

## Same book, new reading experience

**Goal:** retain the book and make it easier to understand and perform.

Start with the audiobook coach for source IDs and separate reading/pronunciation scripts. Use the sentence laboratory only for passages needing deeper language work. Add faithful illumination beside relevant passages. Acceptance: source blocks unchanged, matching sentence IDs, readable scripts, useful anchored visuals and honest media status.

## A complete small lesson from an old lecture

**Goal:** one learner can understand, try and check a new skill.

Use lecture-to-lessons for conceptual segmentation and source coverage; teaching-materials-methods supplies a worked example, practice and feedback. Use ELT365 only for a genuinely compact unit. Acceptance: the practice tests the outcome, the answer guidance is usable and old claims are corrected separately from original content.

## A story that becomes a manuscript

**Goal:** turn author decisions into actual prose, not an ever-growing empty writing system.

Use story development to choose the next meaningful direction; context packer supplies relevant canon; scene planner/drafter creates prose. Use a focused editor or continuity keeper only where needed. Acceptance: the scene changes state, preserves locked facts and leaves canon approval with the author.

## Memoir without invented memory

**Goal:** readable sections faithful to what the user remembers, knows or can document.

The interviewer asks one non-leading question and waits. The manuscript builder drafts once enough material exists. Evidence translation or dossier work stays separate from literary drafting. Acceptance: uncertain history remains uncertain, private material stays protected and enough sections are assembled into a bounded version.

## Two-thirds visuals, one-third presenter

**Goal:** visual teaching or book reading that remains intelligible on modest hardware.

Transcript visual director produces a source-linked cue sheet; storyboard assets supply reusable items; Blender producer tests a lightweight pilot. Video editing joins real media and reviewed captions. Acceptance: labels are readable, the presenter area is clear, the timing is real or explicitly estimated and rendering claims match actual files.

## One truthful application

**Goal:** a relevant application reaches the correct verified destination once.

Career workflow prepares the accurate CV/letter. Verified outreach checks recipient and history. An approved send needs a real receipt and ledger update. Apps Script is optional and should not be deployed before a bounded end-to-end route works.

## Upgrade a skill without false completion

**Goal:** replace a demonstrated failure with a traceable improvement.

Skill architect reads the actual source, chooses patch or restructuring, preserves craft, writes tests and records limits. Library curator maps aliases and versions. Test the intended host before relying on it. An approved document is not a tested integration.
