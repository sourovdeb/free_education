# Open Teacher Training — website and teaching skill
Version 1.0 · 13 September 2026 · Prepared for Mishu / Sourov Deb

## The two deliverables
**Website:** a dedicated learning section for the existing WordPress site, not a second website and not a replacement for the personal blog.
**Skill:** a reusable `teaching-materials-methods` folder for Hermes, with procedures, method-selection guidance, templates, an original worked example and a structural validator.

## Start here
1. Read `website/WEBSITE_SECTION_PLAN.md`.
2. Use `website/WORDPRESS_DRAFT_IMPORT_GUIDE.md` with `website/open-teacher-training-drafts.xml` to create draft pages on a staging copy first. This is an optional shortcut; manual page creation is also documented. The XML is not a plugin.
3. Copy the complete `teaching-materials-methods` folder into the skills directory of the Hermes profile you actually use. The default is `~/.hermes/skills/`. Open a fresh session and ask Hermes to list/load the skill. Do not overwrite a same-named skill without comparison and backup.
4. Start with the original worked unit in `teaching-materials-methods/examples/`.

The XML contains 24 draft pages: eight section pages, twelve module outlines and four pilot-unit pages. One pilot unit has complete sample teaching content; the other three are explicitly outlines. None is an externally reviewed or classroom-tested course release.

## What was inspected
The previous editable booklet, the uploaded rigorous-analysis framework, the public homepage, the existing ELT Masterclass index and one sample teaching post, plus official WordPress/Hermes/W3C documentation and one British Council methodology article. Source details and limitations are in `SOURCES.md`.

No WordPress administration login, theme inspection, full archive audit, classroom trial, live import, publishing or Hermes installation was performed. No existing website content was edited.

## Ownership and licensing decision
The kit proposes an open licence for original educational materials; the owner must approve the licence and check third-party permissions before release. No Cambridge/Oxford branding, source handouts, learner records or third-party font files are included. The working title does not imply affiliation or an awarded qualification.
