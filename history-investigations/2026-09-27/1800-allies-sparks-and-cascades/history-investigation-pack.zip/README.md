# History Investigation — 18:00 edition

This pack investigates cascades.

It contains six chapters.

- Tenochtitlan’s Indigenous alliances.
- India’s accumulated 1857 grievances.
- Abolition’s organized political power.
- Haber–Bosch’s dual-use chemistry.
- Berlin’s cascading border opening.
- Bystander hesitation.

## Files

- `edition.md` — complete sourced edition.
- `wordpress-draft.html` — unpublished import draft.
- `evidence.svg` — accessible cascade diagram.
- `lesson-viewer.html` — dependency-free viewer.
- `lesson.json` — reusable lesson data.
- `build.py` — document and viewer builder.
- `render_video.py` — offline video renderer.
- `history-investigation.mp4` — silent visual summary.
- `manifest.json` — validation and hashes.

## Offline use

Keep all files together.

Open `lesson-viewer.html` locally.

Use Previous and Next.

Play advances every twelve seconds.

The video remains separately controllable.

## Rebuild

Run `python3 build.py`.

Then run `python3 render_video.py`.

The renderer needs Pillow and FFmpeg.

## Verified media

The MP4 is 1280×720.

It runs at 25fps.

Duration is 210 seconds.

It has no audio stream.

## Website status

The WordPress file is unpublished.

No remote website write occurred.

