# Pride and Prejudice: Chapter I

This is a chapter preview, not a completed book.

Open `chapter-one.html` in a browser. Use Next Panel and Previous Panel. Pause Motion stops the ASCII loop. The file works offline. Each image slot accepts `panel01.jpg` through `panel15.jpg` placed beside the HTML. The slots remain labelled placeholders until images are supplied. Sketch prompts appear below the scored text.

The package includes the complete supplied chapter body, 15 panels, a scored script, PDF, PPTX, and silent H.264 MP4. The video is 1280×720 at 25fps and lasts 5:58. ASCII poses update five times per second within the 25fps stream. It is a storyboard animation, not a rendered pencil-sketch film.

Every source word remains, including the extraction artifact `I t`. Source filenames and front matter are excluded from the chapter body. Removing inserted cues and pauses reproduces the source token sequence. The chapter body reconstructs byte-for-byte from the panel source fields. Narrative and dialogue cues are interpretation, not claims about Austen's intended performance.

TypeSafe authenticated successfully during this build. The key is excluded from these files. Future runs must call TypeSafe and stop completion reporting if authentication fails. Deterministic text checks remain mandatory regardless of model judgments.

Hourly book processing starts 27 September 2026 at 18:33, Indian/Reunion. One complete book is the target per run. A run that cannot finish must checkpoint and resume; it must not label a partial book complete. Finish Austen before changing books. Start nonfiction with Benjamin Franklin's autobiography when a suitable source edition is available. Use a different accent and body font for each subsequent book while retaining monochrome artwork.

Deliver the scored body and prompts with all formats. Confirm Gmail, Drive and GitHub receipts separately. Never put API credentials in HTML, GitHub, email, PPTX, PDF, or the completion manifest.

WordPress can embed the HTML from its own hosted location using an iframe. LinkedIn can use the PDF or MP4. No WordPress or LinkedIn publication was performed during this preview build.

Source: Jane Austen, *Pride and Prejudice* (1813), Chapter I, from the user's supplied `classic-fiction-and-nonfiction-with-lexis.md`. This edition uses the supplied text, including its punctuation and extraction quirks. Modern translations and editorial matter from other books need separate publication-rights handling.
